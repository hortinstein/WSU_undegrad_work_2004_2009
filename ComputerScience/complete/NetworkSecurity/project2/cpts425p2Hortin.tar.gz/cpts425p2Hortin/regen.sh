#!/bin/sh
# This resets bob and alice's certs for future use
./bob -g
./alice -g
