
#include "ucode.c"

main()
{ 
  char name[64]; 
  int pid, cmd;

  pid = getpid();

  while(1){

       printf("==============================================\n");
       printf("I am proc %din U mode: running at segment=%x\n",
                pid, getcs());

       #include "ubody.c"
  }
}

