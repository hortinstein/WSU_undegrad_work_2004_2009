int kcinth()
{
   ushort segment, offset, a, b;
   segment = running->uss; offset = running->usp;
 
   a = get_word(segment, offset + 2*13);
   b = get_word(segment, offset + 2*14);

   switch(a){

      case 9:  chcolor(b); break;

      case 10:  putc(b);    break;


      default: printf("\nkcinth: your syscall # = %d\n", a);
   }
}
