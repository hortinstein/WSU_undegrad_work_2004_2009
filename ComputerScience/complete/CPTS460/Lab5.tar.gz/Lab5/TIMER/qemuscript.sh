qemu -fda mtximage -boot a -no-fd-bootchk
