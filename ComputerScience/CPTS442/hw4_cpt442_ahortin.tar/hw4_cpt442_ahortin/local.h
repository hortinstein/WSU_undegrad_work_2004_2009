enum {
    N_VTX = 3,
};

extern void setCell(int x, int y, double r, double g, double b);

extern void fillTri(int p[N_VTX][2]);
