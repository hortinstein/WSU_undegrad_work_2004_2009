public class RocketException extends Exception {

    public RocketException(String message) {
        super(message);
    }

    public RocketException(String message, Throwable cause) {
        super(message, cause);
    }

}
