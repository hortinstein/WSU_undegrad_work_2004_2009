class Planet {

    private double gravity; /* units: (m/s/s) */
    private double ground;  /* units: m */
    private String name;

    /* constructors and accessors go here--you are to complete them */
       
    public Planet() {} // boring planet
}
