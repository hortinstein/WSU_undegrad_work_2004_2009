/************ main.c file **********************************/
#define NPROC     4        
#define SSIZE  1024       // per proc kstack size 

#define FREE      0       // proc status 
#define READY     1      
#define RUNNING   2
#define ZOMBIE    3

typedef struct proc{
    struct proc *next;   
    int  *ksp;            // saved sp; offset = 2

    int  pid;
    int  ppid;
    int  priority;        // scheduling priority
    int  status;          // FREE|READY|.... 
    int  exitValue;       // exit code  

    int kstack[SSIZE];    // per proc kmode stack 
}PROC;

PROC proc[NPROC], *running, *freelist, *readyqueue;
int  procsize = sizeof(PROC);

int body();
PROC *getproc();
PROC *dequeue();

#include "myio.c"    // YOUR gets, printf functions

int initialize()
{
  int i;
  PROC *p;

  printf("initialize ....\n");

  for (i = 0; i < NPROC; i++){
    proc[i].pid = i;                        // pid = 0,1,2,3 */    
      proc[i].status = FREE;
      proc[i].priority = 1;                 // all have priority = 1        
      proc[i].next=(PROC *)&proc[(i+1)];       
  }
  freelist = &proc[0];                      // all proc's in freelist
  proc[NPROC-1].next = 0;

  readyqueue = 0;                          // readyqueue = empty

  // create P0
  printf("create P0 as running\n");
  p = getproc();
  p->status = RUNNING;
  p->priority = 0;                        // P0 has lowest priority
  running = p;

  printf("create P1, put into readyqueue\n");
  p = getproc();
  p->status = READY;
  p->priority = 1;

  /****************************************************************
   stack frame = -1    -2  -3  -4  -5  -6  -7  -8  -9
                 body  ax  bx  cx  dx  bp  si  di  flag
                                                    |
                                                   ksp
  ****************************************************************/
   for (i=2; i<=9; i++)
       p->kstack[SSIZE - i] = 0;
   p->kstack[SSIZE - 1] = (int)body;
   p->ksp = &p->kstack[SSIZE - 9];

   enqueue(p);
   printqueue();

   prints("initialization done\n"); 
}

int body()
{  
   char c;
   while(1){
     printf("I am Proc%d : Input a char [p|s|q] : ", running->pid); 
     c=getc();
     printf("\n");

     switch(c){
        case 'p': ps();        break;
        case 's': tswitch();   break;
        case 'q': kexit(1);    break;
        default :              break;  
     }
   }
}


main()
{
   printf("\nWelcome to the 460 MTX System\n");
   initialize();

   printf("P0 switch to P1\n");
     tswitch();
   printf("main resumes: happy ending\n");
}

int scheduler()
{
    PROC *p;

    if (running->pid>0){
       if (running->status == RUNNING){
           running->status = READY;
           enqueue(running);
       }
    }
    running = dequeue();
    
}


// utility functions

PROC *getproc()             // get a pointer to a FREE proc
{
  PROC *p = freelist;
  if (p){
    freelist = p->next;
  }
  return p;
}

int putproc(p) PROC *p;   // return p to freelist
{
  p->status = FREE;
  p->next = freelist;
  freelist = p;

}

int enqueue(p) PROC *p;   // enter p into readyqueue
{
  if (readyqueue==0)
     readyqueue = p;
  else{
        // enter p into readyqueue by priority
  }
  p->next = 0;
}


PROC *dequeue()         // remove and return FIRST proc from readyqueue
{
  PROC *p = readyqueue;

  if (p){
    readyqueue = p->next;
    p->status = RUNNING;
    return p;
  }
  return &proc[0];        // if readyqueue empty => return P0
}

int printqueue()          // print readyqueue 
{
  PROC *p = readyqueue;
  printf("readyqueue = ");
  while (p){
    printf("%d-> ",p->pid);
    p = p->next;
  }
  printf("NULL\n");
}


char *pStatus[] = {"FREE   ","READY  ","RUNNING","ZOMBIE ", 0};

int ps()                 // print all proc pid and status
{
  PROC *p;

  printf("---------------------------\n");
  p = &proc[0];

  while (p < &proc[NPROC]){
    printf("%d   %s\n", p->pid, pStatus[p->status]);
    p++;
  }
  printf("---------------------------\n");
  printqueue();  
}

char *gasp[NPROC]={
     "Oh! You are killing me .......\n",
     "Oh! I am dying ...............\n", 
     "Oh! I am a goner .............\n", 
     "Bye! Bye! World...............\n",      
};

int grave(){
  printf("*****************************************\n"); 
  printf("Proc%d %c %s", running->pid, 7, gasp[(running->pid) % NPROC]);
  printf("*****************************************\n");
  running->status = ZOMBIE;

  tswitch();   /* journey of no return */        
}

int kexit(v) int v;
{
  printf("Proc%d in kexit(): exitValue=%d\n", running->pid, v);
  running->exitValue = v; 
  grave();
}


