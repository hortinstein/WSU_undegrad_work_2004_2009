///////////////////////////////////////////////////////////////////////////////
/// \class        ConnectionWindow
/// \author       Alex Hortin
/// \date         2/28/06  
/// \brief			This is a window that tests the HandOfCards class
///
/// This Class is the window that you will see that contains all the work 
/// behind the program interface.  It will display graphics for hands, and 
/// pop up error messages when nessecary.
///
///       
/// REVISION HISTORY:
///
/// NONE
///            
///////////////////////////////////////////////////////////////////////////////

// SYSTEM INCLUDES
//
#include <FL/Fl.H>//the FLTK source files
#include <FL/Fl_Window.H>//the FLTK source files
#include <FL/Fl_Button.H>//the FLTK source files
#include <FL/Fl_Input.H>//the FLTK source files
#include <FL/Fl_Output.H>//the FLTK source files
#include <FL/Fl_GIF_Image.h>//the FLTK gif class
#include <Fl/fl_ask.H>
#include <FL/Fl_Value_Slider.H>
#include <FL/gl.h>
#include <FL/Fl_Dial.H>
#include <FL/Fl_Round_Button.H>
#include <GL/gl.h>
#include <FL/Fl_Overlay_Window.H>
#include <FL/Fl_Output.H>//the FLTK source files
#include <FL/Fl_Multiline_Output.H>
#include <string>//string.h include
#include <vector>//vector.h include
#include <stdio.h>
#include <stdlib.h>
#include <stdexcept>

// LOCAL INCLUDES
//
#include "ConnectionWindow.h"
#include "Connection.h"
#include "MyWindow.h"
// FORWARD REFERENCES
//

// CONSTANTS
//

// LIFECYCLE

///////////////////////////////////////////////////////////////////////
/// Default constructor.
/// \pre    None
/// \post   An instance of the MyWindow is created.
/// \param  None
/// \throw  None
///////////////////////////////////////////////////////////////////////
ConnectionWindow::ConnectionWindow() : Fl_Window(100,100, "Connection Setup")//the basic constructor used for testing
{
	this->resize(100,100,100,100);
	cServer = new Fl_Round_Button(10,10,70,30,"Server");
	cClient = new Fl_Round_Button(10,50,70,30,"Client");
	cPlayers = new Fl_Input(250,10, 100,30,"Number of Players:");
	cIP = new Fl_Input(250,10, 100,30,"Ip Adress:");
	cUserName = new Fl_Input(250,50, 100,30,"User Name:");
	cConnect = new Fl_Button(400, 30, 60,30, "Connect");
	cConnect->hide();
	cPlayers->hide();
	cUserName->hide();
	cIP->hide();
	cServer->callback(cb_server, this);
	cClient->callback(cb_client, this);
	cConnect->callback(cb_connect, this);
	
	

	cIP->value("127.0.0.1");

	cPlayers->value("1");

	cUserName->value("Default");
	
	this->show();
}

///////////////////////////////////////////////////////////////////////
/// Destructor.
/// \pre    An instance of PlaybackWindow has been created.
/// \post   The instance of PlaybackWindow is destroyed.
///////////////////////////////////////////////////////////////////////
ConnectionWindow::~ConnectionWindow()//the destructor
{
}
// OPERATORS

///////////////////////////////////////////////////////////////////////
/// returnConnection returns a pointer to the connection class contained within this window
/// \pre    A the connection is finised being created
/// \post   the connection will be passed into the scorch window
/// \param none
/// \return a pointer to the connection
/// \throw  None
///////////////////////////////////////////////////////////////////////
Connection* ConnectionWindow::returnConnection(void)
{
		return mConnection;
}
// OPERATIONS

// ACCESS and MUTATE

// INQUIRY

// OPERATIONS

///////////////////////////////////////////////////////////////////////
/// draw draws all of the widgets
/// \pre    A valid window
/// \post   a window is added
/// \param none
/// \return none
/// \throw  None
///////////////////////////////////////////////////////////////////////
void ConnectionWindow::draw(void)
{
	Fl_Window::draw(); 
}

///////////////////////////////////////////////////////////////////////
/// handle handles the mouse events that happen
/// \pre    a button is clicks
/// \post   a card is added
/// \param  the event number
/// \return the event number
/// \throw  None
///////////////////////////////////////////////////////////////////////
int ConnectionWindow::handle(int event)
{
	int r = Fl_Window::handle(event);
	return r;
}


// ACCESS and MUTATE

///////////////////////////////////////////////////////////////////////
/// cb_server is the call that the program makes when the server button is pressed
/// \pre   None
/// \post  The button will be set, label of input changed, and other button turned off if its on
/// \param  a widget pointer
/// \return void
/// \throw  n/a
///////////////////////////////////////////////////////////////////////
void ConnectionWindow::cb_server(Fl_Widget*, void* v)
{
	( (ConnectionWindow*)v )->cb_server_i();
}

///////////////////////////////////////////////////////////////////////
/// cb_server_i is the call that the program makes when the server button is pressed
/// \pre   None
/// \post  The button will be set, label of input changed, and other button turned off if its on
/// \param  a widget pointer
/// \return void
/// \throw  n/a
///////////////////////////////////////////////////////////////////////
void ConnectionWindow::cb_server_i()
{
	
	cIP->hide();
	cServer->set();
	cClient->clear();
	this->resize(100,100,500,100);
	cPlayers->show();
	cConnect->show();
	cUserName->show();
	redraw();
}

///////////////////////////////////////////////////////////////////////
/// cb_client is the call that the program makes when the client button is pressed
/// \pre   None
/// \post   The button will be set, label of input changed, and other button turned off if its on
/// \param  a widget pointer
/// \return void
/// \throw  n/a
///////////////////////////////////////////////////////////////////////
void ConnectionWindow::cb_client(Fl_Widget*, void* v)
{
	( (ConnectionWindow*)v )->cb_client_i();
}

///////////////////////////////////////////////////////////////////////
/// cb_client_i is the call that the program makes when the client button is pressed
/// \pre   None
/// \post  The button will be set, label of input changed, and other button turned off if its on
/// \param  a widget pointer
/// \return void
/// \throw  n/a
///////////////////////////////////////////////////////////////////////
void ConnectionWindow::cb_client_i()
{
	cPlayers->hide();
	cClient->set();
	cServer->clear();
	this->resize(100,100,500,100);
	cIP->show();
	cConnect->show();
	cUserName->show();
	redraw();
}

///////////////////////////////////////////////////////////////////////
/// cb_connect is the call that the program makes when the connect button is pressed
/// \pre   None
/// \post  A polymorphic connection is assgined to mConnection
/// \param  a widget pointer
/// \return void
/// \throw  n/a
///////////////////////////////////////////////////////////////////////
void ConnectionWindow::cb_connect(Fl_Widget*, void* v)
{
	( (ConnectionWindow*)v )->cb_connect_i();
}

///////////////////////////////////////////////////////////////////////
/// cb_connect_i is the call that the program makes when the connect button is pressed
/// \pre   None
/// \post  A polymorphic connection is assgined to mConnection
/// \param  a widget pointer
/// \return void
/// \throw  n/a
///////////////////////////////////////////////////////////////////////
void ConnectionWindow::cb_connect_i()
{
	if (cClient->value() == true)
	{
		mConnection = new ClientConnection(cIP->value());
		mConnection->makeConnection(cUserName->value());
	}
	else
	{
		mConnection = new ServerConnection(atoi(cPlayers->value()));
		mConnection->makeConnection(cUserName->value());
	}
	this->hide();
	MyWindow* newwin = new MyWindow(mConnection,cUserName->value());
	newwin->show();
	
}
