///////////////////////////////////////////////////////////////////////////////
/// \class        Scorch
/// \author       Alex Hortin 
/// \date         March 20 2006
/// \brief        A class that stores a players details
///
/// This class stores a players details and can modify HP, award XP, save the
/// the level and skills of that player.
///
/// REVISION HISTORY
///
/// None
///
///////////////////////////////////////////////////////////////////////////////

// SYSTEM INCLUDES
//
#include <sstream>
#include <iostream>
#include <fstream>
#include <stdexcept>
#include <string>
#include <time.h>
#include <math.h>
// LOCAL INCLUDES
//
#include "Player.h"//the node to be defined
#include "Scorch.h"//the node to be defined
// FORWARD REFERENCES
//

// CONSTANTS
//
   

// LIFECYCLE

///////////////////////////////////////////////////////////////////////
/// Default constructor.
/// \pre    None
/// \post   An instance of player is constructed and new stats file will be contructed
/// \param  string for the username
/// \throw  None
///////////////////////////////////////////////////////////////////////
Scorch::Scorch()
{
	mTurn = 0;
}


// OPERATORS

// OPERATIONS


///////////////////////////////////////////////////////////////////////
/// fire fires a shot changes game state using the modify terrain and deal damage
/// \pre    a games is started and players are put into their locations
/// \post   The terrain vector is built
/// \param  power for power of bullet
/// \param	angle for the angle of bullet
/// \param	payload for the size of bullet
/// \return int for the final x of the bullet
/// \throw  None
///////////////////////////////////////////////////////////////////////
std::vector<Scorch::x_y> Scorch::fire(unsigned int power, unsigned int angle, unsigned int payload)
{
	double y_line = y_terrain(mPlayers[mTurn % mPlayers.size()].getLocation()) + (sin( angle * 3.14 / 180) * 20) + 25;
	double x_line = mPlayers[mTurn % mPlayers.size()].getLocation() + (cos( angle * 3.14 / 180) * 20);	
	mLastAngle[mTurn % mPlayers.size()] = angle;
	unsigned int powerplus = power;
	int xi = (int) x_line;
	int x = xi;
	int yi = (int) y_line;
	int y = y_terrain(xi);
	
	//creating the vector of vectors for the x_y coords
	std::vector<x_y> x_y_coords;
	Scorch::x_y coord;
	coord.x = xi;//adding x
	coord.y = yi;//adding y
	x_y_coords.push_back(coord);
	 
	
	
	mPlayers[mTurn % mPlayers.size()].useFuel(( powerplus / 35 + payload* 10)+5);
	
	double t = 0;
	while (y >= y_terrain(x) && x >= 0 && x <= 800)
	{
		double yv = sin(angle * 3.14 / 180) ;
		double xv = cos(angle * 3.14 / 180);
		
		y =(int)(yi + (float) powerplus * yv * t - ((9.8) * ( t * t ) / 2));
		x =(int)( xi + (float) powerplus * xv * t);
		coord.x = x;
		coord.y = y;
		x_y_coords.push_back(coord);
		t+= .03;
	}
	
	if (x >= 0 && x <= 800) 
	{
		modifyTerrain(payload+5,x);
		dealDamage(payload+5, x);
	}
	int players_left_alive = 0;
	for (unsigned int i = 0;i < playersAlive().size(); i++)
	{
		if (playersAlive()[i] == true)
		{
			players_left_alive++;
		}
	}
	//std::cout << players_left_alive << std::endl;
	mTurn++;
	while (mPlayers[mTurn % mPlayers.size()].isAlive() == false && players_left_alive > 0)
	{
		mTurn++;
		//std::cout << "skip" << std::endl;
	}
	
	return x_y_coords;
}

///////////////////////////////////////////////////////////////////////
/// buildTerrain builds the terrain using the seed
/// \pre    none
/// \post   The terrain vector is built
/// \param  none
/// \return none
/// \throw  None
///////////////////////////////////////////////////////////////////////
void Scorch::buildTerrain( time_t seed )
{
	srand(seed);
	int i = 0;
	mTerrain.clear();
	int h = rand()%80;
	h +=20;
	int p = rand()%200;
	p+=100;
	
	while (i < 800)
	{
		int c = rand()% 6;
		int r = rand() % 2;
		if(c > 3)
			c = 0;
		if (r % 2 == 0)
		{
			h += c;
		}
		else
		{
			h -= c;
		}
		int b;
		int d = 0;
		
		if( p %2 == 0 ) 
			b =(int)( sin(i * 3.14 / p)  * h); 
		else 
			b =(int)( cos(i * 3.14 / p)  * h);
		
		
		d = (rand() % 10);
		if (b < -300 )
			b = 0;
		mTerrain.push_back(b + 250);
		i++;
	}
}

///////////////////////////////////////////////////////////////////////
/// seedTerrainRand returns a seed to use to build terrain
/// \pre    none
/// \post   The random number for terrain generation is seeded
/// \param  none
/// \return a time_t for the seed of the number 
/// \throw  None
///////////////////////////////////////////////////////////////////////
time_t Scorch::seedTerrainRand( void )
{
	//return time(0);
	return 0;
}

///////////////////////////////////////////////////////////////////////
/// addPlayer adds a player to the players vector
/// \pre    none
/// \post   The terrain vector is built
/// \param  a string for name and a location
/// \return none
/// \throw  None
///////////////////////////////////////////////////////////////////////
void Scorch::addPlayer( std::string name, int loc )
{
	Player toadd(name);
	toadd.setLocation(loc);
	mPlayers.push_back(toadd);
	mLastAngle.push_back(0);
}

///////////////////////////////////////////////////////////////////////
/// moveRight move a player right and consumers fuel
/// \pre    none
/// \post   The terrain vector is built
/// \param  a string for name and a location
/// \return bool if succeeded
/// \throw  None
///////////////////////////////////////////////////////////////////////
bool Scorch::moveRight()
{
	
	if (mPlayers[mTurn % mPlayers.size()].isAlive() && mPlayers[mTurn % mPlayers.size()].getLocation() < 790 && mPlayers[mTurn % mPlayers.size()].getFuelRemaining() > 30)
	{
		mPlayers[mTurn % mPlayers.size()].useFuel(10);
		mPlayers[mTurn % mPlayers.size()].setLocation(mPlayers[mTurn % mPlayers.size()].getLocation()+2);
		return true;
	}
	else
	{	
		while (mPlayers[mTurn % mPlayers.size()].isAlive() == false)
		{
			mTurn++;
			//std::cout << "skip" << std::endl;
		}
		return false;
	}
	
}

///////////////////////////////////////////////////////////////////////
/// moveLeft moves a tank left and consumes fuel
/// \pre    none
/// \post   The terrain vector is built
/// \param  a string for name and a location
/// \return bool if succeeded
/// \throw  None
///////////////////////////////////////////////////////////////////////
bool Scorch::moveLeft()
{	
	if (mPlayers[mTurn % mPlayers.size()].isAlive() && mPlayers[mTurn % mPlayers.size()].getLocation() > 10 && mPlayers[mTurn % mPlayers.size()].getFuelRemaining() > 30)
	{
		mPlayers[mTurn % mPlayers.size()].useFuel(10);
		mPlayers[mTurn % mPlayers.size()].setLocation(mPlayers[mTurn % mPlayers.size()].getLocation()-2);
		return true;
	}
	else
	{	
		while (mPlayers[mTurn % mPlayers.size()].isAlive() == false)
		{
			mTurn++;
			//std::cout << "skip" << std::endl;
		}	
		return false;
	}
	
}

// ACCESS and MUTATE

///////////////////////////////////////////////////////////////////////
/// modifyTerrain damages the terrain based on power and location of explosion
/// \pre    a games is started and players are put into their locations
/// \post   The terrain vector is modified due to explosions
/// \param  none
/// \return none
/// \throw  None
///////////////////////////////////////////////////////////////////////
void Scorch::modifyTerrain(unsigned int power, int x)
{
	
	for (int i = 0; i < (int)power; i++)
	{
		mTerrain[x + i] -= power - i;
		if (i != 0)
		{
			mTerrain[x - i] -= power - i;
		}	
	}
}

///////////////////////////////////////////////////////////////////////
/// dealDamage deals damage to a player based on power and location of explosion 
/// \pre    none
/// \post   The terrain vector is built
/// \param  none
/// \return none
/// \throw  None
///////////////////////////////////////////////////////////////////////
void Scorch::dealDamage(unsigned int power, int x)
{
	for (unsigned int i = 0; i < mPlayers.size(); i++)
	{
		if (mPlayers[i].getLocation() < (int)( x + power )&& mPlayers[i].getLocation() > (int)(x - power))
		{
			mPlayers[i].takeDamage(abs( x- mPlayers[i].getLocation()) * 3);
		}
		
	}
	
}

// INQUIRY

///////////////////////////////////////////////////////////////////////
/// y_terrain returns a y based on the x
/// \pre    A valid Player
/// \post   none
/// \param  an int containing x in question
/// \return an int containing the y information
/// \throw  None
///////////////////////////////////////////////////////////////////////
int Scorch::y_terrain(int x )
{
	return mTerrain[x];
}

///////////////////////////////////////////////////////////////////////
/// returnTerrain returns the entire terrain vector
/// \pre    A valid Player
/// \post   none
/// \param  none
/// \return a vect of ints containing the y information
/// \throw  None
///////////////////////////////////////////////////////////////////////
std::vector<unsigned int> Scorch::returnTerrain( void)
{
	return mTerrain;
}

///////////////////////////////////////////////////////////////////////
/// returnTankLocations returns all the tanks location in a vector of ints
/// \pre    A valid Player
/// \post   none
/// \param  none
/// \return a vector containing all of the locations of the players
/// \throw  None
///////////////////////////////////////////////////////////////////////
std::vector<int> Scorch::returnTankLocations(void )
{
	std::vector<int> tank_loc;
	for (unsigned int i = 0; i < mPlayers.size(); i++)
	{
		tank_loc.push_back(mPlayers[i].getLocation());
	}
	return tank_loc;
}

///////////////////////////////////////////////////////////////////////
/// playersAlive returns a bool vector of people still alive
/// \pre    A valid Player
/// \post   none
/// \param  none
/// \return a vector containing true or false based on players life
/// \throw  None
///////////////////////////////////////////////////////////////////////
std::vector<bool> Scorch::playersAlive(void )
{
	std::vector<bool> tank_loc;
	for (unsigned int i = 0; i < mPlayers.size(); i++)
	{
		tank_loc.push_back(mPlayers[i].isAlive());
	}
	return tank_loc;
}

///////////////////////////////////////////////////////////////////////
/// lastAngle returns the last angle of each tank
/// \pre    A valid Player
/// \post   none
/// \param  none
/// \return a vector containing the players last angle fired
/// \throw  None
///////////////////////////////////////////////////////////////////////
std::vector<int> Scorch::lastAngle(void )
{
	return mLastAngle;
}

///////////////////////////////////////////////////////////////////////
/// isTurn returns a bool if it is that player numbers turn
/// \pre    A valid scorch with at least 2 players
/// \post   none
/// \param  none
/// \return a vector containing the players last angle fired
/// \throw  None
///////////////////////////////////////////////////////////////////////
bool Scorch::isTurn(int i )
{
	if ((unsigned int)i == mTurn % mPlayers.size())
	{
		return true;
	}
	else 
	{
		return false;
	}
}

///////////////////////////////////////////////////////////////////////
/// isGameOver returns a bool if the game is over
/// \pre    A valid scorch has been started
/// \post   none
/// \param  none
/// \return bool if game is over or not
/// \throw  None
///////////////////////////////////////////////////////////////////////
bool Scorch::isGameOver()
{
	int players_left_alive = 0;
	for (unsigned int i = 0;i < playersAlive().size(); i++)
	{
		if (playersAlive()[i] == true)
		{
			players_left_alive++;
		}
	}
	return (players_left_alive < 2);
}

///////////////////////////////////////////////////////////////////////
/// infoString returns info about the game
/// \pre    A valid Player
/// \post   none
/// \param  none
/// \return a string containing the information for all of the players
/// \throw  None
///////////////////////////////////////////////////////////////////////
std::string Scorch::infoString(void )
{
	std::stringstream info;
	for (unsigned int i = 0; i < mPlayers.size(); i++)
	{
		if (mPlayers[i].isAlive() == false)
		{
			info << "*DEAD*" << mPlayers[i].name(); 
		}
		
		if (i == mTurn % mPlayers.size())
		{
			info << "*Current Turn*";
		}
		info << mPlayers[i].name() << " ";
		info << "Hp: " << mPlayers[i].hitPoints() << " Fuel Remaining: " << mPlayers[i].getFuelRemaining();
		info << "\n";
	}
	info << "\n";
	std::string return_info = info.str();
	return return_info;
}
