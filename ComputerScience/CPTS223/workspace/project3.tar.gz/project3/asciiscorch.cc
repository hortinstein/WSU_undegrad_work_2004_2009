///////////////////////////////////////////////////////////////////////////////
/// \author       Alex Hortin
/// \date         2/28/06
/// \brief        A simple GUI implementation of HandOfCards 
///
/// I am creating a GUI that tests out Card and HandOfCards, as well as the
/// templated linked list that they are contained in.
///
/// REVISION HISTORY:
///
/// NONE
///            
///////////////////////////////////////////////////////////////////////////////

// INCLUDES

#include "Scorch.h"
#include <FL/Fl.H>
// FUNCTIONS

int main(void)
{
	Scorch game;
	std::cout <<"******************* SCORCH TESTS *******************" << std::endl;
	std::cout <<"1) Adding three Players, Chris, Alex, and Kelly, than setting their locations to 200, 400, and 600 respectively.  Than Outputing the infostring containing the data for all players present." << std::endl;
	game.addPlayer("Alex Hortin", 200);
	game.addPlayer("Chris Mallory", 400);
	game.addPlayer("Kelly Fitz", 600);
	std::cout << game.infoString();
	std::cout <<"TEST PASSED" << std::endl << std::endl;
	std::cout <<"2) Now seeding the terrain for a time_t, that will be used to build the random terrain on each computer (function used to seed so everyone's terrain will be the same when generating over a network game" << std::endl;
	time_t seed = game.seedTerrainRand();
	std::cout << seed << std::endl;
	std::cout <<"TEST PASSED" << std::endl << std::endl;
	std::cout <<"3) Now building terrain using sinusoidal function based on a constant seed same terrain for testing" << std::endl;
	game.buildTerrain(0);
	std::cout <<"TEST PASSED" << std::endl << std::endl;
	std::cout <<"4) Since the terrain is stored in a vector if ints representing heights, and players locations were given in x they are located at the level given for that x representing the height of the terrain.  The game is now ready to begin.  After each fire the terrain is modified and damage is dealt if within range of a player charecter.  It should land at 214 283.  It should be chris's turn" << std::endl;
	
	std::vector<Scorch::x_y> line_shot = game.fire(30, 45, 20);
	std::cout << line_shot[0].x << " " << line_shot[0].y << std::endl;
	std::cout << game.infoString();
	std::cout <<"TEST PASSED" << std::endl << std::endl;
	std::cout <<"5) Checking Terrain for modification the original was 283, now is:" << std::endl;
	std::cout << game.y_terrain(214) << std::endl;
	std::cout <<"TEST PASSED" << std::endl << std::endl;
	
	std::cout <<"6) Chris will die, by shooting the largest shot and hitting himself, and you will see his reduction in HP when the game info string comes up and it will be kelly's turn.  His fuel will be used by useFuel, and HP reduced by dealDamage" << std::endl;
	game.fire(0, 0, 100);
	std::cout << game.infoString();
	std::cout <<"TEST PASSED" << std::endl << std::endl;
	std::cout <<"7) now firing a few more times to show dead people are skipped" << std::endl;
	game.fire(0, 0, 2);
	std::cout << game.infoString();
	game.fire(0, 0, 2);
	std::cout << game.infoString();
	game.fire(0, 0, 2);
	std::cout << game.infoString();
	std::cout <<"TEST PASSED" << std::endl << std::endl;
	
	std::cout <<"run 'make window' to see the fltk version for more testing" << std::endl << std::endl;
}
