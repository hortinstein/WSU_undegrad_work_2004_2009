///////////////////////////////////////////////////////////////////////////////
/// \class        Player
/// \author       Alex Hortin 
/// \date         March 20 2006
/// \brief        A class that stores a players details
///
/// This class stores a players details and can modify HP, award XP, save the
/// the level and skills of that player.
///
/// REVISION HISTORY
///
/// None
///
///////////////////////////////////////////////////////////////////////////////

// SYSTEM INCLUDES
//

#include <iostream>
#include <fstream>
#include <stdexcept>
#include <string>
// LOCAL INCLUDES
//
#include "Player.h"//the node to be defined

// FORWARD REFERENCES
//

// CONSTANTS
//   
	
// LIFECYCLE

///////////////////////////////////////////////////////////////////////
/// Default constructor.
/// \pre    None
/// \post   An instance of player is constructed and new stats file will be contructed
/// \param  string for the username
/// \throw  None
///////////////////////////////////////////////////////////////////////
Player::Player(std::string name)
{
	mName = name;
	mHitPoints = 100;
	mFuel = 1000;
	mLocation = 0;
	
}

// OPERATORS

// OPERATIONS

///////////////////////////////////////////////////////////////////////
/// takeDamage deals damage to the player
/// \pre    A valid Player
/// \post   hitpoints are reduced
/// \param  int for the value of the Hit Points to take away
/// \return true or false based on whether or not
/// \throw  None
///////////////////////////////////////////////////////////////////////
void Player::takeDamage( int hp )
{
	mHitPoints -= hp;
	if (mHitPoints <= 0)
	{
		mHitPoints = 0;
		mFuel = 0;
	}
}

///////////////////////////////////////////////////////////////////////
/// useFuel takes fuel away from a player
/// \pre    A valid Player
/// \post   fuel is reduced by the param
/// \param  int for the x value of the Hit Points
/// \return none
/// \throw  None
///////////////////////////////////////////////////////////////////////
void Player::useFuel( int fuel )
{
	mFuel -= fuel;
	if (mFuel <= 0)
	{
		mHitPoints = 0;
		mFuel = 0;
	}
}

///////////////////////////////////////////////////////////////////////	
/// setLocation sets the location of a player
/// \pre    A valid Player
/// \post   hitpoints are gained or reduced
/// \param  int for the x value of the Hit Points
/// \return none
/// \throw  None
///////////////////////////////////////////////////////////////////////
void Player::setLocation( int x )
{
	mLocation = x;
}

// ACCESS and MUTATE

// INQUIRY

///////////////////////////////////////////////////////////////////////
/// name returns the name of the player
/// \pre    A valid Player
/// \post   none
/// \param  none
/// \return a string containing the name
/// \throw  None
///////////////////////////////////////////////////////////////////////
std::string Player::name( void ) const
{
	return mName;
}

///////////////////////////////////////////////////////////////////////
/// getLocation returns the location 
/// \pre    A valid Player
/// \post   none
/// \param  none
/// \return int for the x value of the location
/// \throw  None
///////////////////////////////////////////////////////////////////////
int Player::getLocation( ) const 
{
	return mLocation;
}

///////////////////////////////////////////////////////////////////////
/// hitPoints returns the ammount of remaining hitpoints
/// \pre    A valid Player
/// \post   none
/// \param  none
/// \return int for the x Hit Points Left
/// \throw  None
///////////////////////////////////////////////////////////////////////
int Player::hitPoints( void ) const 
{
	return mHitPoints;
}

///////////////////////////////////////////////////////////////////////
/// isAlive returns if the player is alive or not
/// \pre    A valid Player
/// \post   none
/// \param  none
/// \return a bool true if alive, false if dead
/// \throw  None
///////////////////////////////////////////////////////////////////////
bool Player::isAlive( void ) const 
{
	if (mHitPoints > 0)
	{
		return true;
	}
	else
	{
		return false;
	}
}

///////////////////////////////////////////////////////////////////////
/// getFuelRemaining returns the ammount of fuel remaining
/// \pre    A valid Player
/// \post   none
/// \param  none
/// \return int for the x value of the remaining fuel
/// \throw  None
///////////////////////////////////////////////////////////////////////
int Player::getFuelRemaining(void ) const 
{
	return mFuel;
}
