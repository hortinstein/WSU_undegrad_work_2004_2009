///////////////////////////////////////////////////////////////////////////////
/// \class        Socket
/// \author       Chris Mallery
/// \date         22 March 2006
/// \brief        Provides simple point-to-point communication over TCP/IP.
///
/// Use an instance of this class to set up a communication link with
/// a nother program over TCP/IP. 
/// 
/// This class requires the FLTK library, because it supports a 
/// blocking receive that keeps FLTK applications alive by calling
/// Fl::check repeatedly, so that the GUI won't freeze while the
/// Socket is waiting to receive a message. 
///
/// REVISION HISTORY:
///
/// 22 March   creation and uglification by Mallery
/// 24 March   documentation by Fitz
///            
///////////////////////////////////////////////////////////////////////////////
#include "Socket.h"

// SYSTEM INCLUDES
//
#include <sys/socket.h>
#include <arpa/inet.h>
#include <unistd.h>

#include <algorithm>
using std::find;

#include <cstring>
using std::memset;

#include <iostream>
using std::cout;
using std::endl;

#include <stdexcept>
using std::domain_error;
using std::runtime_error;

#include <string>
using std::string;

#include <vector>
using std::vector;

#include <FL/Fl.h>   // for Fl::check

// LOCAL INCLUDES
//

// PUBLIC 

// LIFECYCLE 

///////////////////////////////////////////////////////////////////////
/// Default constructor.
/// Construct a new Socket that is not connected to anything.
///////////////////////////////////////////////////////////////////////
Socket::Socket( void ) : 
   mServSock(-1), 
   mClntSock(-1), 
   mLastIsComplete(true)
{
   memset( &mServAddr, 0, sizeof(mServAddr) );
   memset( &mServAddr, 0, sizeof(mClntAddr) );
}

///////////////////////////////////////////////////////////////////////
/// Destructor
/// Clean up by disconnecting this socket from anything 
/// it might be connected to.
///////////////////////////////////////////////////////////////////////
Socket::~Socket( void )
{
   if (-1 != mServSock )
   {
      close( mServSock );
   }
   if ( -1 != mClntSock )
   {
      close( mClntSock );
   }
}  
   
// OPERATIONS 

///////////////////////////////////////////////////////////////////////
/// listen
///
/// Start up a server listening on the specified port for 
/// a client to connect. Returns only after a client 
/// has connected. Only a server should call this.
///
/// This function does not return until a connection is
/// made, but it does call Fl::check so that FLTK apps
/// stay active (including callbacks) and do not freeze up
/// while awaiting the connection. 
///
/// \param portNumber the number of the port over which
///        to communicate, try something bigger than 1024
///        and smaller than 9999.  
/// \throw std::runtime_error if the port cannot be used.
///////////////////////////////////////////////////////////////////////
void Socket::listen( unsigned int portNumber )
{
   if( ( mServSock = socket( PF_INET, SOCK_STREAM, IPPROTO_TCP ) ) < 0 )
   {
      throw runtime_error("Unable to create socket!");
   }
   
   int yes = 1;   // no. Hah hah, just kidding!
   setsockopt( mServSock, SOL_SOCKET, SO_REUSEADDR, &yes, sizeof(int) );
   
   mServAddr.sin_family = AF_INET;
   mServAddr.sin_addr.s_addr = htonl( INADDR_ANY );
   mServAddr.sin_port = htons( portNumber );
   
   if ( bind( mServSock, (struct sockaddr *) &mServAddr, sizeof(mServAddr) ) < 0 )
   {
      throw runtime_error("Failed to bind server port");
   }
      
   if ( ::listen( mServSock, MSG_DONTWAIT ) < 0 )
   {
      throw runtime_error("Failed to listen on server port");
   }
      
   unsigned int clntLen = sizeof(mClntAddr);
   
   while ( ( mClntSock = accept( mServSock, (struct sockaddr *) &mClntAddr, &clntLen ) ) < 0 )
   {
      Fl::check();
   }
   
   close ( mServSock );
   mServSock = -1;
}

///////////////////////////////////////////////////////////////////////
/// connect
///
/// Connect to a server at the specified IP address 
/// (use 127.0.0.1 for the if the server is on the
/// same computer as the client) that is listening
/// on the specified port. Returns after a connection
/// has been made to the server. Only a client should
/// call this.
///
/// This function does not wait around for a connection.
/// If a server is available, a connection is made 
/// immediately. If not, an exception is thrown.
///
/// \param ipAddress the IP address of the computer on
///        which the server is running, use 127.0.0.1
///        for the local host
/// \param portNumber the number of the port over which
///        to communicate, try something bigger than 1024
///        and smaller than 9999.  
/// \throw std::runtime_error if a socket cannot be created
///        or if no server is listening on the specified
///        port at the specified IP address
///////////////////////////////////////////////////////////////////////
void Socket::connect(std::string ipAddress, unsigned int portNumber)
{
   if( ( mClntSock = socket( PF_INET, SOCK_STREAM, IPPROTO_TCP) ) < 0 )
   {
      throw runtime_error ("Unable to create socket!");
   }
      
   mClntAddr.sin_family = AF_INET;
   mClntAddr.sin_addr.s_addr = inet_addr(ipAddress.c_str());
   mClntAddr.sin_port = htons(portNumber);
   
   if ( ::connect( mClntSock, (struct sockaddr *) &mClntAddr, sizeof(mClntAddr) ) < 0 )
   {
      throw runtime_error("Failed to connect to server!");
   }
}
   
///////////////////////////////////////////////////////////////////////
/// send
///
/// Send a message over an established connection (either
/// from server to client, or from client to server). 
/// There must be a connection established before 
/// anything can be sent.
/// 
/// \pre   message must be shorter than 1024 characters
/// \pre   the Socket must be connected (using listen/connect)
/// \param message the message to send, formated as a
///        sequence of characters that do not include '\0'.
/// \throw std::domain_error if the message is longer than
///        1023 characters
/// \throw std::runtime_error if the message cannot be 
///        sent (due to some network problem, or because
///        there is no connection)
///////////////////////////////////////////////////////////////////////
void Socket::send( string message )
{
   if ( message.size() > 1023 )
   {
      throw domain_error("Message too long!");
   }
   vector<char> temp(message.begin(), message.end());
   temp.push_back('\0');
   
   if ( ::send( mClntSock, &temp.front(), temp.size(), 0 ) != (int)temp.size() )
   {  
      throw runtime_error("Sending message failed!");
   }
}
   
///////////////////////////////////////////////////////////////////////
/// recv (receive)
///
/// Wait for a message to arrive over an established
/// connection (from server to client, or from client 
/// to server). Returns only after a message has been 
/// received. If keepFltkAlive is true (the default)
/// then call Fl::check while waiting for the message
/// to arrive, so that FLTK apps stay active (including 
/// callbacks) and do not freeze up while waiting. 
///
/// \pre    the Socket must be connected (using listen/connect)
/// \param  keepFltkAlive if true (the default), FLTK apps
///         are kept alive while waiting for a message by
///         calls to Fl::check.
/// \return a string storing the message received
///////////////////////////////////////////////////////////////////////
string Socket::recv( bool keepFltkAlive )
{
   int bytesRecv = 0;
   char buffer[1024];

   while ( mRcvdMessages.size() == 0 ||  
          ( mRcvdMessages.size() == 1 && mLastIsComplete == false ) )
   {
      if ( ( bytesRecv = ::recv( mClntSock, buffer, 1024, MSG_DONTWAIT ) ) > 0 )
      {
         string msg;

         if ( mLastIsComplete == false )
         {
            msg = mRcvdMessages.back();
            mRcvdMessages.pop_back();
         }
         
         char* msgBegin = buffer;
         char* null;
         
         while( msgBegin != buffer + bytesRecv )
         {
            null = find( msgBegin, buffer + bytesRecv, '\0' );
            mRcvdMessages.push_back( string(msgBegin, null) );
            if ( null != buffer + bytesRecv )
            {
               mLastIsComplete = true;
               ++null;
            }
            else
            {
               mLastIsComplete = false;
            }
            msgBegin = null;
         } 
      }
      
      if( keepFltkAlive )
      {
         Fl::check();
      }
   }

   string nextMessage = mRcvdMessages.front();
   mRcvdMessages.pop_front();
   
   return nextMessage;
}

// PRIVATE  

// --- don't use these, they don't seem to work ---

Socket::Socket(const Socket& rhs)
{
   if (rhs.mClntSock != -1)
   {
      mClntSock = dup(rhs.mClntSock);
   }
   else
   {
      mServSock = -1;
   }

   if (rhs.mServSock != -1)
   {
      mServSock = dup(rhs.mServSock);
   }
   else
   {
      mServSock = -1;
   }

   mServAddr = rhs.mServAddr;
   mClntAddr = rhs.mClntAddr;
}

Socket& Socket::operator=(const Socket& rhs)
{
   if (&rhs == this)
      return *this;

   if (rhs.mClntSock != -1)
   {
      mClntSock = dup(rhs.mClntSock);
   }

   if (rhs.mServSock != -1)
   {
      mServSock = dup(rhs.mServSock);
   }

   mServAddr = rhs.mServAddr;
   mClntAddr = rhs.mClntAddr;

   return *this;

}
