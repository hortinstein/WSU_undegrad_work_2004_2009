///////////////////////////////////////////////////////////////////////////////
/// \class        ServerConnection
/// \author       Alex Hortin 
/// \date         April 3 2006
/// \brief        A polymorphic class that handles communication
///
/// All this class is is a polymorphic container class for chris's class that
/// that handles all of my communication for me.  This inherits 
///
/// REVISION HISTORY
///
/// None
///
///////////////////////////////////////////////////////////////////////////////

// SYSTEM INCLUDES
//

#include <iostream>
#include <fstream>
#include <stdexcept>
#include <string>
#include <sstream>
#include <stdlib.h>
#include <time.h>
// LOCAL INCLUDES
//
#include "Connection.h"//the node to be defined
#include "ServerConnection.h"//the node to be defined
#include "Socket.h"
// FORWARD REFERENCES
//

// CONSTANTS
//

///////////////////////////////////////////////////////////////////////
/// Default constructor.
/// \pre    None
/// \post   An instance of player is constructed and new stats file will be contructed
/// \param  string for the username
/// \throw  None
///////////////////////////////////////////////////////////////////////
ServerConnection::ServerConnection(int players)
{
	mNumOfPlayers = players;
	mSeed = time(0);
	mCurrentTurn = 0;
}

///////////////////////////////////////////////////////////////////////
/// Destructor.
/// \pre    There must be something to destroy
/// \post   Poof! that virtual bitch is gone!
///////////////////////////////////////////////////////////////////////
ServerConnection::~ServerConnection( void )
{
}
// OPERATORS

// OPERATIONS

///////////////////////////////////////////////////////////////////////
/// makeConnection makes the connections between all the players and the server, it is polymorphic
/// \pre    a connection class with a type is made
/// \post   All the connections will be made
/// \param  none
/// \return none
/// \throw  None
///////////////////////////////////////////////////////////////////////
void ServerConnection::makeConnection(std::string username)
{
	mUserName = username;
	mMyTurnNumber = 0;
	
	int clients = 0;
	Socket mLogin;
	while (clients < mNumOfPlayers)
	{
		Socket * NewConnection = new Socket;
		mLogin.listen(9931);//listening on login port
		
		std::stringstream port;
		clients++;//incrimenting clients
		port << (9931 + clients);//setting the port string
 		std::cout << "Login Detected, sending dedicated port" <<  port.str() << std::endl;
		mLogin.send(port.str());//sending dedicated port to client
		
		mConnections.push_back(NewConnection);
		mConnections[clients - 1]->listen(9931 + clients);
		std::stringstream msg;
		msg << clients;
		mConnections[clients - 1]->send(msg.str());
	}
	for (unsigned int i = 0; i < mConnections.size();i++)
	{
		mConnections[i]->send("Everyone is Connected");
	}
	mNumOfPlayers = clients;
	std::stringstream seed;
	seed << mSeed;
	for (unsigned int i = 0; i < mConnections.size();i++)
	{
		std::cout << "sending client: " << i << " seed:" << mSeed << " to store locally" << std::endl;
		mConnections[i]->send(seed.str());
	}
	
}

///////////////////////////////////////////////////////////////////////
/// setupGame this sets up the game and exchanges the data so everyone knows usernames and locations
/// \pre    A connection with everyone present
/// \post   all clients will be sent the server data
/// \param  none
/// \return none
/// \throw  None
///////////////////////////////////////////////////////////////////////
void ServerConnection::setupGame(int location)
{
	//syncronising user names
	mNames.push_back(mUserName);
	for (unsigned int i = 0; i < mConnections.size();i++)
	{
		mConnections[i]->send(mUserName);
		std::cout << "sending server username: " << mUserName << " to client: " << i << std::endl;
	}	
	for (unsigned int i = 0; i < mConnections.size();i++)
	{
		mConnections[i]->send("send");
		std::cout << "asking client: " << i << "for username" << std::endl;
		std::string user_sent_name = mConnections[i]->recv(true);	
		std::cout << "recieved: " << user_sent_name << " as username" << std::endl;
		mNames.push_back(user_sent_name);
		for (unsigned int i1 = 0; i1 < mConnections.size();i1++)
		{
			std::cout << "sending client" << i1 << " " << user_sent_name << " to store locally" << std::endl;
			mConnections[i1]->send(user_sent_name);
		}
	}
	for (unsigned int i = 0; i < mConnections.size();i++)
	{
		mConnections[i]->send("endnameset");
		std::cout << "sending clients 'endnameset' to show that it is done with use names" << std::endl;
	}	
	
	
	//syncronising tank locations
	mLocations.push_back(location);
	for (unsigned int i = 0; i < mConnections.size();i++)
	{
		std::stringstream loc_ss;
		loc_ss << location;
		mConnections[i]->send(loc_ss.str());
		std::cout << "sending server username: " << location << " to client: " << i << std::endl;
	}	
	for (unsigned int i = 0; i < mConnections.size();i++)
	{
		mConnections[i]->send("send");
		std::cout << "asking client: " << i << "for location" << std::endl;
		int user_sent_loc = atoi(mConnections[i]->recv(true).c_str());	
		std::cout << "recieved: " << user_sent_loc << " as location" << std::endl;
		mLocations.push_back(user_sent_loc);
		for (unsigned int i1 = 0; i1 < mConnections.size();i1++)
		{
			std::cout << "sending client" << i1 << " " << user_sent_loc << " to store locally" << std::endl;
			std::stringstream user_loc_ss;
			user_loc_ss << user_sent_loc;
			mConnections[i1]->send(user_loc_ss.str());
		}
	}
	for (unsigned int i = 0; i < mConnections.size();i++)
	{
		mConnections[i]->send("endlocationset");
		std::cout << "sending clients 'endlocationset' to show that it is done with use names" << std::endl;
	}
}

///////////////////////////////////////////////////////////////////////
/// isReady returns after all clients and the server have called this function
/// \pre    A connection with everyone present and game is set up and locations are filled
/// \post   The game will start
/// \param  none
/// \return none
/// \throw  None
///////////////////////////////////////////////////////////////////////
void ServerConnection::isReady()
{	
	for (unsigned int i = 0; i < mConnections.size();i++)
	{
		mConnections[i]->send("start");
	}	
}

///////////////////////////////////////////////////////////////////////
/// sendMyTurn a polymorphic function to send everyone a turn, the server than relays
/// \pre    A connection with everyone present and game is set up and locations are filled
/// \post   The game will start
/// \param  none
/// \return none
/// \throw  None
///////////////////////////////////////////////////////////////////////
Connection::Shot ServerConnection::sendMyTurn(Shot theShot)
{
	std::stringstream myShot;
	myShot << theShot.power << " " << theShot.angle << " " << theShot.payload << " " << theShot.left << " " << theShot.right;
	for (unsigned int i = 0; i < mConnections.size();i++)
	{
		std::cout << "Sending Shot of Power: " << theShot.power << " Angle: " << theShot.angle << " Payload:" << theShot.payload << " to clients " << i << std::endl;
		mConnections[i]->send(myShot.str());
	}
	return theShot;
}

///////////////////////////////////////////////////////////////////////
/// waitForData is the function that waits for the server to relay the turns to everyone
/// \pre    A connection with everyone present and game is set up and locations are filled
/// \post   The game will start
/// \param  none
/// \return none
/// \throw  None
///////////////////////////////////////////////////////////////////////
Connection::Shot ServerConnection::waitForData()
{
	std::cout << "waiting for shot to be sent by player: " << (mCurrentTurn % mNumOfPlayers) + 1 << std::endl;
	Connection::Shot recShot;
	std::stringstream recShotS; 
	recShotS << (mConnections[mCurrentTurn % mNumOfPlayers]->recv(true));
	int tempPower;
	int tempAngle;
	int tempPayload;
	int templeft;
	int tempright;
	recShotS >> tempPower >> tempAngle >> tempPayload >> templeft >> tempright;
	recShot.power = tempPower;
	recShot.angle = tempAngle;
	recShot.payload = tempPayload;
	recShot.left = templeft;
	recShot.right = tempright;
	
	for (unsigned int i = 0; i < mConnections.size();i++)
	{
		std::cout << "Sending Shot of Power: " << recShot.power << " Angle: " << recShot.angle << " Payload:" << recShot.payload << " to clients " << i << std::endl;
		mConnections[i]->send(recShotS.str());
	}
	mCurrentTurn++;
	
	return recShot;
}
	
// ACCESS and MUTATE
	
// INQUIRY
	
// ACCESS and MUTATE
	
// INQUIRY
	
// MEMBER VARIABLES