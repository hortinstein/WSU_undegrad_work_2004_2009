///////////////////////////////////////////////////////////////////////////////
/// \author       Alex Hortin
/// \date         4/3/06
/// \brief        A simple program to test out the network stuff
///
/// I am creating this to test the simple network for the client
///
/// REVISION HISTORY:
///
/// NONE
///            
///////////////////////////////////////////////////////////////////////////////

// INCLUDES

#include "Connection.h"
#include "ServerConnection.h"
#include "ClientConnection.h"
// FUNCTIONS

int main(void)
{
	std::cout << "To Finish testing this open up 2 other terminals and type ./Client and ./Client2 : these will all simulate networked turns" << std::endl;
	Connection* try_connect = new ServerConnection(2);
	try_connect->makeConnection("Gandalf");

	try_connect->setupGame(100);
	
	std::cout << std::endl << std::endl;
	for(unsigned int i = 0; i < try_connect->getPlayerNames().size(); i++)
	{
		std::cout << try_connect->getPlayerNames()[i] << " " << try_connect->getPlayerLocations()[i] << std::endl;
	}
	for (int i = 0; i < 6; i++)
	{
		if (try_connect->isMyTurn(i%3))
		{
			Connection::Shot tShot;
			tShot.power = 100;
			tShot.angle = 90;
			tShot.payload = 10;
			tShot = try_connect->sendMyTurn(tShot);
			std::cout << "*******************************" << std::endl;
			std::cout << "Player " << i%3 << " fired a Shot of Power: " << tShot.power << " Angle: " << tShot.angle << " Payload:" << tShot.payload << std::endl;
			std::cout << "*******************************" << std::endl;
		}
		else
		{
			Connection::Shot tShot;
			tShot = try_connect->waitForData();
			std::cout << "*******************************" << std::endl;
			std::cout << "Player " << i%3 << " fired a Shot of Power: " << tShot.power << " Angle: " << tShot.angle << " Payload:" << tShot.payload<< std::endl;
			std::cout << "*******************************" << std::endl;
		}
	}
}
