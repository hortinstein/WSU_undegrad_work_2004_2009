///////////////////////////////////////////////////////////////////////////////
/// \author       Alex Hortin
/// \date         4/5/06
/// \brief        A simple GUI implementation of ConnectionWindow
///
/// I am creating a GUI that tests out ConnectionWindow
/// REVISION HISTORY:
///
/// NONE
///            
///////////////////////////////////////////////////////////////////////////////

// INCLUDES

#include "ConnectionWindow.h"
#include <FL/Fl.H>
// FUNCTIONS

int main(void)
{
	std::cout << "This is the login that will be used for each game and scorch will inherit from it" << std::endl;
	ConnectionWindow* Mw;
	Mw = new ConnectionWindow();
	return Fl::run();
	
}
