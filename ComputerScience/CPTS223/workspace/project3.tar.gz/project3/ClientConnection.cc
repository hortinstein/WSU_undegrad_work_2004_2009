///////////////////////////////////////////////////////////////////////////////
/// \class        ClientConnection
/// \author       Alex Hortin 
/// \date         April 3 2006
/// \brief        A polymorphic class that handles communication
///
/// All this class is is a polymorphic container class for chris's class that
/// that handles all of my communication for me.  This inherits 
///
/// REVISION HISTORY
///
/// None
///
///////////////////////////////////////////////////////////////////////////////

// SYSTEM INCLUDES
//

#include <iostream>
#include <fstream>
#include <stdexcept>
#include <string>
#include <sstream>
#include <stdlib.h>
#include <time.h>
// LOCAL INCLUDES
//
#include "Connection.h"//the node to be defined
#include "ClientConnection.h"//the node to be defined
#include "Socket.h"
// FORWARD REFERENCES
//

// CONSTANTS
//

// LIFECYCLE

///////////////////////////////////////////////////////////////////////
/// Default constructor.
/// \pre    None
/// \post   An instance of player is constructed and new stats file will be contructed
/// \param  string for the username
/// \throw  None
///////////////////////////////////////////////////////////////////////
ClientConnection::ClientConnection( std::string ip )
{
	mConnection = new Socket();
	mIP = ip;

}

///////////////////////////////////////////////////////////////////////
/// Destructor.
/// \pre    There must be something to destroy
/// \post   Poof! that virtual bitch is gone!
///////////////////////////////////////////////////////////////////////
ClientConnection::~ClientConnection( void )
{
}

// OPERATORS

// OPERATIONS

///////////////////////////////////////////////////////////////////////
/// makeConnection makes the connections between all the players and the server, it is polymorphic
/// \pre    a connection class with a type is made
/// \post   All the connections will be made
/// \param  none
/// \return none
/// \throw  None
///////////////////////////////////////////////////////////////////////
void ClientConnection::makeConnection(std::string username)
{
	mUserName = username;	

	mConnection->connect(mIP,9931);
	//std::cout << mConnection.recv(true) << std::endl;
	mConnection->connect(mIP,atoi(mConnection->recv(true).c_str()));
	mMyTurnNumber = (atoi(mConnection->recv(true).c_str()));
	std::cout << "You are the " << mMyTurnNumber << " to connect" << std::endl;
	std::cout << mConnection->recv(true) << std::endl;
	mSeed = atoi(mConnection->recv(true).c_str());
	std::cout <<" The Seed is: "<< mSeed << std::endl;
}

///////////////////////////////////////////////////////////////////////
/// setupGame this sets up the game and exchanges the data so everyone knows usernames and locations
/// \pre    A connection with everyone present
/// \post   all clients will be sent the server data
/// \param  none
/// \return none
/// \throw  None
///////////////////////////////////////////////////////////////////////
void ClientConnection::setupGame(int location)
{
	std::string rec;
	while(rec != "endnameset")
	{
		rec = mConnection->recv(true);
		std::cout << "recieved: " << rec << std::endl;
		if (rec == "send")
		{
			std::cout << "Sending User Name: " << mUserName << std::endl;
			mConnection->send(mUserName);
			//mNames.push_back(username);
		}
		else if (rec != "endnameset")
		{
			std::cout << "Adding: " << rec << " to user name vector" << std::endl;
			mNames.push_back(rec);
		}
	}
	while(rec != "endlocationset")
	{
		rec = mConnection->recv(true);
		std::cout << "recieved: " << rec << std::endl;
		if (rec == "send")
		{
			std::stringstream loc_ss;
			loc_ss << location;
			std::cout << "Sending location: " << loc_ss.str() << std::endl;
			mConnection->send(loc_ss.str());
		}
		else if (rec != "endlocationset")
		{
			std::cout << "Adding: " << rec << " to the location vector" << std::endl;
			mLocations.push_back(atoi(rec.c_str()));
		}
	}
	std::cout << "All Data Recieved" << std::endl;
	
	
}

///////////////////////////////////////////////////////////////////////
/// isReady returns after all clients and the server have called this function
/// \pre    A connection with everyone present and game is set up and locations are filled
/// \post   The game will start
/// \param  none
/// \return none
/// \throw  None
///////////////////////////////////////////////////////////////////////
void ClientConnection::isReady()
{
	if (mConnection->recv(true) == "start")
	{
		return;
	}
}


///////////////////////////////////////////////////////////////////////
/// sendMyTurn a polymorphic function to send everyone a turn, the server than relays
/// \pre    A connection with everyone present and game is set up and locations are filled
/// \post   The game will start
/// \param  none
/// \return none
/// \throw  None
///////////////////////////////////////////////////////////////////////
Connection::Shot ClientConnection::sendMyTurn(Connection::Shot theShot)
{
	std::stringstream myShot;
	myShot << theShot.power << " " << theShot.angle << " " << theShot.payload << " " << theShot.left << " " << theShot.right;
	std::cout << "Sending Shot of Power: " << theShot.power << " Angle: " << theShot.angle << " Payload:" << theShot.payload << " to server " << std::endl;
	mConnection->send(myShot.str());
	return waitForData();
}

///////////////////////////////////////////////////////////////////////
/// waitForData is the function that waits for the server to relay the turns to everyone
/// \pre    A connection with everyone present and game is set up and locations are filled
/// \post   The game will start
/// \param  none
/// \return none
/// \throw  None
///////////////////////////////////////////////////////////////////////
Connection::Shot ClientConnection::waitForData()
{
	Connection::Shot recShot;
	std::stringstream recShotS; 
	recShotS << (mConnection->recv(true));
	int tempPower;
	int tempAngle;
	int tempPayload;
	int templeft;
	int tempright;
	recShotS >> tempPower >> tempAngle >> tempPayload >> templeft >> tempright;
	recShot.power = tempPower;
	recShot.angle = tempAngle;
	recShot.payload = tempPayload;
	recShot.left = templeft;
	recShot.right = tempright;
	return recShot;
}
