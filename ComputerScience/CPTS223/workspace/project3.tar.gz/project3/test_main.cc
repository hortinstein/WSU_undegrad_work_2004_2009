///////////////////////////////////////////////////////////////////////////////
/// \author       Alex Hortin
/// \date         2/28/06
/// \brief        A simple GUI implementation of HandOfCards 
///
/// I am creating a GUI that tests out Card and HandOfCards, as well as the
/// templated linked list that they are contained in.
///
/// REVISION HISTORY:
///
/// NONE
///            
///////////////////////////////////////////////////////////////////////////////

// INCLUDES


#include "ConnectionWindow.h"
#include <FL/Fl.H>
// FUNCTIONS

int main(void)
{
	
	ConnectionWindow* Mw;
	Mw = new ConnectionWindow();
	return Fl::run();
	
	
}
