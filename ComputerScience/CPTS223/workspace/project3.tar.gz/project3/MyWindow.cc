///////////////////////////////////////////////////////////////////////////////
/// \class        Test_Win
/// \author       Alex Hortin
/// \date         3/20/06
/// \brief			This is a window that tests the Scorch
///
/// This Class is the window that you will see that contains all the work
/// behind the program interface.  It will display graphics for terrain, and
/// pop up error messages when nessecary.
///
///
/// REVISION HISTORY:
///
/// NONE
///
///////////////////////////////////////////////////////////////////////////////

// SYSTEM INCLUDES
//
#include <FL/Fl.H>//the FLTK source files
#include <FL/Fl_Window.H>//the FLTK source files
#include <FL/Fl_Button.H>//the FLTK source files
#include <FL/Fl_Input.H>//the FLTK source files
#include <FL/Fl_Output.H>//the FLTK source files
#include <FL/Fl_GIF_Image.h>//the FLTK gif class
#include <Fl/fl_ask.H>
#include <FL/fl_draw.H>
#include <FL/Fl_Output.H>//the FLTK source files
#include <FL/Fl_Multiline_Output.H>
#include <FL/Enumerations.H>
#include <string>//string.h include
#include <vector>//vector.h include
#include <stdio.h>
#include <sstream>
#include <unistd.h> 
#include <FL/Fl.H>
#include <FL/Fl_Double_Window.H>
#include <FL/Fl_Shared_Image.H>
#include <FL/Fl_JPEG_Image.H>
#include <FL/Fl_Box.H>
#include <FL/Fl_Dial.H>
#include <stdlib.h>
#include <stdexcept>
#include <math.h>

// LOCAL INCLUDES
//
#include "Scorch.h"//the sample sound player
#include "MyWindow.h"//this file!!!11!
#include "ConnectionWindow.h"

// FORWARD REFERENCES
//

// CONSTANTS
//

// LIFECYCLE
///////////////////////////////////////////////////////////////////////
/// Default constructor.
/// \pre    None
/// \post   An instance of the MyWindow is created.
/// \param  a connection and a user name
/// \throw  None
///////////////////////////////////////////////////////////////////////
MyWindow::MyWindow(Connection* connections, std::string username) : Fl_Double_Window(1200,600, "Test")
{
	mConnection = connections;
	mUserName = username;
	mFire = 					new Fl_Button (920, 380, 70, 30, "Fire");
	mGameInfo =				new Fl_Multiline_Output(820, 425, 360, 110, "");
	mPower = 				new Fl_Value_Slider(820, 80, 60,200, "Power");
	mPayload= 				new Fl_Value_Slider(1080, 80, 60,200, "Playload");
	mDial = 					new Fl_Dial(920,80, 120, 200,"Angle");
	mDial->type(FL_LINE_DIAL);
	mDial->angles((short)mAngle - 90,(short)mAngle - 90);
	
	mGame.buildTerrain(mConnection->getSeed());
	mFire->callback(cb_fire, this);
	mFire->hide();
	
	mAngle = 0;
	mGameStarted = false;
	mPlacement = false;
	mShotFired = false;
	mTempShot.left = 0;
	mTempShot.right = 0;
	line_shot.clear();
	
	redraw();
	this->show();
}

///////////////////////////////////////////////////////////////////////
/// Destructor.
/// \pre    An instance of MyWindow has been created.
/// \post   The instance of MyWindow is destroyed.
///////////////////////////////////////////////////////////////////////
MyWindow::~MyWindow()//the destructor
{
}

// OPERATORS

// OPERATIONS

// ACCESS and MUTATE

// INQUIRY

// MEMBER VARIABLES

// OPERATIONS

///////////////////////////////////////////////////////////////////////
/// draw draws all of the board including terrain and shots
/// \pre		None
/// \post   everything is redrawn
/// \param  None
/// \return none
/// \throw  None
///////////////////////////////////////////////////////////////////////
void MyWindow::draw(void)
{
	Fl_Window::draw(); 
	
	int fine_x = 0;
	int fine_y = 0;
	if (mGame.returnTerrain().size() == 800)
	{
		for (int i = 0; i < 800; i++)
		{
			fl_color(FL_CYAN);
			fl_line(i,0,i,600 ) ;
		}
	}
	//drawing the shot
	mGameInfo->value(mGame.infoString().c_str());
	if (line_shot.size() > 0 &&  mGameStarted == true)
	{
		fl_color(FL_BLACK);
		
		mGameInfo->value(mGame.infoString().c_str());
		unsigned int t = 0;
		while (t < line_shot.size())
		{
			fl_point(line_shot[t].x,600 - line_shot[t].y);
			t++;
			
		}
		fine_x = line_shot[line_shot.size()-1].x;
		fine_y = line_shot[line_shot.size()-1].y;
		
	}
	//drawing the terrain
	if (mGame.returnTerrain().size() == 800)
	{
		for (int i = 0; i < 800; i++)
		{
			//fl_color(40);//night sky
			//fl_color(175);//sunset sky
			fl_color(150);
			fl_line(i,600- (mGame.returnTerrain()[i]),i,600) ;
		}
	}
	
	//drawing the tank
	
	for(unsigned int i = 0; i< mGame.returnTankLocations().size(); i++)
	{
		std::stringstream info;
		info << "tank" << i << ".GIF";
		Fl_GIF_Image image( info.str().c_str() );
		int x_tank = mGame.returnTankLocations()[i];
		int y_tank = mGame.returnTerrain()[mGame.returnTankLocations()[i]];
		if (mGame.playersAlive()[i] == true)
		{
			image.draw(x_tank -25 ,550 - y_tank);
			//int angle_for_aim = (int)(mAngle->value() * 180);
			int angle_for_aim = 0;
			if (mGame.isTurn(i))
			{
				angle_for_aim = (int)(mAngle * 180);
			}
			else
			{
				angle_for_aim = mGame.lastAngle()[i];
			}
			fl_color(FL_BLACK);
			double y_line = y_tank + (sin( angle_for_aim * 3.14 / 180) * 20);
			double x_line = x_tank + (cos( angle_for_aim * 3.14 / 180) * 20);

			fl_line((int)x_tank,(int)(575 - y_tank), (int)x_line,(int)(575 - y_line)) ;
			if (line_shot.size() > 0 && mGameStarted == true && fine_x < 800 && fine_x > 0)
			{
				fl_color(FL_RED);
				fl_begin_polygon();
				fl_circle(fine_x, 600 - fine_y,mTempShot.payload);
				fl_end_polygon();
			}
		}
		
	}	
	if (mGame.isGameOver() == true) 
	{
		mFire->hide();
	}
	mShotFired = false;
	redraw();
}

///////////////////////////////////////////////////////////////////////
/// handle handles my mousewheel events for anglechange and placement and movement
/// \pre    a button is clicks
/// \post   a card is added
/// \param  the event number
/// \return the event number
/// \throw  None
///////////////////////////////////////////////////////////////////////
int MyWindow::handle(int event)
{ 
	int r = Fl_Window::handle(event);
	
	if (event == FL_MOUSEWHEEL && Fl::event_y() < 600 && Fl::event_x() < 800 && mGameStarted == true && mGame.isGameOver() == false && mGame.isTurn(mMyTurnNumber))
	{
		if ( Fl::event_dy() < 0)
		{
			if (mGame.moveLeft())
			{
				mTempShot.left++;
			}
		}
		if ( Fl::event_dy() > 0)
		{
			if (mGame.moveRight())
			{
				mTempShot.right++;
			}
		}
		redraw();
	}
	else if (event == FL_MOUSEWHEEL && mGameStarted == true && mGame.isTurn(mMyTurnNumber))
	{
		mAngle += .01 * Fl::event_dy();
		mDial->angles((int)(mAngle*-180 -90),(int)(mAngle*-180 -90));
		redraw();
	}
	else if (event == FL_RELEASE && mGameStarted == false && Fl::event_y() < 600 && Fl::event_x() < 790 && Fl::event_x() > 10)
	{
		
		redraw();
		mPlacement = true;
		mConnection->setupGame(Fl::event_x());
		for (unsigned int i = 0; mConnection->getPlayerNames().size() > i; i++)
		{
			mGame.addPlayer( mConnection->getPlayerNames()[i], mConnection->getPlayerLocations()[i]);
		}
		mGameStarted = true;
		int i = 0; 
		while (!mConnection->isMyTurn(i))
		{
			i++;
		}
		mMyTurnNumber = i;
		redraw();
		
		if (mGame.isTurn(mMyTurnNumber))
		{
			mFire->show();
		}
		else
		{
			this->cycleTurn();
		}
	}

	return r;
}

///////////////////////////////////////////////////////////////////////
/// cycleTurn wait for and registers firing
/// \pre    it is the players turn
/// \post   a card is added
/// \param  the event number
/// \return the event number
/// \throw  None
///////////////////////////////////////////////////////////////////////
void MyWindow::cycleTurn()
{
	if (mGame.isTurn(mMyTurnNumber) && mGameStarted == true)
	{
		mTempShot.power =(int) (mPower->value() * 100);
		mTempShot.angle = (int)(mAngle * 180);
		mTempShot.payload = (int) (mPayload->value() * 100);
		line_shot = mGame.fire(mTempShot.power,mTempShot.angle,mTempShot.payload);
		mTempShot = mConnection->sendMyTurn(mTempShot);
		mFire->hide();
		redraw();
	}
	
	while (! mGame.isTurn(mMyTurnNumber) && mGameStarted == true)
	{
		mTempShot = mConnection->waitForData();
		for (unsigned int i = 0; i < mTempShot.left; i++)
		{
			mGame.moveLeft();
		}
		for (unsigned int i = 0; i < mTempShot.right; i++)
		{
			mGame.moveRight();
		}
		mTempShot.right = 0;
		mTempShot.left = 0;
		line_shot = mGame.fire(mTempShot.power,mTempShot.angle,mTempShot.payload);
		mShotFired = true;
		redraw();
	}
	mFire->show();
}


// ACCESS and MUTATE

///////////////////////////////////////////////////////////////////////
/// cb_DrawTerrain is the call that the program makes when the DrawT errain button
/// is pressed.
/// \pre   None
/// \post  The terrain is mapped to the box
/// \param  a widget pointer
/// \return void
/// \throw  n/a
///////////////////////////////////////////////////////////////////////
void MyWindow::cb_DrawTerrain(Fl_Widget*, void* v)//the button 
{
	( (MyWindow*)v )->cb_DrawTerrain_i();
}

///////////////////////////////////////////////////////////////////////
/// cb_DrawTerrain is the call that the program makes when the DrawT errain button
/// is pressed.
/// \pre   None
/// \post  The terrain is mapped to the box
/// \param  a widget pointer
/// \return void
/// \throw  n/a
///////////////////////////////////////////////////////////////////////
void MyWindow::cb_DrawTerrain_i()//the call that the button makes
{
	time_t seed = mGame.seedTerrainRand();
	mGame.buildTerrain(seed);
	redraw();
}

///////////////////////////////////////////////////////////////////////
/// cb_fire is the call that the program makes when the DrawT errain button
/// is pressed.
/// \pre   None
/// \post  The terrain is mapped to the box
/// \param  a widget pointer
/// \return void
/// \throw  n/a
///////////////////////////////////////////////////////////////////////
void MyWindow::cb_fire(Fl_Widget*, void* v)//the button for tell me
{
	( (MyWindow*)v )->cb_fire_i();
}

///////////////////////////////////////////////////////////////////////
/// cb_fire_i is the call that the program makes when the Draw Terrain button
/// is pressed.
/// \pre   None
/// \post  The terrain is mapped to the box
/// \param  a widget pointer
/// \return void
/// \throw  n/a
///////////////////////////////////////////////////////////////////////
void MyWindow::cb_fire_i()//the call that the button makes
{
	mShotFired = true;
	mFire->hide();
	this->cycleTurn();
}

///////////////////////////////////////////////////////////////////////
/// cb_startgame is the call that the program makes when the startgame button
/// is pressed.
/// \pre   None
/// \post  the game starts
/// \param  a widget pointer
/// \return void
/// \throw  n/a
///////////////////////////////////////////////////////////////////////
void MyWindow::cb_startgame(Fl_Widget*, void* v)
{
	( (MyWindow*)v )->cb_startgame_i();
}

///////////////////////////////////////////////////////////////////////
/// cb_fire_i is the call that the program makes when the cb_startgame button
/// is pressed.
/// \pre   None
/// \post  the game starts
/// \param  a widget pointer
/// \return void
/// \throw  n/a
///////////////////////////////////////////////////////////////////////
void MyWindow::cb_startgame_i()
{
	mPlacement = 1;
	mStartGame->hide();
}