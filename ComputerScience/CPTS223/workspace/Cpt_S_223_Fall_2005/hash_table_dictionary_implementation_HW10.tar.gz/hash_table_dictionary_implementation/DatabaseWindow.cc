///////////////////////////////////////////////////////////////////////////////
/// \class        DatabaseWindow
/// \author       Alex Hortin
/// \date         10/25/05  
/// \brief        This class creates a Database window that inherits 
///               from the FLTK class and uses the templated Tree class.
///
/// This Class is the window that you will see that contains all the work 
/// behind the program interface.  It will create the file structure and put it
/// all into a tree. 
///
///       
/// REVISION HISTORY:
///
/// NONE
///            
///////////////////////////////////////////////////////////////////////////////

// SYSTEM INCLUDES
//

// LOCAL INCLUDES
// 
#include "Dictionary.h"
#include "DatabaseWindow.h"

// FORWARD REFERENCES
//


// CONSTANTS
//


// LIFECYCLE

///////////////////////////////////////////////////////////////////////
/// Default constructor.
/// \pre    None
/// \post   An instance of the DatabaseWindow is created.
/// \param  A string containing the name for a file.
/// \throw  None
///////////////////////////////////////////////////////////////////////
DatabaseWindow::DatabaseWindow (char * file_name):Fl_Window(300,500,"Photo Database")//the basic constructor used for testing
{
   begin();
      this->mDirectoryName = (file_name);
   
      buildDatabase(mDirectoryName);
      
      //mDatabase->print(mDatabase->root());
      
      mSearch = new Fl_Input(50, 20, 150, 30, "Query:");//defines the label and text box
      
      mSearchButton = new Fl_Button( 210, 20, 70, 30, "S&earch");//displays the button to tell
      mSearchButton->callback( cb_search, this );//calls the function after the button has been pressed
   
      mResults = new Fl_Hold_Browser(20, 60, 260, 300, "");//defines the answer box
      mResults->callback( cb_browser, this ); //callback
      mFileInfo = new Fl_Multiline_Output(20, 380, 260, 100, "");
   end();//ends the function
   show();//shows the window
      
}


///////////////////////////////////////////////////////////////////////
/// Destructor.
/// \pre    An instance of DatabaseWindow has been created.
/// \post   The instance of DatabaseWindow is destroyed.
///////////////////////////////////////////////////////////////////////
DatabaseWindow::~DatabaseWindow()//the destructor
{
   
}
// OPERATORS

// OPERATIONS 
  
///////////////////////////////////////////////////////////////////////  
/// convertMonth
/// \pre    Their must be a string given as an argument.
/// \post   A file structure contained in a tree is created and stored in this class.
/// \param  the string to convert
/// \return None
/// \throw  None
///////////////////////////////////////////////////////////////////////
std::string DatabaseWindow::convertMonth ( std::string monthconvert )
{
   switch (monthconvert[1])
   {
      case '1':
      return "january";
      break;
      
      case '2':
      return "febuary";
      break;
      
      case '3':
      return "march";
      break;
      
      case '4':
      return "april";
      break;
      
      case '5':
      return "may";
      break;
      
      case '6':
      return "june";
      break;
      
      case '7':
      return "july";
      break;
      
      case '8':
      return "august";
      break;
      
      case '9':
      return "september";
      break;
      
      case 'A':
      return "october";
      break;
      
      case 'B':
      return "november";
      break;
      
      case 'C':
      return "december";
      break;
      
   }
   return "";
}

///////////////////////////////////////////////////////////////////////
/// convertDate
/// \pre    Their must be a string given as an argument.
/// \post   A file structure contained in a tree is created and stored in this class.
/// \param  the string to convert
/// \return None
/// \throw  None
///////////////////////////////////////////////////////////////////////
std::string DatabaseWindow::convertDate ( std::string dateconvert )
{
   char new_chars[3];
   new_chars[0] = dateconvert[2];
   new_chars[1] = dateconvert[3];
   new_chars[2] = '\0';
   std::string new_string = new_chars;
   return new_string;
}
 
///////////////////////////////////////////////////////////////////////
/// buildDatabase
/// \pre    Their must be a directory given as a command line argument.
/// \post   A file structure contained in a tree is created and stored in this class.
/// \param  a folder name to search
/// \return None
/// \throw  None
///////////////////////////////////////////////////////////////////////
void DatabaseWindow::buildDatabase ( std::string pathName)
{
   DIR * dirp = opendir( pathName.c_str() );//creating the file stream
  
   if (dirp == NULL)
   {
      throw std::domain_error("OMFG WTFBBQ PWNT");
   }
   
   struct dirent * dp = readdir( dirp );
   while ( 0 != dp )//checking to make sure that these is still stuff in there
   {
      std::string name = dp->d_name;
      
      
      struct stat dpstats;
      stat( (pathName + '/' + name).c_str(), &dpstats );
      
      
      if (name[0] != '.')
      {
         if (S_ISDIR(dpstats.st_mode))//checking if the file pointer points to a directory
         {
            buildDatabase(pathName + '/' + name);//recursive call to keep on building directory
         }
         
         cPosition<std::string, Dictionary <int,std::string> > Pos = mDatabase.find(convertMonth(name));
  
         if (Pos.isNull())
         {
            Dictionary <int,std::string> p;
            mDatabase.insertItem(convertMonth(name),p);
            //std::cout << convertMonth(name) << std::endl;
            if (name.size() == 12 && name[8] == '.' && (name[9] == 'J' || name[9] == 'j') && (name[10] == 'P' || name[10] == 'p') && (name[11] == 'G' || name[11] == 'g'))  
            {
               std::string sdf;sdf += name[2]; sdf += name[3];
               int dfsd = atoi(sdf.c_str());
               ((mDatabase.find(convertMonth(name))).mPosition)->mElement.insertItem(dfsd,(pathName + "/" + name));
            }
         }
         else
         {
            if (name.size() == 12 && name[8] == '.' && (name[9] == 'J' || name[9] == 'j') && (name[10] == 'P' || name[10] == 'p') && (name[11] == 'G' || name[11] == 'g'))  
            {
               std::string sdf;sdf += name[2]; sdf += name[3];
               int dfsd = atoi(sdf.c_str());
               Pos.mPosition->mElement.insertItem(dfsd,(pathName + "/" + name));
            }
         }
      }
      dp = readdir( dirp );//moves pointer to next file or dir
   }
   
   closedir( dirp );//closes directry 
}

// ACCESS and MUTATE

///////////////////////////////////////////////////////////////////////      
/// cb_search is the call that the program makes when the search button 
/// is pressed.  It than calls a search of the tree for results.
/// \pre   the pre conditions for this is the button being pressed and a tree existing to search through 
/// \post  the mResults browser will be modified
/// \param  a widget pointer
/// \return void
/// \throw  n/a
///////////////////////////////////////////////////////////////////////
void DatabaseWindow::cb_search(Fl_Widget*, void* v)//the button for tell me
{
   ( (DatabaseWindow*)v )->cb_search_i();
}
///////////////////////////////////////////////////////////////////////
/// cb_search is the call that the program makes when the search button 
/// is pressed.  It than calls a search of the tree for results.
/// \pre   the pre conditions for this is the button being pressed and a tree existing to search through 
/// \post  the mResults browser will be modified
/// \param  a widget pointer
/// \return void
/// \throw  n/a
///////////////////////////////////////////////////////////////////////
inline void DatabaseWindow::cb_search_i()//the call that the button makes
{
   mResults->clear();
   hold_browser_ish.clear();
   std::string searching = (mSearch->value());  
   if (searching.size() != 0)
   {
      Dictionary<std::string, Dictionary<int,std::string> >::Position Post = this->mDatabase.find(searching);
      if (Post.isNull())
      {
         std::string date;
         date+=searching[0];
         date+=searching[1];
         
         std::string month;
         for (unsigned int i = 3; i < searching.size(); i++)
         {
            month+=searching[i];
         }
         Dictionary<std::string, Dictionary<int,std::string> >::Position Post = this->mDatabase.find(month);
         if (Post.isNull())
         {
            return;
         }
         
         cPositionIterator<int,std::string> Posts = Post.mPosition->mElement.findAll(atoi(date.c_str()));
         
         if (!Posts.hasNext())
         {
            return;
         }
         else
         {
            while (Posts.hasNext())
            {
               std::string temp = (Posts.next()).mPosition->mElement;
               std::string onoes;
               hold_browser_ish.push_back(temp);
               for (int i = 12; i >= 0; i--)
               {
                  onoes+=(temp[temp.size()-i]); 
               }
               mResults->add(onoes.c_str());
            }
         }
      }
      else
      {
         Dictionary<int,std::string>::ElementIterator ElemIt = Post.mPosition->mElement.elements();
         while (ElemIt.hasNext())
         {
            std::string temp = ElemIt.next();
            std::string onoes;
            hold_browser_ish.push_back(temp);
            for (int i = 12; i >= 0; i--)
            {
               onoes+=(temp[temp.size()-i]); 
            }
            mResults->add(onoes.c_str());
         }
      }
   }

}

///////////////////////////////////////////////////////////////////////
/// cb_browser is the call that the program makes when the search button 
/// is pressed.  It than calls a search of the tree for results.
/// \pre   the pre conditions for this is the button being pressed and a tree existing to search through 
/// \post  the mResults browser will be modified
/// \param  a widget pointer
/// \return void
/// \throw  n/a
///////////////////////////////////////////////////////////////////////
void DatabaseWindow::cb_browser(Fl_Widget*, void* v)//the button for tell me
{
   ( (DatabaseWindow*)v )->cb_browser_i();
}

///////////////////////////////////////////////////////////////////////
/// cb_browser is the call that the program makes when the search button 
/// is pressed.  It than calls a search of the tree for results.
/// \pre   the pre conditions for this is the button being pressed and a tree existing to search through 
/// \post  the mResults browser will be modified
/// \param  a widget pointer
/// \return void
/// \throw  n/a
///////////////////////////////////////////////////////////////////////
inline void DatabaseWindow::cb_browser_i()//the call that the button makes
{
   unsigned int compare_temp = (mResults->value()-1);
   if (compare_temp > hold_browser_ish.size())
   {
      return; 
   }
   std::string temp;
   for (unsigned int i = ((hold_browser_ish[mResults->value()-1].size()) - hold_browser_ish[mResults->value()-1].find(mDirectoryName,0)); i > 0; i--)
   {
      temp+=(hold_browser_ish[mResults->value()-1][(hold_browser_ish[mResults->value()-1].size()) - i]); 
   }
   struct stat dpstats;
   stat( hold_browser_ish[mResults->value() - 1].c_str(), &dpstats  );
   int size_int = (dpstats.st_size / 1024);
   
   
   char* woots = new char[20];
   sprintf(woots, "%d", size_int);
   
   std::string size_temp = woots;
   
   std::string file_mod = ctime(&dpstats.st_mtime);
   
   temp = temp + "\n" + "Size: " + size_temp + " k \n" + "Modified: " + file_mod;
   mFileInfo->value(temp.c_str());
   
   

}
// INQUIRY
