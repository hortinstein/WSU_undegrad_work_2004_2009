///////////////////////////////////////////////////////////////////////////////
/// \author       Alex Hortin
/// \date         9/19/05
/// \brief        This is the test file for my Vec class
///
/// It uses a variety of test cases to test the functionality of the Vec class.
/// It will create vectors with different sized elements, resize, and add
/// elements to demonstrait the complete functionality of these tests.
///
/// REVISION HISTORY:
///
/// date       Comment on what was changed. Separate entries with a blank line.
///            
///////////////////////////////////////////////////////////////////////////////


// SYSTEM INCLUDES
//
#include <iostream>
#include <string>


// LOCAL INCLUDES
//

#include "Vec.h"
#include "cs223Alg.h" 
using std::cout;
using std::endl;
using std::string;
typedef Vec< string > Vector;




int main( void )
{
    Vector h( 6 );  
   h[0] = "one";
   h[1] = "two";
   h[2] = "three";
   h[3] = "four";
   h[4] = "five";
   h[5] = "six";  

   cout << "USING RANGE ERASE vector contains:" << endl;
   for ( Vector::size_type i = 0; i < h.size(); ++i )
   {
      cout << h[i] << endl;
   }
   Vector::iterator temp = h.begin();
   temp++;
   h.erase(temp,h.end());
  
   
   cout << "now contains:" << endl;
   for ( Vector::size_type i = 0; i < h.size(); ++i )
   {
      cout << h[i] << endl;
   }
string s = "amanaplanacanalpanama";
cout << s;
if ( isPalindrome( s.begin(), s.end() ) )
{
  cout << " is a palindrome" << endl;
}
else
{
  cout << " is NOT a palindrome" << endl;
}

int a[] = { 1, 2, 3, 4, 5 };
for ( int * ptr = a; ptr != a + 5; ++ptr )
{
  cout << *ptr << " ";
}
if ( isPalindrome( a, a + 5 ) )
{
  cout << "is a palindrome" << endl;
}
else
{
  cout << "is NOT a palindrome" << endl;
}

cout << endl;
cout << endl;

cout << "sorting " << s << " gives ";
bubbleSort( s.begin(), s.end() );
cout << s << endl;

Vec< int > v( 5 );
std::reverse_copy(  a, a + 5, v.begin() );
cout << "sorting ";
for ( Vec< int >::iterator iter = v.begin(); iter != v.end(); ++iter )
{
  cout << *iter << " ";
}
cout << "gives ";
bubbleSort( v.begin(), v.end() );
for ( Vec< int >::iterator iter = v.begin(); iter != v.end(); ++iter )
{
  cout << *iter << " ";
}
cout << endl;
cout << endl;

int b[] = { 2, 4, 6, 8, 10, 9, 7, 5, 3 };
cout << "searching ";
for ( int * ptr = b; ptr != b + 9; ++ptr )
{
  cout << *ptr << " ";
}
cout << endl;
int N = 3;

int * pos = findNIf( b, b + 9, N, moreThanFive );
if ( pos != b + 9 )
{
  cout << "found " << N;
  cout << " elements more than five, beginning with ";
  cout << *pos << endl;
}
else
{
  cout << "found no sequence of " << N;
  cout << " elements more than five" << endl;
}

N = 7;
pos = findNIf( b, b + 9, N, moreThanFive );
if ( pos != b + 9 )
{
  cout << "found " << N;
  cout << " elements more than five, beginning with ";
  cout << *pos << endl;
}
else
{
  cout << "found no sequence of " << N;
  cout << " elements more than five" << endl;
}
   
   
   
}  
 