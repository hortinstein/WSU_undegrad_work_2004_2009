///////////////////////////////////////////////////////////////////////////////
/// \class        Node
/// \author       Alex Hortin
/// \date         10/17/05
/// \brief        A node that makes up part of a tree
///
/// This class is one the stores each individual part of the tree. It stores 
/// a element, a parent pointer, and an array of pointers to all of it's 
/// children. 
///       
/// REVISION HISTORY:
///
///   NONE
///         
///////////////////////////////////////////////////////////////////////////////
#include "Tree.h"                                // class implemented

// SYSTEM INCLUDES
//

// LOCAL INCLUDES
//

// PUBLIC 

// LIFECYCLE 

///////////////////////////////////////////////////////////////////////
/// Default constructor.
/// \pre    None
/// \post   An instance of the Node class is created.
/// \param  None
/// \throw  None
///////////////////////////////////////////////////////////////////////
cNode::cNode( void )
{
   mParent = NULL;
}

///////////////////////////////////////////////////////////////////////
/// Copy Constructor.
/// \pre    An instance of Node needs to be present.
/// \post   Two instances of the same Node will exist.
/// \param  Node is the Node to copy from.
/// \throw  None
///////////////////////////////////////////////////////////////////////
cNode::cNode( const cNode & from )
{
   mParent = from.mParent;
   mElement = from.mElement;
   mChildren = from.mChildren;
}

///////////////////////////////////////////////////////////////////////
/// Destructor.
/// \pre    An instance of Node has been created.
/// \post   The instance of Node is destroyed.
///////////////////////////////////////////////////////////////////////
cNode::~cNode( void )
{
}

// OPERATORS 

// OPERATIONS 

// ACCESS and MUTATE 

// INQUIRY 

// PROTECTED  

// PRIVATE  

///////////////////////////////////////////////////////////////////////////////
/// \class        Position
/// \author       Alex Hortin
/// \date         10/17/05
/// \brief        A class that stores a pointer to the position.
///
/// This class is one the stores a position of a node in the tree.  It is an 
/// interface tool for the client.
///       
/// REVISION HISTORY:
///
///   NONE
///            
///////////////////////////////////////////////////////////////////////////////

// SYSTEM INCLUDES
//

// LOCAL INCLUDES
//

// PUBLIC 

// LIFECYCLE 

///////////////////////////////////////////////////////////////////////
/// Default constructor.
/// \pre    None
/// \post   An instance of the Position class with 0 elements is created.
/// \param  None
/// \throw  None
///////////////////////////////////////////////////////////////////////
cPosition::cPosition( void )
{
   this->mPosition = NULL;
}

///////////////////////////////////////////////////////////////////////
/// constructor with node input 
/// \pre    None
/// \post   An instance of the Position class with 1 element is created.
/// \param  A node pointer
/// \throw  None
///////////////////////////////////////////////////////////////////////
cPosition::cPosition( cNode * n)
{
   this->mPosition = n;
}

///////////////////////////////////////////////////////////////////////
/// Copy Constructor.
/// \pre    An instance of Position needs to be present.
/// \post   Two instances of the same Position will exist.
/// \param  Vec is the Position to copy from.
/// \throw  None
///////////////////////////////////////////////////////////////////////
cPosition::cPosition( const cPosition & from )
{
   this->mPosition = from.mPosition;
}

///////////////////////////////////////////////////////////////////////
/// Destructor.
/// \pre    An instance of Position has been created.
/// \post   The instance of Position is destroyed.
///////////////////////////////////////////////////////////////////////
cPosition::~cPosition( void )
{
}

// OPERATORS 

// OPERATIONS 

// ACCESS and MUTATE 

// INQUIRY 

///////////////////////////////////////////////////////////////////////
/// element
/// \pre    There must be an positon to call it on
/// \post   None
/// \param  None
/// \return the element
///////////////////////////////////////////////////////////////////////
Element cPosition::element( void )
{
   if (mPosition == NULL)
   {
      throw std::out_of_range("OMFG WTFBBQ PWNT");
   }
   return (mPosition->mElement);
}

///////////////////////////////////////////////////////////////////////
/// isNull
/// \pre    There must be an positon to call it on
/// \post   None
/// \param  None
/// \return A bool whether or not their is an element
///////////////////////////////////////////////////////////////////////
bool cPosition::isNull( void )
{
   return (mPosition == NULL);
}

///////////////////////////////////////////////////////////////////////
/// element (const)
/// \pre    There must be an positon to call it on
/// \post   None
/// \param  None
/// \return the element
///////////////////////////////////////////////////////////////////////
Element cPosition::element( void ) const
{
   if (mPosition == NULL)
   {
      throw std::out_of_range("OMFG WTFBBQ PWNT");
   }
   return (mPosition->mElement);
}

///////////////////////////////////////////////////////////////////////
/// isNull(const)
/// \pre    There must be an positon to call it on
/// \post   None
/// \param  None
/// \return A bool whether or not their is an element
///////////////////////////////////////////////////////////////////////
bool cPosition::isNull( void ) const
{
   return (mPosition == NULL);
}

// PROTECTED  

// PRIVATE  

///////////////////////////////////////////////////////////////////////////////
/// \class        ElementIterator
/// \author       Alex Hortin
/// \date         10/17/05
/// \brief        A class that iterates a pointer to the element.
///
/// This class is one the stores a element of a node in the tree.  It is an 
/// interface tool for the client.  So they can iterate through all of the 
/// elements in the tree.
///       
/// REVISION HISTORY:
///
///   NONE
///       
///////////////////////////////////////////////////////////////////////////////

// SYSTEM INCLUDES
//

// LOCAL INCLUDES
//

// PUBLIC 

// LIFECYCLE 

///////////////////////////////////////////////////////////////////////////////
/// Default constructor.
/// \pre    None
/// \post   An instance of the ElementIterator class with 0 elements is created.
/// \param  None
/// \throw  None
///////////////////////////////////////////////////////////////////////////////
cElementIterator::cElementIterator( void )
{
   this->mPosition = 0;
}

///////////////////////////////////////////////////////////////////////////////
/// Copy Constructor.
/// \pre    An instance of ElementIterator needs to be present.
/// \post   Two instances of the same ElementIterator will exist.
/// \param  ElementIterator is the Position to copy from.
/// \throw  None
///////////////////////////////////////////////////////////////////////////////
cElementIterator::cElementIterator( const cElementIterator & from )
{
   this->mElementIterator = from.mElementIterator;
   this->mPosition = from.mPosition;
}

///////////////////////////////////////////////////////////////////////////////
/// Destructor.
/// \pre    An instance of ElementIterator has been created.
/// \post   The instance of ElementIterator is destroyed.
///////////////////////////////////////////////////////////////////////////////
cElementIterator::~cElementIterator( void )
{
}

// OPERATORS

///////////////////////////////////////////////////////////////////////////////
/// Assignment operator.
/// \pre    The target must be assigned a value in memory.
/// \post   A reference value will be returned.
/// \param  An element of a tree.
/// \return A refence to that element
/// \throw  NONE
///////////////////////////////////////////////////////////////////////////////
const cElementIterator &  cElementIterator::operator=( const cElementIterator & rhs )
{
   this->mPosition = rhs.mPosition;
   this->mElementIterator = rhs.mElementIterator;
   return rhs;
}

///////////////////////////////////////////////////////////////////////////////
// OPERATIONS 
/// next
/// \pre    There must be an iterator to call it on
/// \post   None
/// \param  None
/// \return a bool whether or not their is an iterator
///////////////////////////////////////////////////////////////////////////////
bool cElementIterator::hasNext ( void )
{
   return (mElementIterator.size() > mPosition);
}

///////////////////////////////////////////////////////////////////////////////
/// hasNext
/// \pre    The array where elements are stored must have something in it.
/// \post   mPosition is incemented
/// \param  None
/// \return The element of the array 
///////////////////////////////////////////////////////////////////////////////
Element cElementIterator::next ( void )
{
   if (! hasNext() )
   {
      throw std::out_of_range("OMFG WTFBBQ PWNT");
   }
   mPosition++;
   return mElementIterator[mPosition-1];
}
// ACCESS and MUTATE 

// INQUIRY 

// PROTECTED  

// PRIVATE  

///////////////////////////////////////////////////////////////////////////////
/// \class        PositionIterator
/// \author       Alex Hortin
/// \date         10/17/05
/// \brief        A class that iterates a pointer to the position.
///
/// This class is one the stores a position of a node in the tree.  It is an 
/// interface tool for the client.  So they can iterate through all of the 
/// positions in the tree.
///       
/// REVISION HISTORY:
///
///   NONE
///           
///////////////////////////////////////////////////////////////////////////////

// SYSTEM INCLUDES
//

// LOCAL INCLUDES
//

// PUBLIC 

// LIFECYCLE 

///////////////////////////////////////////////////////////////////////////////
/// Default constructor.
/// \pre    None
/// \post   An instance of the PositionIterator class with 0 elements is 
///         created.
/// \param  None
/// \throw  None
///////////////////////////////////////////////////////////////////////////////
cPositionIterator::cPositionIterator( void )
{
   this->mPosition = 0;
}

///////////////////////////////////////////////////////////////////////////////
/// Copy Constructor.
/// \pre    An instance of PositionIterator needs to be present.
/// \post   Two instances of the same PositionIterator will exist.
/// \param  Vec is the PositionIterator to copy from.
/// \throw  None
///////////////////////////////////////////////////////////////////////////////
cPositionIterator::cPositionIterator( const cPositionIterator & from )
{
   this->mPositionIterator = from.mPositionIterator;
   this->mPosition = from.mPosition;
}

///////////////////////////////////////////////////////////////////////////////
/// Destructor.
/// \pre    An instance of PositionIterator has been created.
/// \post   The instance of PositionIterator is destroyed.
///////////////////////////////////////////////////////////////////////////////
cPositionIterator::~cPositionIterator( void )
{
}

// OPERATORS

///////////////////////////////////////////////////////////////////////////////
/// Assignment operator.
/// \pre    The target must be assigned a value in memory.
/// \post   A reference value will be returned.
/// \param  An position of a tree.
/// \return A refence to that element
/// \throw  NONE
///////////////////////////////////////////////////////////////////////////////
const cPositionIterator &  cPositionIterator::operator=( const cPositionIterator & rhs )
{
   this->mPosition = rhs.mPosition;
   this->mPositionIterator = rhs.mPositionIterator;
   return rhs;
}

// OPERATIONS 


// ACCESS and MUTATE


// INQUIRY

/////////////////////////////////////////////////////////////////////////////// 
/// next
/// \pre    There must be an iterator to call it on
/// \post   None
/// \param  None
/// \return a bool whether or not their is an iterator
///////////////////////////////////////////////////////////////////////////////
bool cPositionIterator::hasNext ( void )
{
   return (mPositionIterator.size() > mPosition);
}
///////////////////////////////////////////////////////////////////////////////
/// hasNext
/// \pre    The array where elements are stored must have something in it.
/// \post   mPosition is incemented
/// \param  None
/// \return The element of the array 
///////////////////////////////////////////////////////////////////////////////
Tree::Position cPositionIterator::next ( void )
{
   if (! hasNext() )
   {
      throw std::out_of_range("OMFG WTFBBQ PWNT");
   }
   mPosition++;
   return mPositionIterator[mPosition-1];
}
// PROTECTED  

// PRIVATE  

///////////////////////////////////////////////////////////////////////////////
/// \class        Tree
/// \author       Alex Hortin
/// \date         10/17/05
/// \brief        A stan
///
/// This class is a vector that is built to act just like the standard library
/// vector class.  It was built from a shell given to us by Kelly Fitz.  
///       
/// REVISION HISTORY:
///
///   NONE
///         
///////////////////////////////////////////////////////////////////////////////

// SYSTEM INCLUDES
//

// LOCAL INCLUDES
//

// PUBLIC 

// LIFECYCLE 

///////////////////////////////////////////////////////////////////////////////
/// Default constructor.
/// \pre    None
/// \post   An instance of the Tree class with 0 elements is created.
/// \param  None
/// \throw  None
///////////////////////////////////////////////////////////////////////////////
Tree::Tree( Element e )
{
   mSize = 1;
   mRoot = new Node;
   mRoot->mParent = NULL;
   mRoot->mElement = e;
}

///////////////////////////////////////////////////////////////////////////////
/// Copy Constructor.
/// \pre    An instance of Tree needs to be present.
/// \post   Two instances of the same Vec will exist.
/// \param  Vec is the Tree to copy from.
/// \throw  None
///////////////////////////////////////////////////////////////////////////////
Tree::Tree( const Tree & from )
{
   
   if (from.mRoot != this->mRoot)
   {
      this->mRoot = copySubtree(from.mRoot);
   }
   this->mSize = from.mSize;
   
   
}

///////////////////////////////////////////////////////////////////////////////
/// Destructor.
/// \pre    An instance of Tree has been created.
/// \post   The instance of Tree is destroyed.
///////////////////////////////////////////////////////////////////////////////
Tree::~Tree( void )
{
   deleteSubtree(mRoot);
}

// OPERATORS

///////////////////////////////////////////////////////////////////////////////
/// Assignment Operator
/// Provide access to the element at the specified rank.
/// \pre    there must be a tree to copy
/// \post   2 copies of the tree will exist
/// \param  a reference to a tree
/// \return a reference to a tree
///////////////////////////////////////////////////////////////////////////////
Tree& Tree::operator=( const Tree & rhs )
{ 
   
   if (rhs.mRoot != this->mRoot)
   {
      deleteSubtree(mRoot);
      this->mRoot = copySubtree(rhs.mRoot);
   }
   this->mSize = rhs.mSize;
   return *this;
}

// OPERATIONS 

///////////////////////////////////////////////////////////////////////////////
/// addchild
/// \pre    There must be a tree to call it on
/// \post   The tree will have an element added to v's child
/// \param  A position
/// \paran  An Element
/// \return A position to the new node (child) 
///////////////////////////////////////////////////////////////////////////////
Tree::Position Tree::addChild( const Position& v, const Element e)
{
   if (v.isNull())
   {
      throw std::out_of_range("OMFG WTFBBQ PWNT");
   }
   Node* temp = new Node;//creating the new node
   v.mPosition->mChildren.push_back(temp);//adding the new node to the children list of its parent
   temp->mParent = v.mPosition;//telling the child that they are adopted
   temp->mElement = e;
   mSize++;//incrimenting the size
   Position temp_pos;
   temp_pos.mPosition = temp;//makeing and storing a position to return of the new node
   return temp_pos;
}

// ACCESS and MUTATE

///////////////////////////////////////////////////////////////////////////////
/// replaceElement
/// \pre    There must be a tree to call it on
/// \post   The Position will be replaced with the element
/// \param  A position 
/// \param  An Element
/// \return None   
///////////////////////////////////////////////////////////////////////////////
void Tree::replaceElement(Position v, Element e) 
{
   if (v.isNull())
   {
      throw std::out_of_range("OMFG WTFBBQ PWNT");
   }
   v.mPosition->mElement = e;
}

///////////////////////////////////////////////////////////////////////////////
/// swapElement
/// \pre    There must be a tree to call it on
/// \post   The Position will be replaced with the element
/// \param  A position to swap
/// \param  A position to swap
/// \return None   
///////////////////////////////////////////////////////////////////////////////
void Tree::swapElements(Position v, Position w) 
{
   if (v.isNull() || w.isNull())
   {
      throw std::out_of_range("OMFG WTFBBQ PWNT");
   }
   Element temp = w.mPosition->mElement;
   w.mPosition->mElement = v.mPosition->mElement;
   v.mPosition->mElement = temp;
}
   
// INQUIRY
///////////////////////////////////////////////////////////////////////////////
/// root
/// \pre    There must be a tree to call it on
/// \post   None
/// \param  None
/// \return The Position to the root of the tree
///////////////////////////////////////////////////////////////////////////////
void Tree::print(Position v)
{
   if (v.isNull())
   {
      throw std::out_of_range("OMFG WTFBBQ PWNT");
   }
   std::cout << v.element();
   PositionIterator children_rec = this->children(v);
   while (children_rec.hasNext())
   {
      std::cout << " ";
      print(children_rec.next());
   }
}

///////////////////////////////////////////////////////////////////////////////
/// root
/// \pre    There must be a tree to call it on
/// \post   None
/// \param  None
/// \return The Position to the root of the tree
///////////////////////////////////////////////////////////////////////////////
Tree::Position Tree::root( void ) const
{
   Position root_temp;
   root_temp.mPosition = mRoot;
   return root_temp;
}

///////////////////////////////////////////////////////////////////////////////
/// isRoot
/// \pre    There must be a tree to call it on
/// \post   None
/// \param  A position
/// \return bool if its a root
///////////////////////////////////////////////////////////////////////////////
bool Tree::isRoot(Position& v) const
{
   if (v.isNull())
   {
      throw std::out_of_range("OMFG WTFBBQ PWNT");
   }
   return (v.mPosition == mRoot);
}

///////////////////////////////////////////////////////////////////////////////
/// isExternal
/// \pre    There must be a tree to call it on
/// \post   None
/// \param  A position
/// \return bool if its external
///////////////////////////////////////////////////////////////////////////////
bool Tree::isExternal(Position& v) const
{
   if (v.isNull())
   {
      throw std::out_of_range("OMFG WTFBBQ PWNT");
   }
   return (v.mPosition->mChildren.size() == 0);
}

///////////////////////////////////////////////////////////////////////////////
/// isInternal
/// \pre    There must be a tree to call it on
/// \post   None
/// \param  A position
/// \return bool if its internal
///////////////////////////////////////////////////////////////////////////////
bool Tree::isInternal(Position& v) const
{
   if (v.isNull())
   {
      throw std::out_of_range("OMFG WTFBBQ PWNT");
   }
   return (v.mPosition->mChildren.size() != 0);
}

///////////////////////////////////////////////////////////////////////////////
/// size
/// \pre    There must be a tree to call it on
/// \post   None
/// \param  None
/// \return the size of a tree
///////////////////////////////////////////////////////////////////////////////
unsigned int Tree::size( void ) const
{
   return mSize;
}

///////////////////////////////////////////////////////////////////////////////
/// parent
/// \pre    There must be a tree to call it on
/// \post   None
/// \param  A position
/// \return the parent of a node   
///////////////////////////////////////////////////////////////////////////////
Tree::Position Tree::parent( const Position& v) const
{
   if (v.isNull())
   {
      throw std::out_of_range("OMFG WTFBBQ PWNT");
   }
   Tree::Position p;
   p.mPosition = (v.mPosition->mParent);
   return p;
   
}
///////////////////////////////////////////////////////////////////////////////
/// children
/// \pre    There must be a tree to call it on
/// \post   None
/// \param  A position
/// \return the parent of a node
///////////////////////////////////////////////////////////////////////////////
Tree::PositionIterator Tree::children(const Position& v) const
{
   if (v.isNull())
   {
      throw std::out_of_range("OMFG WTFBBQ PWNT");
   }
   PositionIterator temp_it;
   for (unsigned int i = 0; i < (v.mPosition->mChildren.size());i++)
   {
      Position temp_pos(v.mPosition->mChildren[i]);
      (temp_it.mPositionIterator).push_back(temp_pos);
   }
   return temp_it;
}

///////////////////////////////////////////////////////////////////////////////
/// elements
/// \pre    There must be a tree to call it on
/// \post   None
/// \param  None
/// \return an Iterator of Elements
///////////////////////////////////////////////////////////////////////////////
Tree::ElementIterator Tree::elements(void ) const
{
   ElementIterator x;
   getelements(x,root());
   return x;
}

///////////////////////////////////////////////////////////////////////////////
/// positions
/// \pre    There must be a tree to call it on
/// \post   None
/// \param  None
/// \return an Iterator of Positions
///////////////////////////////////////////////////////////////////////////////
Tree::PositionIterator Tree::positions(void ) const
{
   PositionIterator x;
   getpositions(x,root());
   return x;
}

///////////////////////////////////////////////////////////////////////////////
/// getelements
/// \pre    There must be a tree to call it on
/// \post   None
/// \param  None
/// \return an Iterator of Elements
///////////////////////////////////////////////////////////////////////////////
void Tree::getelements(ElementIterator& iter, Position p ) const
{
   iter.mElementIterator.push_back( p.element() );
   Element i = p.element();
   PositionIterator children_rec = children(p);
   while (children_rec.hasNext())
   {
      getelements(iter,(children_rec.next()));
   }
}

///////////////////////////////////////////////////////////////////////////////
/// getpositions
/// \pre    There must be a tree to call it on
/// \post   None
/// \param  None
/// \return an Iterator of Positions
///////////////////////////////////////////////////////////////////////////////
void Tree::getpositions(PositionIterator& iter, Position p ) const
{
   iter.mPositionIterator.push_back( p );
   PositionIterator children_rec = children(p);
   while (children_rec.hasNext())
   {
      getpositions(iter,(children_rec.next()));
   }
}


// PROTECTED  

// PRIVATE  
///////////////////////////////////////////////////////////////////////////////
/// deleteSubtree
/// \pre    There must be a tree to call it on
/// \post   None
/// \param  None
/// \return an Iterator of Positions
///////////////////////////////////////////////////////////////////////////////
void Tree::deleteSubtree( Node * p)
{
   std::vector<Node *>::iterator it = p->mChildren.begin();
   while (it != p->mChildren.end())
   {
      deleteSubtree(*it);
      it++;
   }
   delete p;
}

///////////////////////////////////////////////////////////////////////////////
/// copySubTree
/// \pre    There must be a tree to call it on
/// \post   None
/// \param  None
/// \return an Iterator of Positions
///////////////////////////////////////////////////////////////////////////////
Tree::Node * Tree::copySubtree( Node * p)
{
   Node* Temp = new Node;
   Node* New_Child;
   Temp->mParent = p->mParent;
   Temp->mElement = p->mElement;
   
   std::vector<Node *>::iterator it = p->mChildren.begin();
   while (it != p->mChildren.end())
   {
      New_Child = copySubtree(*it);
      it++;
      Temp->mChildren.push_back(New_Child);
      New_Child->mParent = Temp;
   }
   return Temp;
   
}
