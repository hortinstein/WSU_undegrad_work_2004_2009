///////////////////////////////////////////////////////////////////////////////
/// \author       Alex Hortin
/// \date         10/18/05
/// \brief        This is my test file used to test my implementation of a tree.
///
/// I am creating a tree and this will be the file that I use to test all of
/// the various functions contained within the tree.  It will try to test all
/// of the options that the interface gives the user. 
///
/// REVISION HISTORY:
///
/// NONE
///            
///////////////////////////////////////////////////////////////////////////////

// SYSTEM INCLUDES
//
#include <iostream>

// LOCAL INCLUDES
//
#include "Tree.h"                                

// FUNCTIONS

int main (void)
{
   Tree::Position pos;
   Tree::PositionIterator iter;
   Tree T( "moo" );
   pos = T.root();
   if ( ! pos.isNull() )
   {
     std::cout << pos.element() << std::endl;
   }
   cout << "testing element should have printed moo "<< endl;
   
   pos = T.root();
   if ( ! pos.isNull() )
   {
     cout << pos.element() << endl;
     // prints `moo'
   }
   
   if ( ! T.parent( pos ).isNull() )
   {
     // what the heck could it possibly be?
   }
   cout << "testing rootshould have printed moo "<< endl;
   
   pos = T.root();
   if ( ! pos.isNull() )
   {
     cout << pos.element() << endl;
     // prints `moo'
   }
   
   T.replaceElement( pos, "cow" );
   cout << pos.element() << endl;
   // prints `cow'
   cout << "testing replace should have printed moo than cow "<< endl;
   
   Tree::Position ch = T.addChild( T.root(), "oink" );
   if ( ! ch.isNull() )
   {
     cout << ch.element() << endl;
     // had better print out `oink'
   }
   cout << "testing addChild and children should have printed oink "<< endl;

   Tree::ElementIterator chd = T.elements();
   Tree::PositionIterator chp = T.positions();
   while (  chd.hasNext() &&  chp.hasNext() )
   {
     cout << chd.next() << " elem it" << endl;
     cout << (chp.next()).element() <<  " pos it" << endl;
   }
   cout << "testing iterators elements and positions should have printed cow cow oink oink"<< endl;
   
   Tree R = T;
   R.print(R.root());
   std::cout << std::endl;
   T.print(T.root());
   std::cout << std::endl;
}
