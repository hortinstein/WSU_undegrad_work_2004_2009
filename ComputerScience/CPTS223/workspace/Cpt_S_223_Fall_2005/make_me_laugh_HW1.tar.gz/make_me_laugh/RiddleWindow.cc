#include <iostream>
#include <string>
///////////////////////////////////////////////////////////////////////////////
/// \class        RiddleWindow
/// \author       Alex Hortin
/// \date         9/6/05
/// \brief        This class is built to show a window with two boxes.
/// BASE CLASSES: FL_Window
///
/// PURPOSE:   This class is built to make a simple window with two input boxes
///            and two buttons, one to quit, and one to reveal the contents of            
///            the second box.  It will also resize based on the size of the riddles
///
/// \invariant        
///          -#  first class invariant
///          -#  next class invariant, repeat as necessary
///       
/// REVISION HISTORY: n/a
/// 
///           
///////////////////////////////////////////////////////////////////////////////

#include <iostream>
#include <string>

#include "RiddleWindow.h"//includes the file where my class definition is

// PUBLIC

// LIFECYCLE

///////////////////////////////////////////////////////////////////////
///   Default Constructor.
/// \pre    This is a default constructor so it must be passed two strings
///          and called to construct something. 
/// \post   There are no post conditions
/// \param  2 strings, each containing part of a riddle
/// \return It returns nothing
/// \throw  n/a
///////////////////////////////////////////////////////////////////////
RiddleWindow::RiddleWindow(string w, string h):Fl_Window(300,200,"I Pass")
{
	begin();
		string::size_type mLen_w = w.size();//setting variables to the size for easy comparison
		string::size_type mLen_h = h.size();//setting variables to the size for easy comparison
		int mBiggest = 0;
		if (mLen_w > mLen_h){
			mBiggest = mLen_w;//finding biggest to base size off of
		}
		else{
			mBiggest = mLen_h;//finding biggest to base size off of
		}
		this->size((mBiggest * 10)+70, 200);//resizing to accomidate for extra charecters
		tell_me = new Fl_Button( 10, 150, 70, 30, "T&ell Me");//displays the button to tell
		tell_me->callback( cb_tell_me, this );//calls the function after the button has been pressed
	
		quit = new Fl_Button(100, 150, 70, 30, "&Quit");//displays the quit button
		quit->callback(cb_quit, this);//calls the quit function to quit the program
		
		rid = new Fl_Input(60, 50, (mBiggest * 10), 30, "Riddle:");//defines the label and text box
		rid->textfont(FL_COURIER);//switched the font to courier
		rid->value(w.c_str()); //shows the riddle
		
		ans = new Fl_Output(60, 100, (mBiggest * 10), 30, "Answer:");//defines the answer box
		ans->textfont(FL_COURIER);//switched the font to courier
		answer = h;//copies the string into class memory
	
	end();//ends the function
	resizable(this);//makes the window resizable
	show();//shows the window
}
///////////////////////////////////////////////////////////////////////
///   Copy Constructor.
/// \pre    This is a Copy constructor so it must be passed a reference
///          and called to construct the copy. 
/// \post   There are no post conditions
/// \param  The parameters are the refence to something to copy it.
/// \return It returns nothing
/// \throw  n/a
///////////////////////////////////////////////////////////////////////
RiddleWindow::RiddleWindow(const RiddleWindow& RiddleWindow):Fl_Window(300,200,"I Pass")
{
}
///////////////////////////////////////////////////////////////////////
///   Destructor.
/// \pre    it must be called to destroy soemthing
/// \post   There are no post conditions
/// \param  The parameters are the refence to something to copy it.
/// \return It returns nothing
/// \throw  n/a
///////////////////////////////////////////////////////////////////////
RiddleWindow::~RiddleWindow()
{
}
/* Function: RiddleWindow quit button                      
 * Date Created: 8/30/05                           
 * Date Last Modified: 8/30/05                         
 * Description: Calls the quit function while still hiding information
 * Input parameters: the widget location pointer                                     
 * Returns: NONE    
*/

// OPERATORS

 

///////////////////////////////////////////////////////////////////////
/// cb_quit is the call that the program makes when the quit button is pressed.
/// \pre   the pre conditions for this is the button being pressed  
/// \post  there are no post conditions
/// \param  a widget pointer
/// \return void
/// \throw  n/a
///////////////////////////////////////////////////////////////////////
void RiddleWindow::cb_quit(Fl_Widget* , void* v)
{
	( (RiddleWindow*)v )->cb_quit_i();//calls the function to hide the window
}
///////////////////////////////////////////////////////////////////////
/// cb_quit_i is the call that the cb_quit makes so that information hiding can
///  can be kept in tact
/// \pre   the pre conditions for this is the button being pressed  
/// \post  there are no post conditions
/// \param  none
/// \return void
/// \throw  n/a
///////////////////////////////////////////////////////////////////////
void RiddleWindow::cb_quit_i() 
{
	hide();//hides the window
}
///////////////////////////////////////////////////////////////////////
/// cb_tell_me is the call that the program makes when the tell me button is 
///  pressed.  It than shows the contents.
/// \pre   the pre conditions for this is the button being pressed  
/// \post  there are no post conditions
/// \param  a widget pointer
/// \return void
/// \throw  n/a
///////////////////////////////////////////////////////////////////////
void RiddleWindow::cb_tell_me(Fl_Widget* , void* v)
{
    ( (RiddleWindow*)v )->cb_tell_me_i();//calls the function that displays the text
}
///////////////////////////////////////////////////////////////////////
/// cb_tell_me_i is the call that the program makes when the tell me button is 
///  pressed.  This part shows the contents
/// \pre   the pre conditions for this is the button being pressed  
/// \post  there are no post conditions
/// \param  a widget pointer
/// \return void (shows the contents in the window
/// \throw  n/a
///////////////////////////////////////////////////////////////////////
void RiddleWindow::cb_tell_me_i()
{
	ans->value(answer.c_str());//shows the answer
}

