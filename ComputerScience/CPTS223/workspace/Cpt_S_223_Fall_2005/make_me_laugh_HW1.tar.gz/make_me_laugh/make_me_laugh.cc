///////////////////////////////////////////////////////////////////////////////
/// \author       Alex Hortin
/// \date         9/30/05
/// \brief        This is the test file for my RiddleWindow class
///
/// It uses two test cases to test the functionality of the RiddleWindow class.
/// It will open up two windows with different sized riddles to demonstrait the
/// complete functionality of these tests.
///
/// REVISION HISTORY:
///
/// date       Comment on what was changed. Separate entries with a blank line.
///            
///////////////////////////////////////////////////////////////////////////////


// SYSTEM INCLUDES
//
#include <FL/Fl.H>//the FLTK source files
#include <FL/Fl_Window.H>//the FLTK source files
#include <FL/Fl_Button.H>//the FLTK source files
#include <FL/Fl_Input.H>//the FLTK source files
#include <FL/Fl_Output.H>//the FLTK source files 
// LOCAL INCLUDES
//
#include "RiddleWindow.h"

using std::string;

int main(void)
{
	string q = "What have I got in my pocket?";//question
	string a = "The Ring!";//answer
	
	RiddleWindow w( q, a );//call to the fuction that makes the window
	
	string p = "What has roots as nobody sees, Is taller than trees, Up, up it goes And yet never grows?";//question
	string o = "Mountain";//answer
	
	RiddleWindow r( p, o );//call to the fuction that makes the window
	return Fl::run();//returns the FLTK windows if successfull.
}
