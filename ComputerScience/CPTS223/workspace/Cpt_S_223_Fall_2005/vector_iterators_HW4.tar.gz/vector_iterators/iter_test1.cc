// iter_test1.cc
//
// Test iterator construction, assignment, and dereference
// using a simple iteration loop.
// Assumes that the vector works.
//
#include <iostream>
using std::cout;
using std::endl;

#include <stdexcept>

#include <string>
using std::string;

#include "Vec.h"
typedef Vec< string > Vector;

int main( void )
{
   Vector v( 6 );  
   v[0] = "one";
   v[1] = "two";
   v[2] = "three";
   v[3] = "four";
   v[4] = "five";
   v[5] = "six";  

   cout << "vector contains:" << endl;
   for ( Vector::size_type i = 0; i < v.size(); ++i )
   {
      cout << v[i] << endl;
   }
  
   cout << "constructing a default iterator." << endl;
   Vector::iterator iter;
      
   cout << "assigning to beginning of vector and iterating til equal to end" << endl;
   Vector::size_type count = 0;
   for ( iter = v.begin(); iter != v.end(); ++iter )
   {
      ++count;
      cout << "OK...";
   }
   cout << "\ncounted " << count << " positions" << endl;
   if ( 6 == count )
   {
      cout << "iteration OK" << endl;
   }
   else
   {
      cout << "FAIL: that's odd, there should be sixe positions!" << endl;
      return 1;
   }
   
   cout << "iteration OK, testing dereference" << endl;
   cout << "should print: \"one two three four five six\"" << endl;
   for ( iter = v.begin(); iter != v.end(); ++iter )
   {
      cout << *iter << " ";
   }
   cout << "\n";
   
   cout << "testing pointer operator" << endl;
   cout << "should print \"3 3 5 4 4 3\" (the sizes of the strings)" << endl;
   for ( iter = v.begin(); iter != v.end(); ++iter )
   {
      cout << iter->size() << " ";
   }
   cout << "\n";
   

   cout << "COMPLETED iterator test1" << endl << endl;
   return 0;
}
