// iter_test5.cc
//
// Test iterator range insertion into vector.
//
#include <iostream>
using std::cout;
using std::endl;

#include <stdexcept>

#include <string>
using std::string;

#include "Vec.h"
typedef Vec< string > Vector;

int main( void )
{
   Vector v123( 3 );  
   v123[0] = "one";
   v123[1] = "two";
   v123[2] = "three";

   cout << "vector 123 contains:" << endl;
   for ( Vector::size_type i = 0; i < v123.size(); ++i )
   {
      cout << v123[i] << endl;
   }

   Vector v456( 3 );  
   v456[0] = "four";
   v456[1] = "five";
   v456[2] = "six";

   cout << "vector 456 contains:" << endl;
   for ( Vector::size_type i = 0; i < v456.size(); ++i )
   {
      cout << v456[i] << endl;
   }
   
   Vector v;
   Vector::iterator iter;  

   cout << "inserting 123 contents at beginning of empty vector" << endl;
   v.insert( v.begin(), v123.begin(), v123.end() );

   cout << "should print: \"one two three\"" << endl;
   for ( iter = v.begin(); iter != v.end(); ++iter )
   {
      cout << *iter << " ";
   }
   cout << "\n";

   cout << "clearing, inserting 456 contents at end of empty vector" << endl;
   v = Vector();
   v.insert( v.end(), v456.begin(), v456.end() );

   cout << "should print: \"four five six\"" << endl;
   for ( iter = v.begin(); iter != v.end(); ++iter )
   {
      cout << *iter << " ";
   }
   cout << "\n";

   cout << "inserting 123 contents at beginning of non-empty vector" << endl;
   v.insert( v.begin(), v123.begin(), v123.end() );

   cout << "should print: \"one two three four five six\"" << endl;
   for ( iter = v.begin(); iter != v.end(); ++iter )
   {
      cout << *iter << " ";
   }
   cout << "\n";
   
   cout << "finding \"four\" and inserting 123 there again" << endl;
   iter = v.begin();
   while ( *iter != "four" )
   {
      ++iter;
   }
   v.insert( iter, v123.begin(), v123.end() );

   cout << "should print: \"one two three one two three four five six\"" << endl;
   for ( iter = v.begin(); iter != v.end(); ++iter )
   {
      cout << *iter << " ";
   }
   cout << "\n";
   
   cout << "COMPLETED iterator test5" << endl << endl;
   return 0;
}
