// iter_test2.cc
//
// Test iterator comparison (equal and not equal).
// Assumes that the vector works.
//
#include <iostream>
using std::cout;
using std::endl;

#include <stdexcept>

#include <string>
using std::string;

#include "Vec.h"
typedef Vec< string > Vector;

int main( void )
{
   Vector v( 6 );  
   v[0] = "one";
   v[1] = "two";
   v[2] = "three";
   v[3] = "four";
   v[4] = "five";
   v[5] = "six";  

   cout << "vector contains:" << endl;
   for ( Vector::size_type i = 0; i < v.size(); ++i )
   {
      cout << v[i] << endl;
   }
  
   cout << "constructing a default iterator." << endl;
   Vector::iterator iter;
      
   cout << "comparing two default iterators" << endl;
   if ( iter == Vector::iterator() )
   {
      cout << "they compare equal" << endl;
   }
   else
   {
      cout << "FAIL: they don't compare equal" << endl;
      return 1;
   }
   
   if ( iter != Vector::iterator() )
   {
      cout << "FAIL: they compare not equal" << endl;
      return 1;
   }
   else
   {
      cout << "they don't compare not equal" << endl;
   }
   
   cout << "comparing default iterator to v.begin()" << endl;
   if ( iter == v.begin() )
   {
      cout << "FAIL: they compare equal" << endl;
      return 1;
   }
   else
   {
      cout << "they don't compare equal" << endl;
   }
   
   if ( iter != v.begin() )
   {
      cout << "they compare not equal" << endl;
   }
   else
   {
      cout << "FAIL: they don't compare not equal" << endl;
      return 1;
   }

   cout << "COMPLETED iterator test2" << endl << endl;
   return 0;
}
