///////////////////////////////////////////////////////////////////////////////
/// \author       Alex Hortin
/// \date         9/27/05
/// \brief        This is the test file for my VecIteror class
///
/// It uses a variety of test cases to test the functionality of the 
/// VecIterator class. It is just for me to test the fuctionality of my class
/// before I add in all of the functions
///
/// REVISION HISTORY:
///
/// NONE
///            
///////////////////////////////////////////////////////////////////////////////


// SYSTEM INCLUDES
//


// LOCAL INCLUDES
//
#include "Vec.h"

using std::cout;
using std::endl;


int main(void)
{
   std::string items[] = {"1", "2", "3","4","5"};
   
   Vec v(5);
   
   for (int i = 0; i < 5; i++)
   {
      v[i] = items[i];
   }
   
   Vec::iterator it = v.begin();
   Vec::iterator it2 = v.end();
   Vec::iterator it3 = v.begin();
   it3++;
   
   v.insert(it3,it,it2);
   
   for (Vec::iterator it_help = v.begin(); it_help != v.end(); it_help++)
   {
      cout << *it_help << endl;
   }
   
   
   
   
}
   