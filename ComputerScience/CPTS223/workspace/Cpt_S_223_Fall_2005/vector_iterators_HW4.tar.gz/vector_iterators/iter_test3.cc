// iter_test3.cc
//
// Test iterator increment and decrement.
// Assumes that the vector works.
//
#include <iostream>
using std::cout;
using std::endl;

#include <stdexcept>

#include <string>
using std::string;

#include "Vec.h"
typedef Vec< string > Vector;

int main( void )
{
   Vector v( 6 );  
   v[0] = "one";
   v[1] = "two";
   v[2] = "three";
   v[3] = "four";
   v[4] = "five";
   v[5] = "six";  

   cout << "vector contains:" << endl;
   for ( Vector::size_type i = 0; i < v.size(); ++i )
   {
      cout << v[i] << endl;
   }
  
   cout << "constructing a default iterator." << endl;
   Vector::iterator iter = v.begin();
      
   cout << "checking pre-increment" << endl;
   Vector::iterator preinc_return = ++iter;
   if ( *iter != "two" )
   {
      cout << "FAILED: pre-incremented iterator is at" << *iter << endl;
      cout << "should be at \"two\"" << endl;
      return 1;
   }
   else if ( *preinc_return != "two" )
   {
      cout << "FAILED: pre-incremented return is at" << *preinc_return << endl;
      cout << "should be at \"two\"" << endl;
      return 1;
   }
   else
   {
      cout << "OK" << endl;
   }

   cout << "checking post-increment" << endl;
   Vector::iterator postinc_return = iter++;
   if ( *iter != "three" )
   {
      cout << "FAILED: post-incremented iterator is at" << *iter << endl;
      cout << "should be at \"three\"" << endl;
      return 1;
   }
   else if ( *postinc_return != "two" )
   {
      cout << "FAILED: post-incremented return is at" << *postinc_return << endl;
      cout << "should be at \"two\"" << endl;
      return 1;
   }
   else
   {
      cout << "OK" << endl;
   }

   cout << "checking pre-decrement" << endl;
   Vector::iterator predec_return = --iter;
   if ( *iter != "two" )
   {
      cout << "FAILED: pre-decremented iterator is at" << *iter << endl;
      cout << "should be at \"two\"" << endl;
      return 1;
   }
   else if ( *predec_return != "two" )
   {
      cout << "FAILED: pre-decremented return is at" << *predec_return << endl;
      cout << "should be at \"two\"" << endl;
      return 1;
   }
   else
   {
      cout << "OK" << endl;
   }

   cout << "checking post-decrement" << endl;
   Vector::iterator postdec_return = iter--;
   if ( *iter != "one" )
   {
      cout << "FAILED: post-decremented iterator is at" << *iter << endl;
      cout << "should be at \"one\"" << endl;
      return 1;
   }
   else if ( *postinc_return != "two" )
   {
      cout << "FAILED: post-decremented return is at" << *postdec_return << endl;
      cout << "should be at \"two\"" << endl;
      return 1;
   }
   else
   {
      cout << "OK" << endl;
   }


   cout << "COMPLETED iterator test3" << endl << endl;
   return 0;
}
