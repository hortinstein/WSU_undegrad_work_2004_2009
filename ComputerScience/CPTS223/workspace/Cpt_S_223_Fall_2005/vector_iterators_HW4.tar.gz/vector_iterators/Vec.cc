///////////////////////////////////////////////////////////////////////////////
/// \class        Vec
/// \author       Alex Hortin (Originally Created by Kelly Fitz)
/// \date         9/7/05
/// \brief        A lousy vector implementation to get you started.
///
/// This class is a vector that is built to act just like the standard library
/// vector class.  It was built from a shell given to us by Kelly Fitz.  
///       
/// REVISION HISTORY:
///
/// 9/19/05    Improved the Vec Class to act more like the standard library.
///            I also removed Kelly's unnecissary commentary and variables that 
///            will not apply to my finished Vec class.
///
/// 9/26/05    Debugged the Vec according to test's.
///            
///////////////////////////////////////////////////////////////////////////////

#include "Vec.h"                                // class implemented

// SYSTEM INCLUDES
//


// PUBLIC 

// LIFECYCLE 

///////////////////////////////////////////////////////////////////////
/// Default constructor.
/// \pre    None
/// \post   An instance of the Vec class with 0 elements is created.
/// \param  None
/// \throw  None
///////////////////////////////////////////////////////////////////////
Vec::Vec( void ) :
   mArray(0),
   mArraySize(0),
   mNumElements(0)
{

} // End constructor

///////////////////////////////////////////////////////////////////////
/// constructor with size given
/// \pre    None
/// \post   An instance of the Vec class with a user specified number of
///         elements is created.
/// \param  None
/// \throw  None
///////////////////////////////////////////////////////////////////////
Vec::Vec(size_type n )
{
   mArray = new Element[n];
   mArraySize = n;
   mNumElements = n;
} // End constructor

///////////////////////////////////////////////////////////////////////
/// Copy Constructor.
/// \pre    An instance of Vec needs to be present.
/// \post   Two instances of the same Vec will exist.
/// \param  Vec is the Vec to copy from.
/// \throw  None
///////////////////////////////////////////////////////////////////////
Vec::Vec( const Vec & from )
{
   this->mArray = new Element[from.mArraySize];
   for (size_type i = 0; i < from.mNumElements; i++)
   {
      this->mArray[i] = from.mArray[i];//copying all elements over
   }
   this->mNumElements = from.mNumElements;
   this->mArraySize = from.mArraySize;
} // end copy constructor

///////////////////////////////////////////////////////////////////////
/// Destructor.
/// \pre    An instance of Vec has been created.
/// \post   The instance of Vec is destroyed.
///////////////////////////////////////////////////////////////////////
Vec::~Vec( void )
{
   delete [] mArray;

} // end destructor

// OPERATORS 

///////////////////////////////////////////////////////////////////////
/// Assignment operator.
/// \pre    A vector is created
/// \post   A reference to the copy is returned  
/// \param  rhs is the object to assign from.
/// \return A reference to this Vec.
/// \throw  None
///////////////////////////////////////////////////////////////////////
Vec& Vec::operator=( const Vec &  rhs )
{
   this->mArray = new Element[rhs.mArraySize];
   for (size_type i = 0; i < rhs.mNumElements; i++)
   {
      this->mArray[i] = rhs.mArray[i];//copying all elements over
   }
   this->mNumElements = rhs.mNumElements;
   this->mArraySize = rhs.mArraySize;
   return *this;
} // end assignment operator

///////////////////////////////////////////////////////////////////////
/// Subscript operator (non-const).
/// \pre    idx must be less than the number of elements
///         stored in the vector,
/// \post   A reference of the element is returned  
/// \param  idx is the rank of the element to access
/// \return access to the element at rank `idx'.
/// \throw  An error if index is out of bounds
///////////////////////////////////////////////////////////////////////
Element & Vec::operator[]( Vec::size_type idx )
{
   if ( idx >= mArraySize )//if index is greater or equal to mNumelements
   {
      throw std::out_of_range("Index is greater than the amount of elements in the Vector");//throwing an exception
   }
   return mArray[ idx ];
}

///////////////////////////////////////////////////////////////////////
/// Subscript operator (const).
/// \pre    idx must be less than the number of elements
///         stored in the vector,
/// \post   A reference of the element is returned  
/// \param  idx is the rank of the element to access
/// \return read-only access to the element at rank `idx'.
/// \throw  An error if index is out of bounds
///////////////////////////////////////////////////////////////////////
const Element & Vec::operator[]( Vec::size_type idx ) const
{
   if ( idx >= mArraySize )//if index is greater or equal to mNumelements
   {
      throw std::out_of_range("Index is greater than the amount of elements in the Vector");//throwing an exception
   }
   return mArray[ idx ];
}

// OPERATIONS 
///////////////////////////////////////////////////////////////////////
/// push_back
/// \pre    A Vec must exist to make the call.
/// \post   The vector has a new element appended to it and possibly
///         allocate more memory.  (Double what the number of elements were
///         before to insure n performance.)
/// \param  An element to be appended onto the vector
/// \return None
/// \throw  None
///////////////////////////////////////////////////////////////////////
void Vec::push_back(Element E)
{
   
   if (mArraySize == 0)
   {
      mArraySize = 1;
      Element *new_array = new Element[mArraySize*2];//creating a new array two times larger than the old one
         
      mArraySize = mArraySize * 2;
         
      mArray = new_array;
         
      mArray[mNumElements] = E;//setting the new value to the next spot in the array and incrimenting mNumElements
         
      mNumElements++;
   }
   else if (mNumElements < mArraySize)
   {
      mArray[mNumElements++] = E;
   }
   else if (mNumElements >= mArraySize)//if array is out of space
   {
      
      Element *new_array = new Element[mArraySize*2];//creating a new array two times larger than the old one
      
      for (size_type i = 0; i < this->mNumElements; i++)
      {
         new_array[i] = this->mArray[i];//copying all old stuff over into new array
      }
      
      mArraySize = mArraySize * 2;
      delete [] mArray;
      mArray = new_array;
      mArray[mNumElements] = E;//setting the new value to the next spot in the array and incrimenting mNumElements
      mNumElements++;
   } 
  
  
}
///////////////////////////////////////////////////////////////////////
/// pop_back
/// \pre    The array where elements are stored must have something in it.
/// \post   The last element is removed.
/// \param  None
/// \return None
/// \throw  None
///////////////////////////////////////////////////////////////////////
void Vec::pop_back(void)
{
   Element empty;
   if (mNumElements != 0)
   {
      mNumElements--;
   }
   mArray[mNumElements] = empty;   
}

///////////////////////////////////////////////////////////////////////
/// front (const)
/// \pre    The array where elements are stored must have something in it.
/// \post   None
/// \param  None
/// \return A reference to the starting element of the array
/// \throw  domain error if the array has nothing in it
///////////////////////////////////////////////////////////////////////
const Element& Vec::front(void) const
{
   if (mNumElements == 0)
   {
      throw std::domain_error("Vector is empty");//throwing an exception
   }
   else 
   {
      return mArray[0];
   }
}

///////////////////////////////////////////////////////////////////////
/// front 
/// \pre    The array where elements are stored must have something in it.
/// \post   None
/// \param  None
/// \return A reference to the starting element of the array
/// \throw  domain error if the array has nothing in it
///////////////////////////////////////////////////////////////////////
Element& Vec::front(void)
{
   if (mNumElements == 0)
   {
      throw std::domain_error("Vector is empty");//throwing an exception
   }
   else 
   {
      return mArray[0];
   }
}

///////////////////////////////////////////////////////////////////////
/// back (const)
/// \pre    The array where elements are stored must have something in it.
/// \post   None
/// \param  None
/// \return A const reference to the end element of the array
/// \throw  domain error if the array has nothing in it
///////////////////////////////////////////////////////////////////////
const Element& Vec::back(void) const
{
   if (mNumElements == 0)
   {
      throw std::domain_error("Vector is empty");//throwing an exception
   }
   else 
   {
      return mArray[mNumElements - 1];
   }
}

///////////////////////////////////////////////////////////////////////
/// back
/// \pre    The array where elements are stored must have something in it.
/// \post   None
/// \param  None
/// \return A reference to the end element of the array
/// \throw  domain error if the array has nothing in it
///////////////////////////////////////////////////////////////////////
Element& Vec::back(void)
{
   if (mNumElements == 0)
   {
      throw std::domain_error("Vector is empty");//throwing an exception
   }
   else 
   {
      return mArray[mNumElements - 1];
   }
}

///////////////////////////////////////////////////////////////////////
/// begin 
/// \pre    The array where elements are stored must have something in it.
/// \post   None
/// \param  None
/// \return An iterator pointin g to the starting element of the array
/// \throw  NONE
///////////////////////////////////////////////////////////////////////
Vec::iterator Vec::begin(void)
{
   Vec::iterator it; 
   it.mIterator= mArray;
   it.mPosition = 0;
   return it;
} 

///////////////////////////////////////////////////////////////////////
/// end 
/// \pre    The array where elements are stored must have something in it.
/// \post   None
/// \param  None
/// \return An iterator pointin g to the ending element of the array
/// \throw  NONE
///////////////////////////////////////////////////////////////////////
Vec::iterator Vec::end(void)
{
   Vec::iterator temp;
   temp.mIterator = (mArray + mNumElements - 1);
   temp.mPosition = mNumElements - 1;
   return temp;
}

// ACCESS and MUTATE
///////////////////////////////////////////////////////////////////////
/// empty 
/// \pre    Their must be an array where elements can be stored.
/// \post   None
/// \param  None
/// \return A bool for the array being full or not.
/// \throw  None
///////////////////////////////////////////////////////////////////////
bool Vec::empty()
{
   if (mNumElements == 0)//checking to see if there is anything in the array
   {
      return true;
   }
   else
   {
      return false;
   }
}


///////////////////////////////////////////////////////////////////////
/// empty (const)
/// \pre    Their must be an array where elements can be stored.
/// \post   None
/// \param  None
/// \return A bool for the array being full or not.
/// \throw  None
///////////////////////////////////////////////////////////////////////
bool Vec::empty() const
{
   if (mNumElements == 0)//checking to see if there is anything in the array
   {
      return true;
   }
   else
   {
      return false;
   }
}

///////////////////////////////////////////////////////////////////////
/// clear
/// \pre    Their must be an array where elements can be stored.
/// \post   The array's elements are removed.
/// \param  None
/// \return None
/// \throw  None
///////////////////////////////////////////////////////////////////////
void Vec::clear(void)
{
   mNumElements = 0;
}
///////////////////////////////////////////////////////////////////////
/// resize
/// \pre    Their must be an array where elements can be stored.
/// \post   The array's values are all initialized to zero.
/// \param  A new size for the array.
/// \return None
/// \throw  None
///////////////////////////////////////////////////////////////////////
void Vec::resize(size_type new_size)
{
   Element empty;
   
   if (mArraySize == 0)
   {
      mArraySize = new_size;
      Element *new_array = new Element[mArraySize];//creating a new array two times larger than the old one
         
         
      mArray = new_array;
      mNumElements = mArraySize;
   }
   else if (new_size <= mArraySize && new_size < mNumElements)
   {
      mNumElements = new_size;
   }
   else
   {
      Element *new_array = new Element[new_size];//creating a new array two times larger than the old one
      size_type i;
      for (i = 0;i<mNumElements-1;i++)
      {
         new_array[i] = mArray[i];//copying the new array
      }
      mArraySize = new_size;
      delete [] mArray;
      mArray = new_array;//setting the array to the new array
   }
}
///////////////////////////////////////////////////////////////////////
/// insert (range)
/// \pre    Their must be an array with which to insert data.
/// \post   An array with data is inserted and the pointer Iterator is invalid
/// \param  Iterator I for the position to insert in
/// \param  Iterator i_start for the beginning of the range
/// \param  Iterator i_end for the end of the range
/// \return None
/// \throw  None
///////////////////////////////////////////////////////////////////////
void Vec::insert( iterator it, iterator i_start, iterator i_end)
{
   iterator temp = it;
   int loop_time = (i_end.mPosition-i_start.mPosition);
   Element e;
   for (int i = 0; i < loop_time;i++)
   {
      e = *(i_start.mIterator + i);
      temp = insert(e, temp);
      temp++;
   }   
}
///////////////////////////////////////////////////////////////////////
/// insert
/// \pre    Their must be an array with which to insert data.
/// \post   An array with data is inserted
/// \param  An Element that is to be insterted
/// \param  Iterator I for the position to insert in
/// \return a pointer to the new value
/// \throw  None
///////////////////////////////////////////////////////////////////////
Vec::iterator Vec::insert(const Element e, iterator it)
{
   Element* temp_array = new Element[mNumElements];
   for (size_type i = 0; i < mNumElements; i++)
   {
      temp_array[i] = mArray[i];//copying all elements over
   }
   
   
   if (mNumElements >= mArraySize)
   {
      resize(mArraySize * 2);
   }
   size_type i2 = 0;
   for (size_type i = 0; i < mNumElements; i++)
   {
      if (i2 == it.mPosition)
      {
         this->mArray[i2] = e;//copying all elements over
         i--;
      }
      else 
      {
         this->mArray[i2] = temp_array[i];//copying all elements over
      }
      i2++;
   }
   mNumElements++;
   
   Vec::iterator return_temp;
   return_temp.mIterator = (this->mArray + it.mPosition);
   return_temp.mPosition = it.mPosition;
 
   return return_temp;
 
}

/////////////////////////////////////////////////////////////////////// 
/// erase
/// \pre    Their must be an array with which to insert data.
/// \post   An array with data is inserted
/// \param  None
/// \return None
/// \throw  None
///////////////////////////////////////////////////////////////////////
Vec::iterator Vec::erase( iterator it)
{
   size_type i2 = 0;
   for (size_type i = 0; i < mNumElements-1; i++)
   {
      if (i != it.mPosition)
      {
         this->mArray[i] = this->mArray[i2];//copying all elements over
      }
      else 
      {
         i2++;
      
      }
   }
   mNumElements--;
   
   Vec::iterator return_temp;
   return_temp.mIterator = this->mArray + it.mPosition;
   return_temp.mPosition = it.mPosition;
   
   return return_temp;
}

// INQUIRY 

///////////////////////////////////////////////////////////////////////
/// size
/// \pre    Their must be an array where elements can be stored.
/// \post   None
/// \param  None
/// \return The number of elements in the vector.
/// \throw  None
///////////////////////////////////////////////////////////////////////
Vec::size_type Vec::size( void ) const
{
   return mNumElements;
}   



///////////////////////////////////////////////////////////////////////////////
/// \class        VecIterator
/// \author       Alex Hortin
/// \date         9/26/05
/// \brief        A standard lib vector iterator implementation.
///
/// This class is a vector that is built to act just like the standard library
/// vector iterator class.  It was built using the Vec class we created in 
/// project 3.  The Vec class is included within this assignment in Vec.h.  
///       
/// REVISION HISTORY:
///
/// 
///            
///////////////////////////////////////////////////////////////////////////////

// LIFECYCLE

/// Default constructor.
/// \pre    None
/// \post   An instance of the Vec class with 0 elements is created.
/// \param  None
/// \throw  None
VecIterator::VecIterator( void )
{
   mIterator = NULL;
   this->mPosition = 0;
}

///////////////////////////////////////////////////////////////////////
/// Copy Constructor.
/// \pre    An instance of VecIterator needs to be present.
/// \post   Two instances of the same VecIterator will exist.
/// \param  VecIterator is the VecIterator to copy from.
/// \throw  None
///////////////////////////////////////////////////////////////////////
VecIterator::VecIterator( const VecIterator & from )
{
   this->mIterator = from.mIterator; 
   this->mPosition = from.mPosition; 
}

///////////////////////////////////////////////////////////////////////
/// Destructor.
/// \pre    An instance of VecIterator has been created.
/// \post   The instance of VecIterator is destroyed.
///////////////////////////////////////////////////////////////////////
VecIterator::~VecIterator( void )
{
}

// OPERATORS

///////////////////////////////////////////////////////////////////////
/// Assignment operator.
/// \pre    The target must be assigned a value in memory.
/// \post   A reference value will be returned.
/// \param  An element of a vector.
/// \return A refence to that element
/// \throw  NONE
///////////////////////////////////////////////////////////////////////
const VecIterator &  VecIterator::operator=( const VecIterator & rhs )
{
   return rhs;//assinging the new value over
}

///////////////////////////////////////////////////////////////////////
/// Reference operator.
/// \pre    The target must be assigned a value in memory.
/// \post   A reference value will be returned.
/// \param  An element of a vector.
/// \return A refence to that element
/// \throw  NONE
///////////////////////////////////////////////////////////////////////
Element &  VecIterator::operator*( void )
{
   return *mIterator;//returning the reference
}

///////////////////////////////////////////////////////////////////////
/// -> operator.
/// \pre    The target must be assigned a value in memory.
/// \post   A reference value will be returned.
/// \param  An element of a vector.
/// \return A pointer to that element denoted by the iterator
/// \throw  NONE
///////////////////////////////////////////////////////////////////////
Element * VecIterator::operator->( void )
{
   return mIterator;//returning the pointer
}

///////////////////////////////////////////////////////////////////////
/// pre incriment operator.
/// \pre    The iterator must point to a value.
/// \post   The iterator moves to the next value.
/// \param  A vector that calls it
/// \return A refence to itself
/// \throw  NONE
///////////////////////////////////////////////////////////////////////
VecIterator & VecIterator::operator++( void )
{
   this->mIterator++;
   this->mPosition++;
   return *this;//incrimenting the iterator
}

///////////////////////////////////////////////////////////////////////
/// post incriment operator.
/// \pre    The iterator must point to a value.
/// \post   The iterator moves to the next value.
/// \param  A vector that calls it
/// \return The next value
/// \throw  NONE  
///////////////////////////////////////////////////////////////////////
VecIterator VecIterator::operator++( int )
{
   VecIterator temp;
   temp.mIterator = mIterator;
   temp.mPosition = mPosition;
   mIterator++;//incrimenting the iterator
   this->mPosition++;
   return temp;
}

///////////////////////////////////////////////////////////////////////
/// pre decriment operator.
/// \pre    The iterator must point to a value.
/// \post   The iterator moves to the previous value.
/// \param  A vector that calls it
/// \return A refence to itself
/// \throw  NONE
///////////////////////////////////////////////////////////////////////
VecIterator & VecIterator::operator--( void )
{
   this->mIterator--;
   this->mPosition--;
   return *this;//decrimenting the iterator
}

///////////////////////////////////////////////////////////////////////
/// post decriment operator.
/// \pre    The iterator must point to a value.
/// \post   The iterator moves to the previous value.
/// \param  A vector that calls it
/// \return The next value
/// \throw  NONE  
///////////////////////////////////////////////////////////////////////
VecIterator VecIterator::operator--( int )
{
   VecIterator temp;
   temp.mIterator = mIterator;
   temp.mPosition = mPosition;
   mIterator--;//incrimenting the iterator
   this->mPosition--;
   return temp;
}

///////////////////////////////////////////////////////////////////////   
/// equality operator.
/// \pre    The target must be assigned a value in memory.
/// \post   NONE
/// \param  An element of a vector.
/// \return bool based on whether it is equal or not
/// \throw  NONE   
///////////////////////////////////////////////////////////////////////
bool VecIterator::operator==( const VecIterator & rhs )
{
   if (this->mIterator == rhs.mIterator)//comparing the iterators
   {
      return true;
   }
   else
   {
      return false;
   }
}

///////////////////////////////////////////////////////////////////////
/// non-equality operator.
/// \pre    The target must be assigned a value in memory.
/// \post   NONE
/// \param  An element of a vector.
/// \return bool based on whether it is equal or not
/// \throw  NONE   
///////////////////////////////////////////////////////////////////////
bool VecIterator::operator!=( const VecIterator & rhs )
{
   if (this->mIterator != rhs.mIterator)//comparing the iterators
   {
      return true;
   }
   else
   {
      return false;
   }
}

// OPERATIONS 


// ACCESS and MUTATE
  

   
// INQUIRY
