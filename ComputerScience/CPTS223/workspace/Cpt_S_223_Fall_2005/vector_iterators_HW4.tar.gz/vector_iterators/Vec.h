#ifndef VEC_H    // include guard
#define VEC_H
///////////////////////////////////////////////////////////////////////////////
/// \class        Vec
/// \author       Alex Hortin (Originally Created by Kelly Fitz)
/// \date         9/7/05
/// \brief        A lousy vector implementation to get you started.
///
/// This class is a vector that is built to act just like the standard library
/// vector class.  It was built from a shell given to us by Kelly Fitz.  
///       
/// REVISION HISTORY:
///
/// 9/19/05    Improved the Vec Class to act more like the standard library.
///            I also removed Kelly's unnecissary commentary and variables that 
///            will not apply to my finished Vec class.
///
/// 9/27/05    Added begin, insert, end, and erase, also corrected tests.
///            
///////////////////////////////////////////////////////////////////////////////

// SYSTEM INCLUDES
//

#include <iostream>
#include <stdexcept>

// LOCAL INCLUDES
//
#include "Vec.h"//the sample sound player

// FORWARD REFERENCES
//
class VecIterator;

// CONSTANTS
//



// We are not worrying about template classes yet.
// Define the Element type here.
#ifndef ELEMENT_TYPE
#include <string>
typedef std::string Element;
#else
typedef ELEMENT_TYPE Element;
#endif


class Vec 
{
   public:
   
   typedef unsigned long size_type;
   typedef VecIterator iterator;
 
// LIFECYCLE

   /// Default constructor.
   /// \pre    None
   /// \post   An instance of the Vec class with 0 elements is created.
   /// \param  None
   /// \throw  None
   Vec( void );
   
   /// constructor with size given
   /// \pre    None
   /// \post   An instance of the Vec class with a user specified number of
   ///         elements is created.
   /// \param  None
   /// \throw  None
   Vec(size_type n);

   /// Copy Constructor.
   /// \pre    An instance of Vec needs to be present.
   /// \post   Two instances of the same Vec will exist.
   /// \param  Vec is the Vec to copy from.
   /// \throw  None
   Vec( const Vec & from );

   /// Destructor.
   /// \pre    An instance of PlaybackWindow has been created.
   /// \post   The instance of PlaybackWindow is destroyed.
   ~Vec( void );

// OPERATORS

   /// Assignment operator.
   /// THIS DOESN'T WORK YET!
   /// \param  rhs is the object to assign from.
   /// \return A reference to this Vec.
   Vec& operator=( const Vec & rhs );  

   /// Subscript operator (non-const).
   /// Provide access to the element at the specified rank.
   /// \pre    idx must be less than the number of elements
   ///         stored in the vector, or else it will crash!
   ///         FIX ME so I do something more sensible!
   /// \param  idx is the rank of the element to access
   /// \return access to the element at rank `idx'.
   Element & operator[]( size_type idx );  

   /// Subscript operator (const).   
   /// Provide read-only access to the element at the specified rank.
   /// \pre    idx must be less than the number of elements
   ///         stored in the vector, or else it will crash!
   ///         FIX ME so I do something more sensible!
   /// \param  idx is the rank of the element to access
   /// \return read-only access to the element at rank `idx'.
   const Element & operator[]( size_type idx ) const;  

// OPERATIONS 

   /// push_back
   /// \pre    A Vec must exist to make the call.
   /// \post   The vector has a new element appended to it and possibly
   ///         allocate more memory.  (Double what the number of elements were
   ///         before to insure n performance.)
   /// \param  An element to be appended onto the vector
   /// \return None
   /// \throw  None
   void push_back(Element E);

   /// pop_back
   /// \pre    The array where elements are stored must have something in it.
   /// \post   The last element is removed.
   /// \param  None
   /// \return None
   /// \throw  None
   void pop_back(void);
   
   /// front (const)
   /// \pre    The array where elements are stored must have something in it.
   /// \post   None
   /// \param  None
   /// \return A reference to the starting element of the array
   /// \throw  domain error if the array has nothing in it
   const Element& front(void) const;
   
   /// front 
   /// \pre    The array where elements are stored must have something in it.
   /// \post   None
   /// \param  None
   /// \return A reference to the starting element of the array
   /// \throw  domain error if the array has nothing in it
   Element& front(void);
   
   /// back (const)
   /// \pre    The array where elements are stored must have something in it.
   /// \post   None
   /// \param  None
   /// \return A const reference to the end element of the array
   /// \throw  domain error if the array has nothing in it
   const Element& back(void) const;
   
   /// back
   /// \pre    The array where elements are stored must have something in it.
   /// \post   None
   /// \param  None
   /// \return A reference to the end element of the array
   /// \throw  domain error if the array has nothing in it
   Element& back(void);
   
   /// begin 
   /// \pre    The array where elements are stored must have something in it.
   /// \post   None
   /// \param  None
   /// \return An iterator pointin g to the starting element of the array
   /// \throw  NONE
   iterator begin(void); 

   /// end 
   /// \pre    The array where elements are stored must have something in it.
   /// \post   None
   /// \param  None
   /// \return An iterator pointin g to the ending element of the array
   /// \throw  NONE
   iterator end(void); 
// ACCESS and MUTATE
  
   /// empty (const)
   /// \pre    Their must be an array where elements can be stored.
   /// \post   None
   /// \param  None
   /// \return A bool for the array being full or not.
   /// \throw  None
   bool empty();
   
   /// empty (const)
   /// \pre    Their must be an array where elements can be stored.
   /// \post   None
   /// \param  None
   /// \return A bool for the array being full or not.
   /// \throw  None
   bool empty() const;
   
   /// clear
   /// \pre    Their must be an array where elements can be stored.
   /// \post   The array's elements are removed.
   /// \param  None
   /// \return None
   /// \throw  None
   void clear(void);

   /// resize
   /// \pre    Their must be an array where elements can be stored.
   /// \post   The array's values are all initialized to zero.
   /// \param  A new size for the array.
   /// \return None
   /// \throw  None
   void resize(size_type new_size); 
   
   /// insert (range)
   /// \pre    Their must be an array with which to insert data.
   /// \post   An array with data is inserted
   /// \param  None
   /// \return None
   /// \throw  None
   void insert( iterator it, iterator it_start, iterator it_end);
   
   /// insert
   /// \pre    Their must be an array with which to insert data.
   /// \post   An array with data is inserted
   /// \param  None
   /// \return None
   /// \throw  None
   iterator insert( Element e, iterator it);
 
   /// erase
   /// \pre    Their must be an array with which to insert data.
   /// \post   An array with data is inserted
   /// \param  None
   /// \return None
   /// \throw  None
   iterator erase( iterator it);
   
// INQUIRY
   /// size
   /// \pre    Their must be an array where elements can be stored.
   /// \post   None
   /// \param  None
   /// \return The number of elements in the vector.
   /// \throw  None
   size_type size( void ) const;
   
   
// MEMBER VARIABLES
private:

   /// contents of the vector
   Element * mArray;
   
   /// size of vector memory
   size_type mArraySize;
   
   /// number of elements stored in the vector
   size_type mNumElements;

}; // end of class Vec


///////////////////////////////////////////////////////////////////////////////
/// \class        VecIterator
/// \author       Alex Hortin
/// \date         9/26/05
/// \brief        A standard lib vector iterator implementation.
///
/// This class is a vector that is built to act just like the standard library
/// vector iterator class.  It was built using the Vec class we created in 
/// project 3.  The Vec class is included within this assignment in Vec.h.  
///       
/// REVISION HISTORY:
///
/// 
///            
///////////////////////////////////////////////////////////////////////////////

class VecIterator
{

   public:
   friend class Vec;
   // LIFECYCLE

   /// Default constructor.
   /// \pre    None
   /// \post   An instance of the Vec class with 0 elements is created.
   /// \param  None
   /// \throw  None
   VecIterator( void );

   /// Copy Constructor.
   /// \pre    An instance of VecIterator needs to be present.
   /// \post   Two instances of the same VecIterator will exist.
   /// \param  VecIterator is the VecIterator to copy from.
   /// \throw  None
   VecIterator( const VecIterator & from );

   /// Destructor.
   /// \pre    An instance of VecIterator has been created.
   /// \post   The instance of VecIterator is destroyed.
   ~VecIterator( void );

// OPERATORS
   
   /// Assignment operator.
   /// \pre    The target must be assigned a value in memory.
   /// \post   A reference value will be returned.
   /// \param  An element of a vector.
   /// \return A refence to that element
   /// \throw  NONE
   const VecIterator &  operator=( const VecIterator & rhs );
   
   /// Reference operator.
   /// \pre    The target must be assigned a value in memory.
   /// \post   A reference value will be returned.
   /// \param  An element of a vector.
   /// \return A refence to that element
   /// \throw  NONE
   Element &  operator*( void );
   
   /// -> operator.
   /// \pre    The target must be assigned a value in memory.
   /// \post   A reference value will be returned.
   /// \param  An element of a vector.
   /// \return A pointer to that element denoted by the iterator
   /// \throw  NONE 
   Element * operator->( void );
   
   /// pre incriment operator.
   /// \pre    The iterator must point to a value.
   /// \post   The iterator moves to the next value.
   /// \param  A vector that calls it
   /// \return A refence to itself
   /// \throw  NONE
   VecIterator & operator++( void );
   
   /// post incriment operator.
   /// \pre    The iterator must point to a value.
   /// \post   The iterator moves to the next value.
   /// \param  A vector that calls it
   /// \return The next value
   /// \throw  NONE  
   VecIterator operator++( int );
   
   /// pre decriment operator.
   /// \pre    The iterator must point to a value.
   /// \post   The iterator moves to the previous value.
   /// \param  A vector that calls it
   /// \return A refence to itself
   /// \throw  NONE
   VecIterator & operator--( void );
   
   /// post decriment operator.
   /// \pre    The iterator must point to a value.
   /// \post   The iterator moves to the previous value.
   /// \param  A vector that calls it
   /// \return The next value
   /// \throw  NONE  
   VecIterator operator--( int );
   
   /// equality operator.
   /// \pre    The target must be assigned a value in memory.
   /// \post   NONE
   /// \param  An element of a vector.
   /// \return bool based on whether it is equal or not
   /// \throw  NONE   
   bool operator==( const VecIterator & rhs );
   
   /// non-equality operator.
   /// \pre    The target must be assigned a value in memory.
   /// \post   NONE
   /// \param  An element of a vector.
   /// \return bool based on whether it is equal or not
   /// \throw  NONE   
   bool operator!=( const VecIterator & rhs );

// OPERATIONS 


// ACCESS and MUTATE
  

   
// INQUIRY



// MEMBER VARIABLES

private:
   Element * mIterator;
   unsigned int mPosition;

}; // end of class VecIterator

#endif
