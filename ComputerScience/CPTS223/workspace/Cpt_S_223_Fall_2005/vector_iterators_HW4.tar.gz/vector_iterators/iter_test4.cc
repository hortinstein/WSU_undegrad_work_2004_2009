// iter_test4.cc
//
// Test single-element insertion into and erasure from vector.
//
#include <iostream>
using std::cout;
using std::endl;

#include <stdexcept>

#include <string>
using std::string;

#include "Vec.h"
typedef Vec< string > Vector;

int main( void )
{
   Vector v;  
   Vector::iterator iter;  
   
   cout << "inserting \"one\" at end of empty vector" << endl;
   v.insert( v.end(), "one" );

   cout << "should print: \"one\"" << endl;
   for ( iter = v.begin(); iter != v.end(); ++iter )
   {
      cout << *iter << " ";
   }
   cout << "\n";

   cout << "clearing, inserting \"three\" at beginning of empty vector" << endl;
   v.clear();
   v.insert( v.begin(), "three" );

   cout << "should print: \"three\"" << endl;
   for ( iter = v.begin(); iter != v.end(); ++iter )
   {
      cout << *iter << " ";
   }
   cout << "\n";
   
   cout << "inserting \"four\" through \"six\" at end" << endl;
   v.insert( v.end(), "four" );
   v.insert( v.end(), "five" );
   v.insert( v.end(), "six" );

   cout << "should print: \"three four five six\"" << endl;
   for ( iter = v.begin(); iter != v.end(); ++iter )
   {
      cout << *iter << " ";
   }
   cout << "\n";
   
   cout << "inserting \"zero\" through \"two\" at beginning" << endl;
   v.insert( v.begin(), "two" );
   v.insert( v.begin(), "one" );
   v.insert( v.begin(), "zero" );

   cout << "should print: \"zero one two three four five six\"" << endl;
   for ( iter = v.begin(); iter != v.end(); ++iter )
   {
      cout << *iter << " ";
   }
   cout << "\n";
   
   cout << "inserting \"one-and-a-half\" at a twice-incremented position" << endl;
   Vector::iterator pos = v.begin();
   ++pos;
   ++pos;
   v.insert( pos, "one-and-a-half" );
  
   cout << "should print: \"zero one one-and-a-half two three four five six\"" << endl;
   for ( iter = v.begin(); iter != v.end(); ++iter )
   {
      cout << *iter << " ";
   }
   cout << "\n";
   
   cout << "erasing first element" << endl;
   v.erase( v.begin() );

   cout << "should print: \"one one-and-a-half two three four five six\"" << endl;
   for ( iter = v.begin(); iter != v.end(); ++iter )
   {
      cout << *iter << " ";
   }
   cout << "\n";
   
   cout << "erasing last element" << endl;
   v.erase( --v.end() );

   cout << "should print: \"one one-and-a-half two three four five\"" << endl;
   for ( iter = v.begin(); iter != v.end(); ++iter )
   {
      cout << *iter << " ";
   }
   cout << "\n";
   
   cout << "erasing end" << endl;
   v.erase( v.end() );

   cout << "should print: \"one one-and-a-half two three four five\" (no change)" << endl;
   for ( iter = v.begin(); iter != v.end(); ++iter )
   {
      cout << *iter << " ";
   }
   cout << "\n";

   cout << "erasing element at second position" << endl;
   iter = v.begin();
   ++iter;
   v.erase( iter );

   cout << "should print: \"one two three four five\"" << endl;
   for ( iter = v.begin(); iter != v.end(); ++iter )
   {
      cout << *iter << " ";
   }
   cout << "\n";
   
   cout << "clearing and erasing end of empty vector" << endl;
   v.clear();
   v.erase( v.end() );

   cout << "should print nothing" << endl;
   for ( iter = v.begin(); iter != v.end(); ++iter )
   {
      cout << *iter << " ";
   }
   cout << "\n";

   cout << "erasing end of default-constructed empty vector" << endl;
   v = Vector();
   v.erase( v.end() );

   cout << "should print nothing" << endl;
   for ( iter = v.begin(); iter != v.end(); ++iter )
   {
      cout << *iter << " ";
   }
   cout << "\n";

   cout << "COMPLETED iterator test4" << endl << endl;
   return 0;
}
