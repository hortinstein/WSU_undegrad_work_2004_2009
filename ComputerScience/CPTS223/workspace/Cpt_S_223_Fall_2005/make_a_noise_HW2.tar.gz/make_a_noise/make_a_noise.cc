///////////////////////////////////////////////////////////////////////////////
/// \author       Alex Hortin
/// \date         9/1/05
/// \brief        This is the test file for my PlaybackWindow class
///
/// It uses one test cases to test the functionality of the PlaybackWindow 
///class.  It will open up a sound file and a window to play it
///
/// REVISION HISTORY:
///
/// 9/13    I added exception handling
///            
///////////////////////////////////////////////////////////////////////////////


#include <FL/Fl.H>//the FLTK source files
#include <FL/Fl_Window.H>//the FLTK source files
#include <FL/Fl_Button.H>//the FLTK source files
#include <FL/Fl_Input.H>//the FLTK source files
#include <FL/Fl_Output.H>//the FLTK source files 
#include "PlaybackWindow.h"//the class to be tested
#include "SamplePlayer.h"//a class that contains the code to play the actual sound
#include <iostream>


int main(void)
{
	try
   {
      PlaybackWindow w( "../explosion.wav" );//calls the window/player constructor with the argumnent of the files name
      return Fl::run();//returns the FLTK windows if successfull.
   }
   catch (std::domain_error)
   {
      std::cout << "No File Found..try again" << std::endl;//prints out the error
   }
}
