///////////////////////////////////////////////////////////////////////////////
/// \class        DatabaseWindow
/// \author       Alex Hortin
/// \date         10/25/05  
/// \brief        This class creates a Database window that inherits 
///               from the FLTK class and uses the templated Tree class.
///
/// This Class is the window that you will see that contains all the work 
/// behind the program interface.  It will create the file structure and put it
/// all into a tree. 
///
///       
/// REVISION HISTORY:
///
/// NONE
///            
///////////////////////////////////////////////////////////////////////////////

// SYSTEM INCLUDES
//

// LOCAL INCLUDES
// 
#include "Tree.h"
#include "DatabaseWindow.h"

// FORWARD REFERENCES
//


// CONSTANTS
//


// LIFECYCLE

///////////////////////////////////////////////////////////////////////
/// Default constructor.
/// \pre    None
/// \post   An instance of the DatabaseWindow is created.
/// \param  A string containing the name for a file.
/// \throw  None
///////////////////////////////////////////////////////////////////////
DatabaseWindow::DatabaseWindow (char * file_name):Fl_Window(300,500,"Photo Database")//the basic constructor used for testing
{
   begin();
      this->mDirectoryName = (file_name);
      this->mDatabase = new Tree<std::string>("Root");
   
      buildDatabase(mDirectoryName);
      
      //mDatabase->print(mDatabase->root());
      
      mSearch = new Fl_Input(50, 20, 150, 30, "Query:");//defines the label and text box
      
      mSearchButton = new Fl_Button( 210, 20, 70, 30, "S&earch");//displays the button to tell
      mSearchButton->callback( cb_search, this );//calls the function after the button has been pressed
   
      mResults = new Fl_Hold_Browser(20, 60, 260, 300, "");//defines the answer box
      mResults->callback( cb_browser, this ); //callback
      mFileInfo = new Fl_Multiline_Output(20, 380, 260, 100, "");
   end();//ends the function
   show();//shows the window
      
}


///////////////////////////////////////////////////////////////////////
/// Destructor.
/// \pre    An instance of DatabaseWindow has been created.
/// \post   The instance of DatabaseWindow is destroyed.
///////////////////////////////////////////////////////////////////////
DatabaseWindow::~DatabaseWindow()//the destructor
{
   
}
// OPERATORS

// OPERATIONS 
  
///////////////////////////////////////////////////////////////////////  
/// convertMonth
/// \pre    Their must be a string given as an argument.
/// \post   A file structure contained in a tree is created and stored in this class.
/// \param  the string to convert
/// \return None
/// \throw  None
///////////////////////////////////////////////////////////////////////
std::string DatabaseWindow::convertMonth ( std::string monthconvert )
{
   switch (monthconvert[1])
   {
      case '1':
      return "january";
      break;
      
      case '2':
      return "febuary";
      break;
      
      case '3':
      return "march";
      break;
      
      case '4':
      return "april";
      break;
      
      case '5':
      return "may";
      break;
      
      case '6':
      return "june";
      break;
      
      case '7':
      return "july";
      break;
      
      case '8':
      return "august";
      break;
      
      case '9':
      return "september";
      break;
      
      case 'A':
      return "october";
      break;
      
      case 'B':
      return "november";
      break;
      
      case 'C':
      return "december";
      break;
      
   }
   return "";
}

///////////////////////////////////////////////////////////////////////
/// convertDate
/// \pre    Their must be a string given as an argument.
/// \post   A file structure contained in a tree is created and stored in this class.
/// \param  the string to convert
/// \return None
/// \throw  None
///////////////////////////////////////////////////////////////////////
std::string DatabaseWindow::convertDate ( std::string dateconvert )
{
   char new_chars[3];
   new_chars[0] = dateconvert[2];
   new_chars[1] = dateconvert[3];
   new_chars[2] = '\0';
   std::string new_string = new_chars;
   return new_string;
}
 
///////////////////////////////////////////////////////////////////////
/// buildDatabase
/// \pre    Their must be a directory given as a command line argument.
/// \post   A file structure contained in a tree is created and stored in this class.
/// \param  a folder name to search
/// \return None
/// \throw  None
///////////////////////////////////////////////////////////////////////
void DatabaseWindow::buildDatabase ( std::string pathName)
{
   DIR * dirp = opendir( pathName.c_str() );//creating the file stream
  
   if (dirp == NULL)
   {
      throw std::domain_error("OMFG WTFBBQ PWNT");
   }
   
   struct dirent * dp = readdir( dirp );
   while ( 0 != dp )//checking to make sure that these is still stuff in there
   {
      std::string name = dp->d_name;
      
      
      struct stat dpstats;
      stat( (pathName + '/' + name).c_str(), &dpstats );
      
      
      if (name[0] != '.')
      {
         if (S_ISDIR(dpstats.st_mode))//checking if the file pointer points to a directory
         {
            buildDatabase(pathName + '/' + name);//recursive call to keep on building directory
         }
         
         cPosition<std::string> Pos = getMonth(convertMonth(name));
  
         if (Pos.isNull())
         {
            Pos = mDatabase->addChild(mDatabase->root(),convertMonth(name));
            Pos = mDatabase->addChild(Pos,convertDate(name));
            if (name.size() == 12 && name[8] == '.' && (name[9] == 'J' || name[9] == 'j') && (name[10] == 'P' || name[10] == 'p') && (name[11] == 'G' || name[11] == 'g'))  
            {
               mDatabase->addChild(Pos,(pathName + "/" + name));
            }
         }
         else
         {
            cPosition<std::string> Pos_store = Pos;
            Pos = getDate(Pos,convertDate(name));
            
            if (Pos.isNull())
            {
               Pos = mDatabase->addChild(Pos_store,convertDate(name));
               if (name.size() == 12 && name[8] == '.' && (name[9] == 'J' || name[9] == 'j') && (name[10] == 'P' || name[10] == 'p') && (name[11] == 'G' || name[11] == 'g'))  
               {
                  mDatabase->addChild(Pos,pathName + '/' + name);
               }
            }
            else
            {
               if (name.size() == 12 && name[8] == '.' && (name[9] == 'J' || name[9] == 'j') && (name[10] == 'P' || name[10] == 'p') && (name[11] == 'G' || name[11] == 'g'))  
               {
                  mDatabase->addChild(Pos,pathName + '/' + name);
               }
            }
         }
      }
      dp = readdir( dirp );//moves pointer to next file or dir
   }
   
   closedir( dirp );//closes directry 
}

///////////////////////////////////////////////////////////////////////
/// getMonth
/// \pre    Their must be a string given as an argument.
/// \post   A file structure contained in a tree is created and stored in this class.
/// \param  None
/// \return a position
/// \throw  None
///////////////////////////////////////////////////////////////////////
cPosition<std::string> DatabaseWindow::getMonth ( std::string month)
{
   cPositionIterator<std::string> iter = mDatabase->children(mDatabase->root());
   cPosition<std::string> pos;
   while (iter.hasNext())
   {
      pos = iter.next();
      if (pos.element() == month)
      {
         return pos;
      }
   }
   cPosition<std::string> pos2;
   return pos2;
}

///////////////////////////////////////////////////////////////////////
/// getDate
/// \pre    The position must have been returned 
/// \post   A file structure contained in a tree is created and stored in this class.
/// \param  a position provided by getMonth
/// \return None
/// \throw  None
///////////////////////////////////////////////////////////////////////
cPosition<std::string> DatabaseWindow::getDate (cPosition<std::string> Month, std::string date )
{
   cPositionIterator<std::string> iter = this->mDatabase->children(Month);
   cPosition<std::string> pos;
   while (iter.hasNext())
   {
      pos = iter.next();
      if (pos.element() == date)
      {
         return pos;
      }
   }
   cPosition<std::string> pos2;
   return pos2;
}

///////////////////////////////////////////////////////////////////////
/// searchRecurse
/// \pre    The position must have been returned 
/// \post   A file structure contained in a tree is created and stored in this class.
/// \param  the string to convert
/// \return None
/// \throw  None
///////////////////////////////////////////////////////////////////////
void DatabaseWindow::searchRecurse (cPosition<std::string> Search )
{
   if ( mDatabase->isExternal(Search) )
   {
      std::string temp;
      for (int i = 12; i >= 0; i--)
      {
         temp+=(Search.element())[(Search.element().size())-i]; 
      }
      mResults->add(temp.c_str());
      hold_browser_ish.push_back(Search.element());
   }
   else
   {
      cPositionIterator<std::string> herro = mDatabase->children(Search);
      while (herro.hasNext())
      {
         searchRecurse(herro.next());
      }
   }
}

// ACCESS and MUTATE

///////////////////////////////////////////////////////////////////////      
/// cb_search is the call that the program makes when the search button 
/// is pressed.  It than calls a search of the tree for results.
/// \pre   the pre conditions for this is the button being pressed and a tree existing to search through 
/// \post  the mResults browser will be modified
/// \param  a widget pointer
/// \return void
/// \throw  n/a
///////////////////////////////////////////////////////////////////////
void DatabaseWindow::cb_search(Fl_Widget*, void* v)//the button for tell me
{
   ( (DatabaseWindow*)v )->cb_search_i();
}
///////////////////////////////////////////////////////////////////////
/// cb_search is the call that the program makes when the search button 
/// is pressed.  It than calls a search of the tree for results.
/// \pre   the pre conditions for this is the button being pressed and a tree existing to search through 
/// \post  the mResults browser will be modified
/// \param  a widget pointer
/// \return void
/// \throw  n/a
///////////////////////////////////////////////////////////////////////
inline void DatabaseWindow::cb_search_i()//the call that the button makes
{
   mResults->clear();
   hold_browser_ish.clear();
   std::string searching = (mSearch->value());  
   if (searching.size() != 0)
   {
      cPosition<std::string> Pos = getMonth(searching);
      if (Pos.isNull())
      {
         std::string date;
         date+=searching[0];
         date+=searching[1];
         
         std::string month;
         for (unsigned int i = 3; i < searching.size(); i++)
         {
            month+=searching[i];
         }
         cPosition<std::string> Pos = getMonth(month);
         if (Pos.isNull())
         {
            return;
         }
         Pos = getDate(Pos,date);
         if (Pos.isNull())
         {
            return;
         }
         else searchRecurse(Pos);
      }
      else
      {
         searchRecurse(Pos);
      }
   }
}

///////////////////////////////////////////////////////////////////////
/// cb_browser is the call that the program makes when the search button 
/// is pressed.  It than calls a search of the tree for results.
/// \pre   the pre conditions for this is the button being pressed and a tree existing to search through 
/// \post  the mResults browser will be modified
/// \param  a widget pointer
/// \return void
/// \throw  n/a
///////////////////////////////////////////////////////////////////////
void DatabaseWindow::cb_browser(Fl_Widget*, void* v)//the button for tell me
{
   ( (DatabaseWindow*)v )->cb_browser_i();
}

///////////////////////////////////////////////////////////////////////
/// cb_browser is the call that the program makes when the search button 
/// is pressed.  It than calls a search of the tree for results.
/// \pre   the pre conditions for this is the button being pressed and a tree existing to search through 
/// \post  the mResults browser will be modified
/// \param  a widget pointer
/// \return void
/// \throw  n/a
///////////////////////////////////////////////////////////////////////
inline void DatabaseWindow::cb_browser_i()//the call that the button makes
{
   unsigned int compare_temp = (mResults->value()-1);
   if (compare_temp > hold_browser_ish.size())
   {
      return; 
   }
   std::string temp;
   for (unsigned int i = ((hold_browser_ish[mResults->value()-1].size()) - hold_browser_ish[mResults->value()-1].find(mDirectoryName,0)); i > 0; i--)
   {
      temp+=(hold_browser_ish[mResults->value()-1][(hold_browser_ish[mResults->value()-1].size()) - i]); 
   }
   struct stat dpstats;
   stat( hold_browser_ish[mResults->value() - 1].c_str(), &dpstats  );
   int size_int = (dpstats.st_size / 1024);
   
   
   char* woots = new char[20];
   sprintf(woots, "%d", size_int);
   
   std::string size_temp = woots;
   
   std::string file_mod = ctime(&dpstats.st_mtime);
   
   temp = temp + "\n" + "Size: " + size_temp + " k \n" + "Modified: " + file_mod;
   mFileInfo->value(temp.c_str());
   
   

}
// INQUIRY
