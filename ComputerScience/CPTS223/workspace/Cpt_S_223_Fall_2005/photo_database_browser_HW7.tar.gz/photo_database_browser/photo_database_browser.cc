///////////////////////////////////////////////////////////////////////////////
/// \author       Alex Hortin
/// \date         10/24/05
/// \brief        This is my test file used to test my implementation of a tree.
///
/// I am creating a tree and this will be the file that I use to test all of
/// the various functions contained within the tree.  It will try to test all
/// of the options that the interface gives the user. This time it will be used
/// to emulate a file structure simalar to the structure used in Unix file 
/// systems.
///
/// REVISION HISTORY:
///
/// NONE
///            
///////////////////////////////////////////////////////////////////////////////

// SYSTEM INCLUDES
//

// LOCAL INCLUDES
//
#include "Tree.h" 
#include "DatabaseWindow.h"                               

// FUNCTIONS

//         /.automount/zeus/vol/vol0/vol0/users/ahortin/workspace/photo_database_browser


int main (int argc, char *argv[])
{
   try
   {
      DatabaseWindow w(argv[1]);//calls the window/player constructor with the argumnent of the files name
      return Fl::run();//returns the FLTK windows if successfull.
   }
   catch (std::domain_error)
   {
      std::cout << "No Directry Found..try again" << std::endl;//prints out the error
   }
}
