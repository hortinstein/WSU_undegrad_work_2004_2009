///////////////////////////////////////////////////////////////////////////////
/// \author       Alex Hortin
/// \date         10/24/05
/// \brief        This is my test file used to test my filesystem
///
/// I am creating a tree and this will be the file that I use to test all of
/// the various functions contained within the filesystem.  It will try to test 
/// all of the options that the interface gives the user. This time it will be
/// used to emulate a file structure simalar to the structure used in Unix file 
/// systems.
///
/// REVISION HISTORY:
///
/// NONE
///            
///////////////////////////////////////////////////////////////////////////////

// SYSTEM INCLUDES
//

// LOCAL INCLUDES
//
#include "File.h"
#include "FileJpeg.h"  
#include "FileDir.h"        
#include "FileWav.h"

// FUNCTIONS

//         /.automount/zeus/vol/vol0/vol0/users/ahortin/workspace/photo_database_browser


int main (void)//int argc, char *argv[])
{
   std::cout << std::endl << "Showing a picture of a cute girl I met at alive...than showing the info about it" << std::endl ;
   File * f = File::create("./stuff/alivegirl.JPG");
   Fl_Window * w = f->preview();
   w->show();
   std::cout << f->name() << std::endl;
   std::cout << *f;
   
   std::cout << std::endl << "Playing a sound that contains some advice...than showing the info about it" << std::endl;
   File * t = File::create("./stuff/ideal.WAV");
   Fl_Window * j = t->preview();
   j->show();
   std::cout << t->name() << std::endl;
   std::cout << *t;
   
   std::cout << std::endl << "Calling up a directory...than showing the info about it" << std::endl;
   File * p = File::create("./stuff");
   Fl_Window * r = p->preview();
   r->show();
   std::cout << p->name() << std::endl;
   std::cout << *p;
   return Fl::run();
}
