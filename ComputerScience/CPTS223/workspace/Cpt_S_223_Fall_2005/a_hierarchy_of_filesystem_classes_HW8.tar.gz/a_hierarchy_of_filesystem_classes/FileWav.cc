///////////////////////////////////////////////////////////////////////////////
/// \class        FileWav
/// \author       Alex Hortin
/// \date         10/13/05
/// \brief        This is the JPEG file type
///
/// This is the class that inherits from file.  It is derived from file, and 
/// redefines some of the key function using the 1337 dark art of polymorphism.  
///       
/// REVISION HISTORY:
///
/// NONE
///            
///////////////////////////////////////////////////////////////////////////////

// SYSTEM INCLUDES
//

// LOCAL INCLUDES
//
#include "File.h"
#include "FileWav.h"
// FORWARD REFERENCES
//

// CONSTANTS
//

// LIFECYCLE

///////////////////////////////////////////////////////////////////////
/// Default constructor.
/// \pre    Function must be called.
/// \post   A default file is constructed
/// \throw  NONE
///////////////////////////////////////////////////////////////////////
FileWav::FileWav( std::string path)
{
   unsigned int i = path.size();
      
   while (path[i] != '/' && i > 0)
   {
      i--;
   }
   i++;
   std::string name;
   for (i = i; i < path.size(); i++)
   {
      mFileName = mFileName + path[i];
   }
   mPath = path;
   
   //creating the info stream
   
   SF_INFO Info;//the info struct for the file
   SNDFILE * Sfp = 0;//pointer to the sound file
   sf_count_t mNsamps = 0;//stores the ammount of samples
   
   Info.format = 0;
   Sfp = sf_open( mPath.c_str(), SFM_READ, &Info );//attempts to open the file
   if ( 0 == Sfp )//if file can't open
   {
      throw std::domain_error("ERROR reading file");//throwing an exception
      return;
   }
   mNsamps = Info.frames * Info.channels;//figuring out how many samples are there

   ostringstream temp_w;
   temp_w << mNsamps;
   ostringstream temp_h;
   temp_h << Info.samplerate;
   
   this->mInfoString = this->mInfoString + mPath + '\n' + "Stereo Sound File \n" + temp_w.str() + " sample frames at " + temp_h.str() + " Hz \n";
   
}

///////////////////////////////////////////////////////////////////////
/// Destructor.
/// \pre    There must be something to mercelessly rape pillage and destroy
/// \post   Poof! that bitch is gone!
///////////////////////////////////////////////////////////////////////
FileWav::~FileWav( void )
{
}

// OPERATORS

///////////////////////////////////////////////////////////////////////
/// Assignment operator.
/// \pre    The fuction is called by trying to assign
/// \post   NONE
/// \param  rhs is the object to assign from.
/// \return A reference to this Name.
/// \throw  NONE
///////////////////////////////////////////////////////////////////////
FileWav& FileWav::operator=( const FileWav & rhs )
{
   this->mPath = rhs.mPath;
   this->mFileName = rhs.mFileName;
   return *this;
}

// OPERATIONS 

// ACCESS and MUTATE

// INQUIRY

///////////////////////////////////////////////////////////////////////
/// preview
/// \pre    The class has been created
/// \post   A string is returned with the name in it
/// \param  None
/// \return A string
/// \throw  NONE
///////////////////////////////////////////////////////////////////////
Fl_Window* FileWav::preview(void)
{
   Fl_Window* t = new PlaybackWindow ( mPath );
   return t;
}
