///////////////////////////////////////////////////////////////////////////////
/// \class        File
/// \author       Alex Hortin
/// \date         10/13/05
/// \brief        This is the base class for all of the file types
///
/// This is the class that makes all of the files work, due to inheritance and
/// polymorphism.  
///       
/// REVISION HISTORY:
///
/// NONE
///          
///////////////////////////////////////////////////////////////////////////////
#include "File.h"                                // class implemented

// SYSTEM INCLUDES
//

// LOCAL INCLUDES
//
#include "FileJpeg.h"  
#include "FileDir.h"        
#include "FileWav.h"

// LIFECYCLE

///////////////////////////////////////////////////////////////////////
/// Default constructor.
/// \pre    Function must be called.
/// \post   A default file is constructed
/// \throw  NONE
///////////////////////////////////////////////////////////////////////
File::File( void )
{
}

///////////////////////////////////////////////////////////////////////
/// Copy Constructor.
/// \pre    A file must be there to copy
/// \post   Two copies of the same file exist.
/// \param  from is the Name to copy from.
/// \throw  NONE
///////////////////////////////////////////////////////////////////////
File::File( const File & from )
{
   this->mPath = from.mPath;
   this->mFileName = from.mFileName;
}

///////////////////////////////////////////////////////////////////////
/// Destructor.
/// \pre    There must be something to mercelessly rape pillage and destroy
/// \post   Poof! that bitch is gone!
///////////////////////////////////////////////////////////////////////
File::~File( void )
{
}

// OPERATORS

// OPERATIONS 

///////////////////////////////////////////////////////////////////////
/// create
/// \pre    NONE
/// \post   A new instance of the concrete class is created
/// \param  A path in the form of the string
/// \return A pointer to a file
/// \throw  An exception if the path does not exist
///////////////////////////////////////////////////////////////////////
File * File::create( const std::string & path )
{
   struct stat dpstats;
   stat( (path).c_str(), &dpstats );
   
   if (S_ISDIR(dpstats.st_mode))
   {
      File* temp = new FileDir(path);
      return temp;
   }
   else 
   {
   
      unsigned int i = path.size();
      
      while (path[i] != '.' && i > 0)
      {
         i--;
      }
      
      std::string ext;
      for (i = i; i < path.size(); i++)
      {
         ext = ext + path[i];
      }
      
      if (ext == ".JPG" || ext == ".jpg")
      {
         File* temp = new FileJpeg(path);
         return temp;
      }
      else if( ext == ".WAV" || ext == ".wav")
      {
         File* temp = new FileWav(path);
         return temp;
      }
      else
      {
         throw std::domain_error("Not a jpeg, wav or directory...wootding!");
      }
   }
}

// ACCESS and MUTATE

// INQUIRY

///////////////////////////////////////////////////////////////////////
/// name
/// \pre    The class has been created
/// \post   A string is returned with the name in it
/// \param  None
/// \return A string containing name
/// \throw  NONE
///////////////////////////////////////////////////////////////////////
std::string File::name(void)
{
   return mFileName;
}

///////////////////////////////////////////////////////////////////////
/// path
/// \pre    The class has been created
/// \post   A string is returned with the path in it
/// \param  None
/// \return A strings containing path
/// \throw  NONE
///////////////////////////////////////////////////////////////////////
std::string File::path(void)
{
   return mPath;
}

///////////////////////////////////////////////////////////////////////
/// infoString
/// \pre    The class has been created
/// \post   A string is returned with the name in it
/// \param  None
/// \return A string
/// \throw  NONE
///////////////////////////////////////////////////////////////////////
std::string File::infoString(void) const
{
   return mInfoString;
}

///////////////////////////////////////////////////////////////////////
/// preview
/// \pre    The class has been created
/// \post   A string is returned with the name in it
/// \param  None
/// \return A string
/// \throw  NONE
///////////////////////////////////////////////////////////////////////
//Fl_Window* File::preview(void)
//{
//}

// INLINE METHODS
//

///////////////////////////////////////////////////////////////////////
/// Output operator.
/// \pre    The fuction is called by trying to assign
/// \post   NONE
/// \param  rhs is the object to print from.
/// \return A reference to this Name.
/// \throw  NONE
///////////////////////////////////////////////////////////////////////
std::ostream& operator << (std::ostream& os, const File & rhs )
{
   std::string h = rhs.infoString();
   os << h;
   return os;//returns ostream
}
