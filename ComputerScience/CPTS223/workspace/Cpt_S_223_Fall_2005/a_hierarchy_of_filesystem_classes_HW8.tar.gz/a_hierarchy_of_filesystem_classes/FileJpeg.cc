///////////////////////////////////////////////////////////////////////////////
/// \class        FileJpeg
/// \author       Alex Hortin
/// \date         10/13/05
/// \brief        This is the JPEG file type
///
/// This is the class that inherits from file.  It is derived from file, and 
/// redefines some of the key function using the 1337 dark art of polymorphism.  
///       
/// REVISION HISTORY:
///
/// NONE
///            
///////////////////////////////////////////////////////////////////////////////

// SYSTEM INCLUDES
//

// LOCAL INCLUDES
//
#include "File.h"
#include "FileJpeg.h"
// FORWARD REFERENCES
//

// CONSTANTS
//

// LIFECYCLE

///////////////////////////////////////////////////////////////////////
/// Default constructor.
/// \pre    Function must be called.
/// \post   A default file is constructed
/// \throw  NONE
///////////////////////////////////////////////////////////////////////
FileJpeg::FileJpeg(std::string path)
{
   unsigned int i = path.size();
      
   while (path[i] != '/' && i > 0)
   {
      i--;
   }
   i++;
   std::string name;
   for (i = i; i < path.size(); i++)
   {
      mFileName = mFileName + path[i];
   }
   mPath = path;
   
   //creating the info stream
   Fl_JPEG_Image * img = new Fl_JPEG_Image( mPath.c_str() );
   if (img == NULL)
   {
      throw std::domain_error("doesnt exist");
   }
   ostringstream temp_w;
   temp_w << img->w();
   ostringstream temp_h;
   temp_h << img->h();
   
   this->mInfoString = this->mInfoString + mPath + '\n' + "JPEG IMAGE \n" + temp_w.str() + " by " + temp_h.str() + "pixels \n";
   
}

///////////////////////////////////////////////////////////////////////
/// Destructor.
/// \pre    There must be something to mercelessly rape pillage and destroy
/// \post   Poof! that bitch is gone!
///////////////////////////////////////////////////////////////////////
FileJpeg::~FileJpeg( void )
{
}

// OPERATORS

///////////////////////////////////////////////////////////////////////
/// Assignment operator.
/// \pre    The fuction is called by trying to assign
/// \post   NONE
/// \param  rhs is the object to assign from.
/// \return A reference to this Name.
/// \throw  NONE
///////////////////////////////////////////////////////////////////////
FileJpeg& FileJpeg::operator=( const FileJpeg & rhs )
{
   this->mPath = rhs.mPath;
   this->mFileName = rhs.mFileName;
   return *this;
}

// OPERATIONS 

// ACCESS and MUTATE

// INQUIRY

///////////////////////////////////////////////////////////////////////
/// preview
/// \pre    The class has been created
/// \post   A string is returned with the name in it
/// \param  None
/// \return A string
/// \throw  NONE
///////////////////////////////////////////////////////////////////////
Fl_Window* FileJpeg::preview(void)
{
   Fl_JPEG_Image * img = new Fl_JPEG_Image( mPath.c_str() );
    
   Fl_Window * win = new Fl_Window( img->w(), img->h() );
   Fl_Box * box = new Fl_Box( 0, 0, img->w(), img->h() );
   box->image( img );   
 
   return win;
}

