///////////////////////////////////////////////////////////////////////////////
/// \class        FileDir
/// \author       Alex Hortin
/// \date         10/13/05
/// \brief        This is the JPEG file type
///
/// This is the class that inherits from file.  It is derived from file, and 
/// redefines some of the key function using the 1337 dark art of polymorphism.  
///       
/// REVISION HISTORY:
///
/// NONE
///            
///////////////////////////////////////////////////////////////////////////////

// SYSTEM INCLUDES
//

// LOCAL INCLUDES
//
#include "File.h"
#include "FileDir.h"
// FORWARD REFERENCES
//

// CONSTANTS
//

// LIFECYCLE

///////////////////////////////////////////////////////////////////////
/// Default constructor.
/// \pre    Function must be called.
/// \post   A default file is constructed
/// \throw  NONE
///////////////////////////////////////////////////////////////////////
FileDir::FileDir(std::string path)
{
   unsigned int i = path.size();
   mPath = path;  
   while (path[i] != '/' && i > 0)
   {
      i--;
   }
   i++;
   std::string name;
   for (i = i; i < path.size(); i++)
   {
      mFileName = mFileName + path[i];
   }
   mPath = path;
   
   DIR * dirp = opendir( path.c_str() );//creating the file stream
   if (dirp == NULL)
   {
      throw std::domain_error("OMFG WTFBBQ PWNT");
   }
   
   struct dirent * dp = readdir( dirp );
   int i2 = 0;
   while ( 0 != dp )//checking to make sure that these is still stuff in there
   {
       mContents = mContents + dp->d_name + '\n';
       mNames.push_back(dp->d_name);
       dp = readdir( dirp );//moves pointer to next file or dir
       i2++;
   }
   
   ostringstream temp_h;
   temp_h << (i2);
   
   this->mInfoString = this->mInfoString + mPath + '\n' + "Directory containing " + temp_h.str() + " items \n ";
   
}

///////////////////////////////////////////////////////////////////////
/// Destructor.
/// \pre    There must be something to mercelessly rape pillage and destroy
/// \post   Poof! that bitch is gone!
///////////////////////////////////////////////////////////////////////
FileDir::~FileDir( void )
{
}

// OPERATORS

///////////////////////////////////////////////////////////////////////
/// Assignment operator.
/// \pre    The fuction is called by trying to assign
/// \post   NONE
/// \param  rhs is the object to assign from.
/// \return A reference to this Name.
/// \throw  NONE
///////////////////////////////////////////////////////////////////////
FileDir& FileDir::operator=( const FileDir & rhs )
{
   this->mPath = rhs.mPath;
   this->mFileName = rhs.mFileName;
   return *this;
}

// OPERATIONS 

// ACCESS and MUTATE

// INQUIRY

///////////////////////////////////////////////////////////////////////
/// preview
/// \pre    The class has been created
/// \post   A string is returned with the name in it
/// \param  None
/// \return A string
/// \throw  NONE
///////////////////////////////////////////////////////////////////////
Fl_Window* FileDir::preview(void)
{
   win = new Fl_Window( 200  ,300);
   box = new Fl_Hold_Browser(10, 10, 180, 280, "");
   //Fl_Multiline_Output * box = new Fl_Multiline_Output(10, 10, 180, 280, "");
   //box->value(mContents.c_str());
   for (unsigned int i = 0; i < mNames.size(); i++)
   {
      box->add(mNames[i].c_str());
   }
   box->callback( cb_preview_browser,this); //callback
   return win;
}


///////////////////////////////////////////////////////////////////////
/// cb_preview_browser is the call that the program makes when the search button 
/// is pressed.  It than calls a search of the tree for results.
/// \pre   the pre conditions for this is the button being pressed and a tree existing to search through 
/// \post  the mResults browser will be modified
/// \param  a widget pointer
/// \return void
/// \throw  n/a
///////////////////////////////////////////////////////////////////////
void FileDir::cb_preview_browser(Fl_Widget* box, void* v )//the button for tell me
{
   ( (FileDir*)v )->cb_preview_browser_i();
}

///////////////////////////////////////////////////////////////////////
/// cb_preview_browser_i is the call that the program makes when the search button 
/// is pressed.  It than calls a search of the tree for results.
/// \pre   the pre conditions for this is the button being pressed and a tree existing to search through 
/// \post  the mResults browser will be modified
/// \param  a widget pointer
/// \return void
/// \throw  n/a
///////////////////////////////////////////////////////////////////////
void FileDir::cb_preview_browser_i()//the button for tell me
{
   unsigned int compare_temp = (box->value()-1);
   if (compare_temp > mNames.size())
   {
      return; 
   }
   std::string temp;
   try
   {
      File * f = File::create(mPath+'/'+mNames[compare_temp]);
      Fl_Window * w = f->preview();
      w->show();
   }
   catch (std::domain_error)
   {
      std::cout << std::endl <<"No preview available for this type of file" << std::endl;
   }
}

