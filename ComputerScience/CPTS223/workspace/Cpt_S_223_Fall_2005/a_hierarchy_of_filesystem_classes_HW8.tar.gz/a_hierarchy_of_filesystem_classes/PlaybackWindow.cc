///////////////////////////////////////////////////////////////////////////////
/// \class        PlaybackWindow
/// \author       Alex Hortin
/// \date         8/31/05  
/// \brief        This class creates a playback window that is inherits 
///               from the FLTK class and uses library functions from 
///               sampleplayer
///
/// This class is meant to generate a simple window using FLTK and play a 
/// sound file.  There are two buttons on the window, a play and a quit button.
/// When pressed the play button's text changes to stop and back to play when
/// it is pressed again.  The class must be called with a string, which is the
/// path and file name to the sample sounds that is being played.
///
/// \invariant   None
///       
/// REVISION HISTORY:
///
/// 9/12/05       Coding standard quality commenting and naming, with addition
///               of required features.
///            
///////////////////////////////////////////////////////////////////////////////

#include "PlaybackWindow.h"//includes the file where my class definition is

///////////////////////////////////////////////////////////////////////
/// Default constructor.
/// \pre    None
/// \post   An instance of the playback window is created.  A vector is filled
///         with information about the sound.
/// \param  A string containing the name for a file.
/// \throw  None
///////////////////////////////////////////////////////////////////////
PlaybackWindow::PlaybackWindow(string file_name):Fl_Window(170,50,"Music Player")
{
	SF_INFO mInfo;//the info struct for the file
   SNDFILE * mSfp = 0;//pointer to the sound file
   sf_count_t mNsamps = 0;//stores the ammount of samples
   
   mInfo.format = 0;
   mSfp = sf_open( file_name.c_str(), SFM_READ, &mInfo );//attempts to open the file
   if ( 0 == mSfp )//if file can't open
   {
      throw std::domain_error("ERROR reading file");//throwing an exception
      return;
   }
   mNsamps = mInfo.frames * mInfo.channels;//figuring out how many samples are there
   
   mFrames = mInfo.frames;//storing frames for later use to call by player
   
   mReadSamples.resize(mNsamps);
   
   sf_readf_float( mSfp, &mReadSamples[0], mInfo.frames );
   mPlayer = new SamplePlayer(mInfo.samplerate, mInfo.channels);
   begin();
		play_or_stop = new Fl_Button( 10, 10, 70, 30, "P&lay");//displays the button to tell
		play_or_stop->callback( cb_play_or_stop, this );//calls the function after the button has been pressed
	
		quit = new Fl_Button(90, 10, 70, 30, "&Quit");//displays the quit button
		quit->callback(cb_quit, this);//calls the quit function to quit the program
		mIs_playing = false;
	end();//ends the function
	//resizable(this);//makes the window resizable
	show();//shows the window
}
///////////////////////////////////////////////////////////////////////
/// Copy Constructor.
/// \pre    An instance of PlaybackWindow needs to be present.
/// \post   Two instances of the same window will exist.
/// \param   PlaybackWindow is the PlaybackWindow to copy from.
/// \throw  None
///////////////////////////////////////////////////////////////////////
PlaybackWindow::PlaybackWindow(const PlaybackWindow& PlaybackWindow):Fl_Window(300,200,"I Pass")
{
}
///////////////////////////////////////////////////////////////////////
/// Destructor.
/// \pre    An instance of PlaybackWindow has been created.
/// \post   The instance of PlaybackWindow is destroyed.
///////////////////////////////////////////////////////////////////////
PlaybackWindow::~PlaybackWindow()
{
}
///////////////////////////////////////////////////////////////////////
/// cb_quit
/// \pre    The quit button must have been presses
/// \post   The cb_quit_i function is called to terminate the program.
/// \param  Fl_Widget is the button that must be pressed.
/// \return None
/// \throw  None
///////////////////////////////////////////////////////////////////////
void PlaybackWindow::cb_quit(Fl_Widget* , void* v)
{
	( (PlaybackWindow*)v )->cb_quit_i();//calls the function to hide the window
}
///////////////////////////////////////////////////////////////////////
/// cb_quit_i
/// \pre    cb_quit must have been called by the button press.
/// \post   The program terminates
/// \param  None
/// \return None
/// \throw  None
///////////////////////////////////////////////////////////////////////
void PlaybackWindow::cb_quit_i() 
{
	hide();//hides the window
}
///////////////////////////////////////////////////////////////////////
/// cb_play_or_stop
/// \pre    The Play or Stop button must be pressed.
/// \post   Play is changed to stop or stop is changed to play.
/// \param  Fl_Widget is the button that must be pressed
/// \return None
/// \throw  None
///////////////////////////////////////////////////////////////////////
void PlaybackWindow::cb_play_or_stop(Fl_Widget* , void* v)
{
    ( (PlaybackWindow*)v )->cb_play_or_stop_i();//calls the function that displays the text
}
///////////////////////////////////////////////////////////////////////
/// cb_play_or_stop_i
/// \pre    cb_play_or_stop must have been called by the button press.
/// \post   Play is changed to stop or stop is changed to play and the sound
///         plays.
/// \param  None
/// \return None
/// \throw  None
///////////////////////////////////////////////////////////////////////
void PlaybackWindow::cb_play_or_stop_i()
{
	if (true == mPlayer->isPlaying())//checks to see if a sound is being played currently
   {
      play_or_stop->label("Play");//changes label
      mPlayer->stopPlayback();
   }
   else
   {
      mPlayer->startPlayback(&mReadSamples[0], mFrames);
      play_or_stop->label("Stop");//changes label
   }
   
}
