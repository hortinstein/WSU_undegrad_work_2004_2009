///////////////////////////////////////////////////////////////////////////////
/// \author       Alex Hortin
/// \date         11/08/05
/// \brief        This is my test file used to test my filesystem
///
/// I am creating a tree and this will be the file that I use to test all of
/// the various functions contained within the filesystem.  It will try to test 
/// all of the options that the interface gives the user. This time it will be
/// used to emulate a file structure simalar to the structure used in Unix file 
/// systems.
///
/// REVISION HISTORY:
///
/// NONE
///            
///////////////////////////////////////////////////////////////////////////////

// SYSTEM INCLUDES
//

// LOCAL INCLUDES
//
#include "File.h"
#include "FileJpeg.h"  
#include "FileDir.h"        
#include "FileWav.h"                       

// FUNCTIONS

int main (int argc, char *argv[])
{
   if (argc != 2)
   {
      std::cout << "not so fast, you need to specify a file or directory" << std::endl;
      return 0;
   }
   try
   {
      File * f = File::create(argv[1]);
      Fl_Window * w = f->preview();
      w->show();
      return Fl::run();
   }
   catch (std::domain_error)
   {
      std::cout << "No Directry or fileFound..try again" << std::endl;//prints out the error
   }
}
