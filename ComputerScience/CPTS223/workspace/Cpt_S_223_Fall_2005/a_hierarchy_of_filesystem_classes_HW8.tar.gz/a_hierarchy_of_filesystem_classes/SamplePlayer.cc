///////////////////////////////////////////////////////////////////////////////
/// \class        SamplePlayer
/// \author       Kelly Fitz
/// \date         07 Mar 05
///
/// \brief        Manage sound sample playback using the PortAudio library.
///
///               SamplePlayer manages sound playback by establishing a
///               connection with the sound device and feeding samples
///               to it. Clients provide the samples by passing a pointer
///               to a buffer of samples, and the size (in frames) of
///               the buffer, to the startPlayback member. The samples
///               must be of type float. Playback of the specified samples
///               begins when startPlayback returns. Playback stops when
///               stopPlayback is called, or when the specified number
///               of sample frames have been played back.
///
///               This class can only be used in a program running with
///               access to the sound card! Most often, that means that
///               a program using this class cannot be launched over a 
///               network (including ssh). 
///
///               To compile this class, you may need to add something
///               to your compile flags so that the header portaudio.h
///               can be found (most often it is installed in 
///               /usr/local/include so you can add
///               -I/usr/local/include
///               to your CXXFLAGS.
///
///               To link a program using this class, you need to link 
///               the portaudio library, as well as the pthread library. 
///               You shouldbe able to add something like this to your
///               link command:
///               -L/usr/local/lib -lportaudio -lpthread
///
///       
/// REVISION HISTORY:
///
/// 07 Mar 05     Creation.
///
/// 09 Mar 05     Clean up and rename. -kel
///
/// 23 Mar 05     Modify to make copy and assignment work better. Now, 
///               streams are opened and closed on activation, instead 
///               of on construction. The old way prevented you from
///               ever having two players in existence at the same time.
///               Now, the only limitation is that only one may be 
///               active at a time. -kel
///
/// 30 Aug 05     Rewrote to simply play a buffer of floating point 
///               samples, no longer a base class. Renamed to SamplePlayer
///               from SoundPlayer. -kel      
///////////////////////////////////////////////////////////////////////////////

#include "SamplePlayer.h" 

#include <portaudio.h>                               

#include <iostream>     
#include <stdexcept>
using std::runtime_error;
                      
// PUBLIC 

// LIFECYCLE 

///////////////////////////////////////////////////////////////////////
/// Constructor.
///
/// \param  rate is the sample rate in Hz (default 44100)
/// \param  nchans is the number of channels of audio (default 2)
/// \return nothing
/// \throw   if the audio stream cannot be initialized.
///////////////////////////////////////////////////////////////////////
SamplePlayer::SamplePlayer( double rate, unsigned int nchans ) : 
   mStream( 0 ),
   mSampleRate( rate ),
   mNumChannels( nchans ),
   mCurrentSample( 0 ),
   mEndSamples( 0 )
{
} // End constructor

///////////////////////////////////////////////////////////////////////
/// Copy Constructor.
/// The audio stream is not copied, each instance needs its own
/// stream, so a new stream is created and initialized for this
/// instance.
///
/// \param rhs is the Name to copy from.
/// \return nothing
/// \throw   if the audio stream cannot be initialized.
///////////////////////////////////////////////////////////////////////
SamplePlayer::SamplePlayer( const SamplePlayer & rhs ) :
   mStream( 0 ),
   mSampleRate( rhs.mSampleRate ),
   mNumChannels( rhs.mNumChannels ),
   mCurrentSample( 0 ),
   mEndSamples( 0 )
{
   // there is nothing else to copy, each instance 
   // needs its own stream
} // end copy constructor

///////////////////////////////////////////////////////////////////////
/// Destructor.
/// Deactivate and close the audio stream.
/// Destructor is virtual to permit subclassing.
///////////////////////////////////////////////////////////////////////
SamplePlayer::~SamplePlayer( void )
{
   try
   {
      stopSoundStream();
   }
   catch( ... )
   {
      // never, ever, ever throw an exception out of
      // a destructor
   }
} // end destructor

// OPERATORS 

///////////////////////////////////////////////////////////////////////
/// Assignment operator.
/// The audio stream is not copied, each instance needs its own
/// stream, so a new stream is created and initialized for this
/// instance.
///  
/// \param  rhs is the Name to copy from.
/// \return a reference to this SamplePlayer.
/// \throw  runtime_error if the audio stream cannot be initialized.
///////////////////////////////////////////////////////////////////////
SamplePlayer& SamplePlayer::operator=( const SamplePlayer &  rhs )
{
   if ( this != &rhs )
   {
	   stopSoundStream();
	   
	   mSampleRate = rhs.mSampleRate;
	   mNumChannels = rhs.mNumChannels;
	   mCurrentSample = mEndSamples = 0;
		     
      // don't make the instance active, even if rhs
      // is active, because only one instance can be 
      // active at a time.
   }

   return *this;
} // end assignment operator

// OPERATIONS 


///////////////////////////////////////////////////////////////////////
/// startPlayback
/// Start playing samples from the specified buffer
/// of floats.
///
/// \param  buffer is the address of the first sample
///         to playback
/// \param  howMany is the number of sample frames to
///         stereo sample frames are stored in the buffer,
///         and should be played back.
///////////////////////////////////////////////////////////////////////
void SamplePlayer::startPlayback( const float * buffer, unsigned int howMany )
{
   if ( mStream != 0 )
   {
      stopPlayback();
   }

   mCurrentSample = buffer;
   mEndSamples = buffer + ( howMany * getNumChannels() );
   
   try
   {
      startSoundStream();
   }
   catch( std::runtime_error & ex )
   {
      std::cerr << "Error opening audio stream: "
                << ex.what() << std::endl;
      mCurrentSample = mEndSamples = 0;
   }
}

///////////////////////////////////////////////////////////////////////
/// stopPlayback
/// If a sound is playing, stop playback. Otherwise
/// do nothing.
///////////////////////////////////////////////////////////////////////
void SamplePlayer::stopPlayback( void ) 
{
	stopSoundStream();
	mCurrentSample = mEndSamples =  0;
}

///////////////////////////////////////////////////////////////////////
/// wait
/// Sleep for the specified number of milliseconds,
/// then return, useful for busy wait loops.
///
/// \param  sleepTimeMs is the (approximate) number of milliseconds
///         to wait.
///////////////////////////////////////////////////////////////////////
void SamplePlayer::wait( int sleepTimeMs ) const
{
   Pa_Sleep( sleepTimeMs );
}

// ACCESS and MUTATE 

///////////////////////////////////////////////////////////////////////
/// getNumChannels
///
/// \return the number of audio channels (samples per frame),
///         1 for mono, 2 for stereo, etc.
///////////////////////////////////////////////////////////////////////
unsigned int SamplePlayer::getNumChannels( void ) const
{
   return mNumChannels;
}

///////////////////////////////////////////////////////////////////////
/// getSampleRate
///
/// \return the playback sample rate in sample frames per second (Hz). 
///////////////////////////////////////////////////////////////////////
double SamplePlayer::getSampleRate( void ) const
{
   return mSampleRate;
}

// INQUIRY 

///////////////////////////////////////////////////////////////////////
/// isPlaying
/// 
/// \return true is the instance is playing samples, and
///         false otherwise.
///////////////////////////////////////////////////////////////////////
bool SamplePlayer::isPlaying( void ) const
{
   return mCurrentSample != mEndSamples; 
}

// PROTECTED  

///////////////////////////////////////////////////////////////////////
/// playback
///
/// Caled by the callback function.
/// 
/// \param  buffer is the sample buffer
/// \param  howMany is the number of sample frames to
///         stereo sample frames are stored in the buffer,
///         and should be filled in by this call.
/// \return true if more samples are to be played, false
///         otherwise.
///////////////////////////////////////////////////////////////////////
bool SamplePlayer::playback( float * buffer, 
                             unsigned int framesPerBuffer )
{
   unsigned int N = framesPerBuffer * getNumChannels();
   while ( N > 0 && mCurrentSample != mEndSamples )
   {
      *buffer++ = *mCurrentSample++;
      --N;
   }
   
   while ( N > 0 )
   {
      *buffer++ = 0;
      --N;      
   }
   
   // return true if there are more samples to play, false otherwise
   return mCurrentSample != mEndSamples;
}

// PRIVATE  

///////////////////////////////////////////////////////////////////////
/// startSoundStream
/// helper function to establish a connection to the sound device
/// and begin playback.
/// 
/// \throw  if the sound stream cannot be initialized or activated
///////////////////////////////////////////////////////////////////////
void SamplePlayer::startSoundStream( void )
{
   if ( 0 == mStream )
   {
      /* Open an audio I/O stream. */
      PaError err;
      err = Pa_OpenDefaultStream(
                 &mStream,
                 0,              /* no input channels */
                 getNumChannels(),
                 paFloat32,      /* 32 bit floating point output */
                 getSampleRate(),
                 256,            /* frames per buffer */
                 0,              /* number of buffers, if zero then use default minimum */
                 SamplePlayer::PaCallback,     /* the name of the callback function */
                 this );         /* a pointer to this SamplePlayer instance */
                 
      if( err != paNoError )
      {
         throw runtime_error( Pa_GetErrorText( err ) );
         //std::cerr << "Error opening audio stream: " 
         //          << Pa_GetErrorText( err ) << std::endl;
      }
      
      err = Pa_StartStream( mStream );
      if( err != paNoError )
      {
         throw runtime_error( Pa_GetErrorText( err ) );
      }  
   }
}

///////////////////////////////////////////////////////////////////////
/// stopSoundStream
/// helper function to break a connection to the sound device
///
/// This member is const, even though it changes mStream (which
/// is declared mutable, yuck!), because it is called through the
/// const member isActive(), which updates the active status
/// before checking it. This is not beautiful, but it allows
/// me to change the way this class works without changing its
/// interface. If I made isActive non-const, I might break existing
/// code (and inquiry members should be const anyway).
/// 
/// \throw  if there is an error while closing the sound stream
///////////////////////////////////////////////////////////////////////
void SamplePlayer::stopSoundStream( void ) const
{
   if ( 0 != mStream )
   {
      PaError err = Pa_StopStream( mStream );
      Pa_CloseStream( mStream );
      mStream = 0;
      if( err != paNoError )
      {
         throw runtime_error( Pa_GetErrorText( err ) );
         //std::cerr << "Error stopping audio stream: " 
         //          << Pa_GetErrorText( err ) << std::endl;
      }  
   }
}

///////////////////////////////////////////////////////////////////////
/*
   The callback function.
                                                                          
   This function will be called by the PortAudio engine when
   samples are needed. It may called at interrupt level on some
   machines so don't do anything that could mess up the system
   like calling malloc() or free().
                                                                          
   inputBuffer is only useful is you are using live input (we
   won't, but you can try it if you want). Since you can use
   a variety of different sample formats, this is a pointer to
   void, and you have to cast it to the right type. We'll always
   use float samples.
                                                                          
   outputBuffer is where you are storing the samples. Like
   inputBuffer, and for the same reasons, this is a pointer to
   void and you need to cast it in order to make it useful.
                                                                          
   framesPerBuffer is the number of samples in both inputBuffer
   and outputBuffer.
                                                                          
   outTime is how many samples have been generated so far.
                                                                          
   userData is a pointer to your data structure, you can cast it
   to type paData* and access your data.
                                                                          
   There is no direct way to determine the number of channels of audio
   unless you stored it in your data stucture, or make it global.
*/
int 
SamplePlayer::PaCallback( void * /* inputBuffer */, void *outputBuffer,
                         unsigned long framesPerBuffer,
                         PaTimestamp /* outTime */, void *userData )
{
   /* cast those void pointers into something useful */
   float *out = (float*)outputBuffer;
   SamplePlayer * me = (SamplePlayer*)userData;
   
   if ( me->playback( out, framesPerBuffer ) )
   {
      return 0;
   }
   else
   {
      return 1;
   }
}

///////////////////////////////////////////////////////////////////////
// local class to manage the PortAudio library
///////////////////////////////////////////////////////////////////////
struct PA
{
   PA( void ) 
   {
      std::cerr << "Initializing PortAudio library." << std::endl;
      PaError err = Pa_Initialize();
      if( err != paNoError )
      {
         // throw runtime_error( Pa_GetErrorText( err ) );
		 std::cerr << "Could not initialize the PortAudio library.\n"
		           << "SamplePlayer instances will not work.\n"
		 		   << "Maybe the problem is that you are logged in REMOTELY\n"
		 		   << "and do not have access to the sound card." << std::endl;
      }
   }
   
   ~PA( void )
   {
      std::cerr << "Terminating PortAudio library." << std::endl;
      Pa_Terminate();
   }
};

// static local instance that ensures that the PortAudio
// library is initialized before any streams are created,
// and terminated before the program quits. This will probably
// fail if main() is written in C. So don't do that.
static PA pa;
