#include "../Vec.h"
#include <iostream>

using std::cout;
using std::endl;
using std::string;

int main()
{

  cout << "Test 1 (Initial Size Constructor & non-const [] Test):";
  
  string items[] = {"Kelly", "Chris", "Nina", "Ed", "Jack", "Curtis", "Murali"};

  Vec v(7);

  for (int i = 0; i < 7; i++)
  {
    v[i] = items[i];
  }

  bool passed = true;

  int i;
  for(i = 0; i < 7; i++)
  {
    if (v[i] != items[i])
    {
      passed = false;
      break;
    }
  }

  if (passed == true)
  {
    cout << " PASSED" << endl;
  }
  else
  {
    cout << " FAILED" << endl;
    cout << "Expected: v[" << i << "] == " << items[i] << endl;
    cout << "Got:      v[" << i << "] == " << v[i] << endl;

  }

  cout << endl;
  return 0;

}
