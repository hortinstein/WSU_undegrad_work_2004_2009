#include "../Vec.h"
#include <iostream>

using std::cout;
using std::endl;
using std::string;

int main()
{

  cout << "Test 9 (Default Constructor & Stress test of push_back()) Test:";
  
  string items[] = {"Kelly", "Chris", "Nina", "Ed", "Jack", "Curtis", "Murali"};

  Vec v;

  for (int i = 0; i < 1000; i++)
  {
    v.push_back("Moo");
  }

  bool passed = true;

  int i;
  for(i = 0; i < 1000; i++)
  {
    if (v[i] != "Moo")
    {
      passed = false;
      break;
    }
  }

  if (passed == true)
  {
    cout << " PASSED" << endl;
  }
  else
  {
    cout << " FAILED" << endl;
    cout << "Expected: v[" << i << "] == Moo" << endl;
    cout << "Got:      v[" << i << "] == " << v[i] << endl;

  }

  cout << endl;
  return 0;

}
