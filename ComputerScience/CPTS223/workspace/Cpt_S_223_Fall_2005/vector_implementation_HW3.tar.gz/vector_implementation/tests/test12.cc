#include "../Vec.h"
#include <iostream>

using std::cout;
using std::endl;
using std::string;

int main()
{

  cout << "Test 12 (Resize weirdness Test):";
  
  string items[] = {"Kelly", "Chris", "Nina", "Ed", "Jack", "Curtis", "Murali"};

  Vec v;

  for (int i = 0; i < 1000; i++)
  {
    v.push_back("Moo");
  }

  v.resize(10);
  v.resize(1000);

  bool passed = true;

  int i;
  for(i = 10; i < 1000; i++)
  {
    if (v[i] != "")
    {
      passed = false;
      break;
    }
  }

  if (passed == true)
  {
    cout << " PASSED" << endl;
  }
  else
  {
    cout << " FAILED" << endl;
    cout << "Expected: v[" << i << "] == \"\"" << endl;
    cout << "Got:      v[" << i << "] == " << v[i] << endl;

  }

  cout << endl;
  return 0;

}
