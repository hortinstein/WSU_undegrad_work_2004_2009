#include "../Vec.h"
#include <iostream>

using std::cout;
using std::endl;
using std::string;

int main()
{

  cout << "Test 13 (clear() Test):";
  
  Vec v;

  for (int i = 0; i < 1000; i++)
  {
    v.push_back("Moo");
  }

  v.clear();

  bool passed = true;

  int i;

  if (passed == v.empty())
  {
    cout << " PASSED" << endl;
  }
  else
  {
    cout << " FAILED" << endl;
    cout << "Expected: v.empty() == true" << endl;
    cout << "Got:      v.empty() == false" << endl;

  }

  cout << endl;
  return 0;

}
