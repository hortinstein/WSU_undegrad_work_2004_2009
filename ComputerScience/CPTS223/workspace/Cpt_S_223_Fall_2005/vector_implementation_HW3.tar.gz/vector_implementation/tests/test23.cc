#include "../Vec.h"
#include <iostream>
#include <stdexcept>

using std::cout;
using std::endl;
using std::string;
using std::out_of_range;

int main()
{

  cout << "Test 1 ([] exception Test):";
  
  string items[] = {"Kelly", "Chris", "Nina", "Ed", "Jack", "Curtis", "Murali"};

  Vec v;

  bool passed1 = false;
  bool passed2 = false;

  try {
   v[0] = 1;
  }
  catch(out_of_range &oor)
  {
    passed1 = true; 
  }

  Vec y(7);
  for (int i = 0; i < 7; i++)
  {
    y[i] = items[i];
  }

  try {
   y[7] = 1;
  }
  catch(out_of_range &oor)
  {
    passed2 = true; 
  }

  if (passed1 == true && passed2 == true)
  {
    cout << " PASSED" << endl;
  }
  else
  {
    cout << " FAILED" << endl;
    if (passed1 == false)
    {
      cout << "Expected: out_of_range to be thrown when doing v[0] on empty Vec" << endl;
    }

    if (passed2 == false)
    {
      cout << "Expected: out_of_range to be thrown when doing v[7] on  Vec.size() == 7" << endl;
    }

  }

  cout << endl;
  return 0;

}
