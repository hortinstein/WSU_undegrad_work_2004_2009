#include "../Vec.h"
#include <iostream>
#include <stdexcept>

using std::cout;
using std::endl;
using std::string;
using std::domain_error;

int main()
{

  cout << "Test 24 (front() exception Test):";
  

  Vec v;

  bool passed1 = false;
  try {
   v.front() = 1;
  }
  catch(domain_error &de)
  {
    passed1 = true; 
  }

  if (passed1 == true)
  {
    cout << " PASSED" << endl;
  }
  else
  {
    cout << " FAILED" << endl;
    cout << "Expected: domain_error to be thrown when doing v.front() on empty Vec" << endl;


  }

  cout << endl;
  return 0;

}
