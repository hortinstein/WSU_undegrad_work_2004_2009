#include "../Vec.h"
#include <iostream>

using std::cout;
using std::endl;
using std::string;

int main()
{

  cout << "Test 22 (copy constructor Test):";
  
  string items[] = {"Kelly", "Chris", "Nina", "Ed", "Jack", "Curtis", "Murali"};

  Vec v(7);

  for (int i = 0; i < 7; i++)
  {
    v[i] = items[i];
  }

  Vec y = v;

  bool passed = true;
  bool passed1 = true;
  bool passed2 = true;

  int i;
  for(i = 0; i < 7; i++)
  {
    if (v[i] != items[i])
    {
      passed = false;
      break;
    }
  }

  y[0] = "Changed";

  if (y[0] != "Changed")
  {
    passed1 = false;
  }

  if (v[0] == "Changed")
  {
    passed2 = false;
  }

  if (passed == true && passed1 == true && passed2 == true)
  {
    cout << " PASSED" << endl;
  }
  else
  {
    cout << " FAILED" << endl;

    if (passed == false)
    {
      cout << "Expected: v[" << i << "] == " << items[i] << endl;
      cout << "Got:      v[" << i << "] == " << v[i] << endl;
    }
    if (passed1 == false)
    {
      cout << "Expected: y[0] == Changed" << endl;
      cout << "Got:      y[0] == " << y[0] << endl;
    }
    if (passed2 == false)
    {
      cout << "Expected: v[0] == Kelly" << endl;
      cout << "Got:      v[0] == " << v[0] << endl;
    }
    
  }

  cout << endl;
  return 0;

}
