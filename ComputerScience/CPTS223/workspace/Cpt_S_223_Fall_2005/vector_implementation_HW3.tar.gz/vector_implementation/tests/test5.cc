#include "../Vec.h"
#include <iostream>

using std::cout;
using std::endl;
using std::string;

int main()
{

  cout << "Test 5 (size() Test):";
  
  bool passed1 = true;
  bool passed2 = true;

  Vec v1(7);

  if (v1.size() != 7)
  {
    passed1 = false;
  }

  Vec v2;

  if(v2.size() != 0)
  {
    passed2 = false;
  }
  
  if (passed1 == true && passed2 == true)
  {
    cout << " PASSED" << endl;
  }
  else
  {
    cout << " FAILED" << endl;

    if (passed1 == false)
    {
    cout << "Expected: v1.size() == 7" << endl;
    cout << "Got:      v1.size() == " << v1.size() << endl;
    }
    if (passed2 == false)
    {
    cout << "Expected: v2.size() == 0" << endl;
    cout << "Got:      v2.size() == " << v2.size() << endl;
    }
  }

  cout << endl;
  return 0;

}
