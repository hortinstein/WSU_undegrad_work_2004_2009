#include "../Vec.h"
#include <iostream>

using std::cout;
using std::endl;
using std::string;

int main()
{

  cout << "Test 11 (Initial size constructor, shrinking resize()) Test:";
  
  Vec v(1000);

  v.resize(10);

  bool passed = true;

  int i;

  if (v.size() != 10)
  {
    passed = false;
  }

  if (passed == true)
  {
    cout << " PASSED" << endl;
  }
  else
  {
    cout << " FAILED" << endl;
    cout << "Expected: v.size() == 10" << endl;
    cout << "Got:      v.size() == " << v.size() << endl;

  }

  cout << endl;
  return 0;

}
