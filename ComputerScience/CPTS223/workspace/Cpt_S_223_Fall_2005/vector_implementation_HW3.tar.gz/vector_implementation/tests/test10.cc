#include "../Vec.h"
#include <iostream>

using std::cout;
using std::endl;
using std::string;

int main()
{

  cout << "Test 10 (Default Constructor, resize() & Stress test of push_back()) Test:";
  
  Vec v;

  v.resize(1000);

  for (int i = 0; i < 1000; i++)
  {
    v.push_back("Moo");
  }

  bool passed = true;

  int i;

  for (i = 0; i < 1000; i++)
  {
    if (v[i] != "")
    {
      passed = false;
      break;
    }  
  }
  for(i = 0; i < 1000; i++)
  {
    if (v[i+1000] != "Moo")
    {
      passed = false;
      break;
    }

  }

  if (passed == true)
  {
    cout << " PASSED" << endl;
  }
  else
  {
    cout << " FAILED" << endl;
    if (i < 1000)
    {
      cout << "Expected: v[" << i << "] == \"\"" << endl;
    }
    else
    {
      cout << "Expected: v[" << i << "] == Moo" << endl;
    }
    cout << "Got:      v[" << i << "] == " << v[i] << endl;

  }

  cout << endl;
  return 0;

}
