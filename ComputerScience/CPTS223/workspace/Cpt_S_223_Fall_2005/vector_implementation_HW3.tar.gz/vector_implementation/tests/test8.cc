#include "../Vec.h"
#include <iostream>

using std::cout;
using std::endl;
using std::string;

int main()
{

  cout << "Test 8 (clear() & empty() Test):";
  
  string items[] = {"Kelly", "Chris", "Nina", "Ed", "Jack", "Curtis", "Murali"};

  Vec v(7);

  for (int i = 0; i < 7; i++)
  {
    v[i] = items[i];
  }

  v.clear();

  bool passed = true;

  if (v.empty() != true)
    passed = false;

  if (passed == true)
  {
    cout << " PASSED" << endl;
  }
  else
  {
    cout << " FAILED" << endl;
    cout << "Expected: v.empty() == " << true << endl;
    cout << "Got:      v.empty() == " << false << endl;

  }

  cout << endl;
  return 0;

}
