#include "../Vec.h"
#include <iostream>

using std::cout;
using std::endl;
using std::string;

int main()
{

  cout << "Test 14 (front() Test):";
  
  string items[] = {"Kelly", "Chris", "Nina", "Ed", "Jack", "Curtis", "Murali"};

  Vec v(7);

  for (int i = 0; i < 7; i++)
  {
    v[i] = items[i];
  }

  bool passed = true;

  v.front() = "NewKelly";

  if (v[0] == "NewKelly")
  {
    cout << " PASSED" << endl;
  }
  else
  {
    cout << " FAILED" << endl;
    cout << "Expected: v[0] == NewKelly" << endl;
    cout << "Got:      v[0] == " << v[0] << endl;

  }

  cout << endl;
  return 0;

}
