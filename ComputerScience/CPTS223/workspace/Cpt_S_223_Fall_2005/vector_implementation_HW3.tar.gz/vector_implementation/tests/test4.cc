#include "../Vec.h"
#include <iostream>

using std::cout;
using std::endl;
using std::string;

int main()
{

  cout << "Test 4 (Initial Size Constructor, non-const [], pop_back() & size() Test):";
  
  string items[] = {"Kelly", "Chris", "Nina", "Ed", "Jack", "Curtis", "Murali"};

  Vec v(7);

  for (int i = 0; i < 7; i++)
  {
    v[i] = items[i];
  }

  bool passed = true;

  unsigned int i;
  for(i = 7; i > 0; i--)
  {
    v.pop_back();
    if (v.size() != i-1)
    {
      passed = false;
      break;
    }
  }

  if (passed == true)
  {
    cout << " PASSED" << endl;
  }
  else
  {
    cout << " FAILED" << endl;
    cout << "Expected: v.size() == " << i-1 << endl;
    cout << "Got:      v.size() == " << v.size() << endl;

  }

  cout << endl;
  return 0;

}
