#include "../Vec.h"
#include <iostream>

using std::cout;
using std::endl;
using std::string;

int main()
{

  cout << "Test 20 (const empty() Test):";
  
  bool passed1 = true;
  bool passed2 = true;

  Vec v1(7);

  const Vec& y1 = v1;

  if (y1.empty() != false)
  {
    passed1 = false;
  }

  Vec v2;

  const Vec& y2 = v2;

  if(y2.empty() != true)
  {
    passed2 = false;
  }
  
  if (passed1 == true && passed2 == true)
  {
    cout << " PASSED" << endl;
  }
  else
  {
    cout << " FAILED" << endl;

    if (passed1 == false)
    {
    cout << "Expected: y1.empty() == false" << endl;
    cout << "Got:      y1.empty() == " << y1.empty() << endl;
    }
    if (passed2 == false)
    {
    cout << "Expected: y2.empty() == true" << endl;
    cout << "Got:      y2.empty() == " << y2.empty() << endl;
    }
  }

  cout << endl;
  return 0;

}
