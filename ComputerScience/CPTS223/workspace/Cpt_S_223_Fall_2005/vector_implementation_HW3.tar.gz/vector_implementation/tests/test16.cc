#include "../Vec.h"
#include <iostream>

using std::cout;
using std::endl;
using std::string;

int main()
{

  cout << "Test 16 (const [] Test):";
  
  string items[] = {"Kelly", "Chris", "Nina", "Ed", "Jack", "Curtis", "Murali"};

  Vec v(7);

  for (int i = 0; i < 7; i++)
  {
    v[i] = items[i];
  }

  bool passed = true;

  const Vec& y = v;

  int i;
  for(i = 0; i < 7; i++)
  {
    if (y[i] != items[i])
    {
      passed = false;
      break;
    }
  }

  if (passed == true)
  {
    cout << " PASSED" << endl;
  }
  else
  {
    cout << " FAILED" << endl;
    cout << "Expected: y[" << i << "] == " << items[i] << endl;
    cout << "Got:      y[" << i << "] == " << y[i] << endl;

  }

  cout << endl;
  return 0;

}
