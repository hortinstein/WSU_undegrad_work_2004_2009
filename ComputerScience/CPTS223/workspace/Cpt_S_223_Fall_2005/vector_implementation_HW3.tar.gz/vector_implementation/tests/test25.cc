#include "../Vec.h"
#include <iostream>
#include <stdexcept>

using std::cout;
using std::endl;
using std::string;
using std::domain_error;

int main()
{

  cout << "Test 25 (back() exception Test):";
  

  Vec v;

  bool passed1 = false;
  try {
   v.back() = 1;
  }
  catch(domain_error &de)
  {
    passed1 = true; 
  }

  if (passed1 == true)
  {
    cout << " PASSED" << endl;
  }
  else
  {
    cout << " FAILED" << endl;
    cout << "Expected: domain_error to be thrown when doing v.back() on empty Vec" << endl;


  }

  cout << endl;
  return 0;

}
