#include "../Vec.h"
#include <iostream>

using std::cout;
using std::endl;
using std::string;

int main()
{

  cout << "Test 7 (empty() Test):";
  
  bool passed1 = true;
  bool passed2 = true;

  Vec v1(7);

  if (v1.empty() != false)
  {
    passed1 = false;
  }

  Vec v2;

  if(v2.empty() != true)
  {
    passed2 = false;
  }
  
  if (passed1 == true && passed2 == true)
  {
    cout << " PASSED" << endl;
  }
  else
  {
    cout << " FAILED" << endl;

    if (passed1 == false)
    {
    cout << "Expected: v1.empty() == false" << endl;
    cout << "Got:      v1.empty() == " << v1.empty() << endl;
    }
    if (passed2 == false)
    {
    cout << "Expected: v2.empty() == true" << endl;
    cout << "Got:      v2.empty() == " << v2.empty() << endl;
    }
  }

  cout << endl;
  return 0;

}
