#include "../Vec.h"
#include <iostream>

using std::cout;
using std::endl;
using std::string;

int main()
{

  cout << "Test 6 (Default Constructor, push_back() & size() Test:";
  
  string items[] = {"Kelly", "Chris", "Nina", "Ed", "Jack", "Curtis", "Murali"};

  Vec v;
  bool passed = true;

  unsigned int i;
  for (i = 0; i < 7; i++)
  {
    v.push_back(items[i]);
    if (v.size() != i+1)
    {
      passed = false;
      break;
    }
  }


  if (passed == true)
  {
    cout << " PASSED" << endl;
  }
  else
  {
    cout << " FAILED" << endl;
    cout << "Expected: v.size() == " << i << endl;
    cout << "Got:      v.size() == " << v.size() << endl;

  }

  cout << endl;
  return 0;

}
