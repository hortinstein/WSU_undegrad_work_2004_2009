#include "../Vec.h"
#include <iostream>

using std::cout;
using std::endl;
using std::string;

int main()
{

  cout << "Test 15 (back() Test):";
  
  string items[] = {"Kelly", "Chris", "Nina", "Ed", "Jack", "Curtis", "Murali"};

  Vec v(7);

  for (int i = 0; i < 7; i++)
  {
    v[i] = items[i];
  }

  bool passed = true;

  v.back() = "NewMurali";

  if (v[6] == "NewMurali")
  {
    cout << " PASSED" << endl;
  }
  else
  {
    cout << " FAILED" << endl;
    cout << "Expected: v[6] == NewMurali" << endl;
    cout << "Got:      v[6] == " << v[6] << endl;

  }

  cout << endl;
  return 0;

}
