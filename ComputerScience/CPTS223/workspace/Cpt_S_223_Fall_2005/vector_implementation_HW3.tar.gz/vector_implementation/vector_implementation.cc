///////////////////////////////////////////////////////////////////////////////
/// \author       Alex Hortin
/// \date         9/19/05
/// \brief        This is the test file for my Vec class
///
/// It uses a variety of test cases to test the functionality of the Vec class.
/// It will create vectors with different sized elements, resize, and add
/// elements to demonstrait the complete functionality of these tests.
///
/// REVISION HISTORY:
///
/// date       Comment on what was changed. Separate entries with a blank line.
///            
///////////////////////////////////////////////////////////////////////////////


// SYSTEM INCLUDES
//


// LOCAL INCLUDES
//
#include "Vec.h"

using std::cout;
using std::endl;


int main(void)
{
   cout << "/////////////////////" << endl;
   cout << "/Vector Test Program/" << endl;
   cout << "/////////////////////" << endl;
   Vec v(2);//creating a vector with 2 elements
   v[0] = "one";
   v[1] = "two";
///////////////////////////////////////////////////////////////////////
/// Test 1:
///////////////////////////////////////////////////////////////////////   
   cout << endl << "Test 1: Making a new vector with 2 elements, initializing both to 'one' and 'two', and printing the two elements:" << endl << endl;
   for ( unsigned long  i = 0; i < v.size(); ++i )
   {
      cout << v[i] << endl;
   }
///////////////////////////////////////////////////////////////////////
/// Test 2:
///////////////////////////////////////////////////////////////////////  
   cout << endl << "Test 2: Now indexing a 3rd element:" << endl << endl;
   try //trying to perform operations on a vector
   {
      cout << v[3] << endl;
   }
   catch (std::out_of_range)
   {
      cout << "Index accessing vector is out of range..." << endl;//prints out the error
   }
///////////////////////////////////////////////////////////////////////
/// Test 3:
///////////////////////////////////////////////////////////////////////
   cout << endl << "Test 3: Now creating a new default vector and running the copy constructor on the 2 element vector created earlier:" << endl << endl;
   Vec copy = v;
   bool passed3 = true;
   for (unsigned long i = 0; i < copy.size() || i < v.size(); i++)
   {
      if (v[i] != copy[i])
      {
         passed3 = false;
      }
   }
   if (passed3 == false)
   {
      cout << "Failed" << endl;
   }
   else 
   {
      cout << "Passed" << endl;
   }
///////////////////////////////////////////////////////////////////////
/// Test 4:
///////////////////////////////////////////////////////////////////////
   cout << endl << "Test 4: Now clearing the copy and trying to access the front than the back than seeing if its empty using the empty function:" << endl << endl;
   copy.clear();
   try
   {
      cout << copy.front() << endl;
   }
   catch(std::domain_error)
   {
      cout << "Empty Vector, cannot access the front" << endl;//prints out the error
   }
   try
   {
      cout << copy.back() << endl;
   }
   catch(std::domain_error)
   {
      cout << "Empty Vector, cannot access the back" << endl;//prints out the error
   }
   if (copy.empty() == true)
   {
      cout << "This vector is not empty" << endl;
   }
   if (copy.empty() == false)
   {
      cout << "This vector is empty" << endl;
   }
   
   

///////////////////////////////////////////////////////////////////////
/// Test 5:
///////////////////////////////////////////////////////////////////////
   cout << endl << "Test 5: Now using front and back to access the front and back of the original:" << endl << endl;
   try
   {
      cout << v.front() << endl;
   }
   catch(std::domain_error)
   {
      cout << "Empty Vector, cannot access the front" << endl;//prints out the error
   }
   try
   {
      cout << v.back() << endl;
   }
   catch(std::domain_error)
   {
      cout << "Empty Vector, cannot access the back" << endl;//prints out the error
   }
///////////////////////////////////////////////////////////////////////
/// Test 6:
///////////////////////////////////////////////////////////////////////
   cout << endl << "Test 6: Pushing 5 elements onto the original array and printing it out:" << endl << endl;
   v.push_back("three");
   v.push_back("four");
   v.push_back("five");
   v.push_back("six");
   v.push_back("seven");
   for ( unsigned long  i = 0; i < v.size(); ++i )
   {
      cout << v[i] << endl;
   }
///////////////////////////////////////////////////////////////////////
/// Test 7:
///////////////////////////////////////////////////////////////////////
   cout << endl << "Test 7: Now using pop_back 3 times:" << endl << endl;
   v.pop_back();
   v.pop_back();
   v.pop_back();
   for ( unsigned long  i = 0; i < v.size(); ++i )
   {
      cout << v[i] << endl;
   }
///////////////////////////////////////////////////////////////////////
/// Test 8:
///////////////////////////////////////////////////////////////////////
   cout << endl << "Test 8: Printing out the size, and using resize" << endl << endl;
   cout << v.size() << endl;
   v.resize(100);

   for (unsigned long i = 3; i< 99; i++)
   {
      v.push_back("Woots");
   }
   cout << v.size() << endl;
   if (v.size() == 100) 
   {
      cout << "Passed..." << endl;
   }
   return 0;
   
   cout << "//////" << endl;
   cout << "/Done/" << endl;
   cout << "//////" << endl;
}

   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   

