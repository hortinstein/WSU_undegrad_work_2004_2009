///////////////////////////////////////////////////////////////////////////////
/// \author       Kelly Fitz
/// \date         10 January 2006
/// \brief        Test program for readSoundfile
///
/// A program for minimally testing the sound file reader.
/// Uses two sound files "test_stereo_moo.wav" and 
/// "test_mono_boom.wav".
///
/// REVISION HISTORY:
///
/// 10 January 2006  Creation. -kel
///            
///////////////////////////////////////////////////////////////////////////////

// SYSTEM INCLUDES
//
#include <iostream>
using std::cout;
using std::endl;

#include <iostream>
using std::cout;
using std::endl;

// LOCAL INCLUDES
//
#include "Soundfile.h"

///////////////////////////////////////////////////////////////////////
/// main function for minimally testing the sound file reader
/// \return 0 on success, 1 if there is an error
///////////////////////////////////////////////////////////////////////
int main( void )
{
   Soundfile sf;
   
   cout << "reading test_stereo_moo" << endl;
   if ( 0 == readSoundfile( "test_stereo_moo.wav", sf ) ||
        44100 != sf.sampleRate ||
        44100 * 2 != sf.numSampleFrames ||
        2 != sf.numChannels )
   {
      cout << "FAILED" << endl;
      return 1;
   }
   else
   {
      cout << "OK" << endl;
   }
   delete [] sf.samples;
   
   cout << "reading test_mono_boom" << endl;
   if ( 0 == readSoundfile( "test_mono_boom.wav", sf ) ||
        44100 != sf.sampleRate ||
        44100 * 2.5 != sf.numSampleFrames ||
        1 != sf.numChannels )
   {
      cout << "FAILED" << endl;
      return 1;
   }
   else
   {
      cout << "OK" << endl;
   }
   delete [] sf.samples;
   
   cout << "reading no_such_file" << endl;
   if ( 0 != readSoundfile( "no_such_file.wav", sf ) )
   {
      cout << "FAILED" << endl;
      return 1;
   }
   else
   {
      cout << "OK (didn't find it)" << endl;
   }
   
   cout << "PASSED test_soundfile" << endl;
   return 0;
}

