///////////////////////////////////////////////////////////////////////////////
/// \class        Soundfile
/// \author       Kelly Fitz
/// \date         10 January 2006
/// \brief        A structure for storing information about a sound file.
///
/// Soundfile stores information about a sound file, including the
/// sound samples themselves. Populate this structure using the
/// readSoundfile function. 
///       
/// REVISION HISTORY:
///
/// 10 January 2006  Creation. -kel
///            
///////////////////////////////////////////////////////////////////////////////

// SYSTEM INCLUDES
//
#include "Soundfile.h"

#include <sndfile.h> // libsndfile header

#include <iostream>
using std::cerr;
using std::endl;

#include <string>
using std::string;

///////////////////////////////////////////////////////////////////////
/// readSoundfile
///
/// Populate a Soundfile struct with information from the specified 
/// sound file.
/// 
/// \param  filename the name of the sound file to read
/// \param  sfile the Soundfile structure to populate
/// \return he number of sample frames read, or 0 on error.
///////////////////////////////////////////////////////////////////////
unsigned long 
readSoundfile( const string & filename, Soundfile & sfile )
{
   // declare a SF_INFO structure, containg information
   // about the sample data, and a SNDFILE pointer, 
   // which will point to a structure representing 
   // the samples file itself.
   SF_INFO info;
   SNDFILE * sfp = 0;
   
   // declare a buffer -- not yet allocated, a pointer
   // into the buffer, and a sample counter
   double * buffer;
   sf_count_t nsamps = 0;
   
   // open the specified file using the sndfile
   // library call. If this returns a NULL pointer,
   // then the call falied.
   info.format = 0;
   sfp = sf_open( filename.c_str(), SFM_READ, &info );
   if ( 0 == sfp )
   {
      cerr << "ERROR reading file " << filename << endl;
      return 0;
   }

   cerr << "Reading " << info.channels << " channels of audio at "
        << info.samplerate << " Hz." << endl;
   
   // allocate a floating point sample buffer, and
   // fill it with samples from the file
   nsamps = info.frames * info.channels;
   buffer = new double[ nsamps ];
   if ( 0 == buffer )
   {
      cerr << "ERROR allocating buffer for " 
           << nsamps << " samples" << endl;
      return 0;
   }
   cerr << "reading..." << endl;
   sf_readf_double( sfp, buffer, info.frames );
   cerr << "read samples" << endl;

   // don't need the file itself anymore, so close it.
   sf_close( sfp );
   
   sfile.samples = buffer;
   sfile.numSampleFrames = info.frames;
   sfile.sampleRate = info.samplerate;
   sfile.numChannels = info.channels;
   
   return info.frames;
}
