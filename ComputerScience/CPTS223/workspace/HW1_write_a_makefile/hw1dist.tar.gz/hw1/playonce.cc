///////////////////////////////////////////////////////////////////////////////
/// \author       Kelly Fitz
/// \date         10 January 2006
/// \brief        A program that plays a sound file once.
///
/// main function for a simple sound player, you are to write the
/// Makefile for this program in Assignment 1, CptS223 sp06.
///
/// REVISION HISTORY:
///
/// 10 January 2006  Creation. -kel
///            
///////////////////////////////////////////////////////////////////////////////

// SYSTEM INCLUDES
//
#include <iostream>

using std::cout;
using std::endl;

// LOCAL INCLUDES
//
#include "Soundfile.h"
#include "playsamps.h"

///////////////////////////////////////////////////////////////////////
/// main function for simple sample player
/// \param  argc the number of command line arguments, inlcuding
///         the program name
/// \param  argv an array of command line arguments as C strings
/// \return 0 on success, 1 if there is an error
///////////////////////////////////////////////////////////////////////
int main( int argc, char * argv[] )
{
   // get the filename from the command line
   if ( argc < 2 )
   {
      cout << "usage: " << argv[0] << " <filename>" << endl;
      return 1;
   }
   
   // read the sound file, populate a Soundfile struct
   Soundfile sf;
   if ( 0 == readSoundfile( argv[1], sf ) )
   {
      cout << "ERROR reading file " << argv[1] << endl;
      return 1;
   }

   // play the samples
   cout << "playing samples" << endl;
   if ( 0 == playSampleFrames( sf.samples, sf.numSampleFrames, 
                               sf.sampleRate, sf.numChannels ) )
   {
      cout << "failed to play " << argv[1] << endl;
      return 1;
   }
   cout << "done." << endl;

   return 0;
}
