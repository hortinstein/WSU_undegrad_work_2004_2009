///////////////////////////////////////////////////////////////////////////////
/// \author       Kelly Fitz
/// \date         10 January 2006
/// \brief        Function for playing samples on a Linux workstation.
///
/// Definition of a function for playing sound
/// samples (stored as doubles) on a linux machine.
///
/// REVISION HISTORY:
///
/// 10 January 2006  Creation. -kel
///            
///////////////////////////////////////////////////////////////////////////////
#include "playsamps.h"

// SYSTEM INCLUDES
//
#include <iostream>
using std::cerr;
using std::endl;

#include <sys/ioctl.h>
#include <sys/soundcard.h>
#include <fcntl.h>
#include <unistd.h>

///////////////////////////////////////////////////////////////////////
/// DEVICE
///
/// A string that specifies the name of the soundcard
/// device to which play_sample_frames will dump the sample
/// bytes. By default, this is defined to be "/dev/dsp".
/// Change it if you know that your machine uses some
/// other device for the soundcard.
///////////////////////////////////////////////////////////////////////
char * DEVICE = "/dev/dsp";


///////////////////////////////////////////////////////////////////////
/// playSampleFrames
///
/// Stream a sequence of num_sample_frames frames of
/// num_channels samples of type double to the device
/// specified in DEVICE. Only works on little-endian 
/// *nix systems configured such that DEVICE is a 
/// compatible sound card. The maximum absolute value of
/// any sample should be less than 1.0, otherwise distortion
/// (clipping) will occur.
/// 
/// \param  samples an array of samples to play back
/// \param  numSampleFrames the number of sample frames stored in samples
/// \param  sampleRate the sample rate in Hz at which the samples should
///         be played back (44100 is the CD rate)
/// \param  numChannels the number of channels of audio represented
///         by each sample frame (2 for stereo)
/// \return the number of sample frames played, which should equal
///         num_sample_frames unless there is an error.
///////////////////////////////////////////////////////////////////////
unsigned long playSampleFrames( const double * samples, 
                                unsigned long numSampleFrames,
                                int sampleRate, int numChannels )
{
   int soundSystemFd;
   const int SampleSizeBytes = 16; // always
   
   // configure the sound output device
   soundSystemFd = open( DEVICE, O_WRONLY );
  
   if (soundSystemFd < 0)
   {
      cerr << "Error: Sound system could not be opened. " << endl;
      return 0;
   }
  
   if (ioctl(soundSystemFd, SNDCTL_DSP_RESET, 0) < 0)
   {
      close(soundSystemFd);
      cerr << "Error: Sound system could not be reset. " << endl;
      return 0;
   }
  
   if (ioctl(soundSystemFd, SNDCTL_DSP_SETFMT, &SampleSizeBytes) < 0)
   {
      close(soundSystemFd);
      cerr << "Error: Sample size could not be set. " << endl;
      return 0;
   }
  
   if(ioctl(soundSystemFd, SNDCTL_DSP_CHANNELS, &numChannels) < 0)
   {
      close(soundSystemFd);
      cerr << "Error: Number of channels could not be set. " << endl;
      return 0;
   }
  
   if(ioctl(soundSystemFd, SNDCTL_DSP_SPEED, &sampleRate) < 0)
   {
      close(soundSystemFd);
      cerr << "Error: Sample rate could not be set. " << endl;
      return 0;
   }               
  
   if(ioctl(soundSystemFd, SNDCTL_DSP_SYNC) < 0)   
   {
      close(soundSystemFd);
      cerr << "Error: Sound System could not be synced. " << endl;
      return 0;
   }       
  
   // Convert samples to bytes and write them
   // to the sound system device.
   #define BUFSIZE (512)      // bytes per buffer
   char buffer[ BUFSIZE ]; 
   
   unsigned long samplesRemaining = numSampleFrames * numChannels;   
   while( samplesRemaining > 0 )
   {
      // fill a buffer with (little endian) bytes to write 
      char * bufptr = buffer;
      unsigned long bytesThisBuffer = 0;
      while( bytesThisBuffer < BUFSIZE && samplesRemaining > 0 )
      {
         int sample = int( *(samples++) * (1L << 15) );
         buffer[bytesThisBuffer++] = (sample >> 0) & 0xff;  // lsb
         buffer[bytesThisBuffer++] = (sample >> 8) & 0xff;  // msb
         --samplesRemaining;
      }
         
      // write a buffer of bytes to the sound system device
      write( soundSystemFd, buffer, bytesThisBuffer );      
   } 
   
   close( soundSystemFd );
 
   // return the number of frames played back (the difference between
   // the number of frames passed in and the number that have not yet
   // been played)
   return numSampleFrames - ( samplesRemaining / numChannels );
}
