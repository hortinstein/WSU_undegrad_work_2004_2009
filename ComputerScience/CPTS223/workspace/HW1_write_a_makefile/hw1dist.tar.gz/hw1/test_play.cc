///////////////////////////////////////////////////////////////////////////////
/// \author       Kelly Fitz
/// \date         10 January 2006
/// \brief        Test program for playSampleFrames
///
/// A program for minimally testing the sound playback function,
/// uses Soundfile and readSoundfile.
/// Uses two sound files "test_stereo_moo.wav" and 
/// "test_mono_boom.wav".
///
/// REVISION HISTORY:
///
/// 10 January 2006  Creation. -kel
///            
///////////////////////////////////////////////////////////////////////////////
// SYSTEM INCLUDES
//
#include <iostream>
using std::cout;
using std::endl;

// LOCAL INCLUDES
//
#include "playsamps.h"
#include "Soundfile.h"

///////////////////////////////////////////////////////////////////////
/// main function for minimally testing the sound playback function
/// \return 0 on success, 1 if there is an error
///////////////////////////////////////////////////////////////////////
int main( void )
{
   cout << "testing playback (requires working Soundfile)" << endl;
   Soundfile sf;
   
   cout << "reading test_stereo_moo" << endl;
   unsigned long n = readSoundfile( "test_stereo_moo.wav", sf );
   if ( 0 == n )
   {
      cout << "ERROR: failed to read file" << endl;
      return 1;
   }
   
   cout << "playing" << endl;
   if ( n != playSampleFrames( sf.samples, sf.numSampleFrames, sf.sampleRate, sf.numChannels ) )
   {
      cout << "ERROR: failed to play all the sample frames" << endl;
      return 1;
   }
   else
   {
      cout << "finished playing, how'd it sound?" << endl;
      delete [] sf.samples;
   }
   
   cout << "reading test_mono_boom" << endl;
   n = readSoundfile( "test_mono_boom.wav", sf );
   if ( 0 == n )
   {
      cout << "ERROR: failed to read file" << endl;
      return 1;
   }
   
   cout << "playing" << endl;
   if ( n != playSampleFrames( sf.samples, sf.numSampleFrames, sf.sampleRate, sf.numChannels ) )
   {
      cout << "ERROR: failed to play all the sample frames" << endl;
      return 1;
   }
   else
   {
      cout << "finished playing, how'd it sound?" << endl;
      delete [] sf.samples;
   }

   cout << "PASSED test_play" << endl;
   return 0;
}
