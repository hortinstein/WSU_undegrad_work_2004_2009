////////////////////////////////////////////////////////////////////////////////
/// \author       Christopher J. Mallery
/// \date         1/30/2006
/// \brief        Skeleton GUI Code for the CptS 223 Playlist Editor
///
/// PURPOSE:   Provides a non-functioning skelton GUI for completion in hw3 of
///            CptS 223 (Spring 06)    
///
/// REVISION HISTORY:
/// 1/30/2006       Initial Creation
///           
///////////////////////////////////////////////////////////////////////////////

// INCLUDES

#include "PlaylistEditorWindow.h"
#include <FL/Fl.H>
 
// FUNCTIONS


///////////////////////////////////////////////////////////////////////
/// Main method that simply pops up a PlaylistWindow and then enters
/// an FLTK event loop.
///////////////////////////////////////////////////////////////////////
int main(void)
{
	PlaylistEditorWindow* pw;
	pw = new PlaylistEditorWindow;

	return Fl::run();
}

