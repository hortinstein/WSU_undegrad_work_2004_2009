///////////////////////////////////////////////////////////////////////////////
/// \class        PlaylistEditorWindow
/// \author       Christopher J. Mallery
/// \date         1/30/2006
/// \brief        Simple Playlist Editor
/// BASE CLASSES: Fl_Window
///
/// PURPOSE:   Allows for the building of an audio playlist.            
///
/// REVISION HISTORY:
/// 1/31/2006          Initial Creation
///           
///////////////////////////////////////////////////////////////////////////////

#include "PlaylistEditorWindow.h"	// class implemented

// INCLUDES
#include <FL/Fl_File_Chooser.H>

#include <string>


// USING STATEMENTS
using std::string;

// PUBLIC

// LIFECYCLE

/// Default constructor.
PlaylistEditorWindow::PlaylistEditorWindow() : Fl_Window(380, 150, "CptS 223 Playlist Editor")
{

	mNextButton      = new Fl_Button (20, 50, 70, 30, "Next");
	mPrevButton      = new Fl_Button (110, 50, 70, 30, "Previous");
	mInsertButton    = new Fl_Button (200, 50, 70, 30, "Insert...");
	mEraseButton     = new Fl_Button (290, 50, 70, 30, "Erase");
	mPlayAllButton   = new Fl_Button (150, 100, 70, 30, "Play All");
	mFilenameDisplay = new Fl_Box (20, 10, 340, 30);
	
	mNextButton->callback(nextButtonCallback_static, this);
	mPrevButton->callback(prevButtonCallback_static, this);
	mInsertButton->callback(insertButtonCallback_static, this);
	mEraseButton->callback(eraseButtonCallback_static, this);
	mPlayAllButton->callback(playAllButtonCallback_static, this);
	
	mFilenameDisplay->box(FL_DOWN_BOX);
    
    /// IMPLEMENT THIS ONE
    /// ADD SOMETHING HERE TO INITIALIZE ANY OTHER
    /// MEMBER VARIABLES YOU NEED.
    
    
	
	updateButtonState();
	updateFilenameDisplay( "" );
	
	this->show();
}

/// Destructor.
PlaylistEditorWindow::~PlaylistEditorWindow()
{
	
}

/// nextButtonCallback_static
/// The static callback for mNextButton
/// \param void* data: A pointer to this
/// THIS FUNCTION SHOULD NEVER BE CALLED BY HAND
void PlaylistEditorWindow::nextButtonCallback_static(Fl_Widget *w, void* data)
{
	((PlaylistEditorWindow*)data)->nextButtonCallback();
}

/// prevButtonCallback_static
/// The static callback for mPrevButton
/// \param void* data: A pointer to this
/// THIS FUNCTION SHOULD NEVER BE CALLED BY HAND
void PlaylistEditorWindow::prevButtonCallback_static(Fl_Widget *w, void* data)
{
	((PlaylistEditorWindow*)data)->prevButtonCallback();
}	

/// insertButtonCallback_static
/// The static callback for mInsertButton
/// \param void* data: A pointer to this
/// THIS FUNCTION SHOULD NEVER BE CALLED BY HAND
void PlaylistEditorWindow::insertButtonCallback_static(Fl_Widget *w, void* data)
{
	((PlaylistEditorWindow*)data)->insertButtonCallback();
}

/// eraseButtonCallback_static
/// The static callback for mEraseButton
/// \param void* data: A pointer to this
/// THIS FUNCTION SHOULD NEVER BE CALLED BY HAND
void PlaylistEditorWindow::eraseButtonCallback_static(Fl_Widget *w, void* data)
{
	((PlaylistEditorWindow*)data)->eraseButtonCallback();
}

/// playAllButtonCallback_static
/// The static callback for mEraseButton
/// \param void* data: A pointer to this
/// THIS FUNCTION SHOULD NEVER BE CALLED BY HAND
void PlaylistEditorWindow::playAllButtonCallback_static(Fl_Widget *w, void* data)
{
	((PlaylistEditorWindow*)data)->playAllButtonCallback();
}
	
/// nextButtonCallback
/// This method is called when the "Next" button is pushed
void PlaylistEditorWindow::nextButtonCallback(void)
{
/// IMPLEMENT THIS ONE

}

/// prevButtonCallback
/// This method is called when the "Previous" button is pushed	
void PlaylistEditorWindow::prevButtonCallback(void)
{
/// IMPLEMENT THIS ONE

}

/// insertButtonCallback
/// This method is called when the "Insert" button is pushed	
void PlaylistEditorWindow::insertButtonCallback(void)
{
	char* chooser_ret = fl_file_chooser( "Open Soundfile", 
		"WAV Files (*.wav)\tAIFF Files (*.aiff)\tAll Files (*)", 
		NULL, 
		1);
    
    if ( 0 != chooser_ret )
    {
        // a file was chosen:
        string filename = chooser_ret;
        
    /// IMPLEMENT THIS ONE
    
	}
}

/// eraseButtonCallback
/// This method is called when the "Erase" button is pushed
void PlaylistEditorWindow::eraseButtonCallback(void)
{
/// IMPLEMENT THIS ONE

}

/// playAllButtonCallback
/// This method is called when the "Play All" button is pushed
void PlaylistEditorWindow::playAllButtonCallback(void)
{
/// IMPLEMENT THIS ONE

}

/// updateButtonState
/// Enables/Disables the four buttons according to 
/// the internal state of class
void PlaylistEditorWindow::updateButtonState (void)
{
/// IMPLEMENT THIS ONE

    //  use the buttons' activate and deactivate members
    //  to enable and disable the buttons, for example:
	mPlayAllButton->deactivate();



}

/// updateFilenameDisplay
/// Call this function to update the window's displayed filename.
void PlaylistEditorWindow::updateFilenameDisplay( const std::string & s )
{
	if ( 0 == s.size() )
	{
		mFilenameDisplay->copy_label("");
	}
	else
	{
		mFilenameDisplay->copy_label( s.c_str() );
	}
}


